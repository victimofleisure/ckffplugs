INTRODUCTION:

FFSrcPlug is an MFC template project for developing Freeframe source plugins. It mirrors the structure of a typical MFC graphics app, using a surrogate main frame and view, so that drawing code can be transplanted from an app to a plugin with minimal modifications. The project has a simple demo view which draws a bouncing ball, and exposes a single Freeframe parameter (the ball speed).

Look for lines containing the string "TODO"; these mark areas where customization is needed. The process generally should include these steps.

1) In DemoPlug.cpp, edit the plugin's ID and title. NOTE that these are NOT null-terminated strings! Do NOT change their lengths. Pad them with blanks as necessary to keep their lengths the same.

2) In DemoPlug.cpp, edit the plugin's description and about text. These ARE null-terminated strings but don't go crazy with the length as the host may truncate them. The description should summarize what the plugin does, and the about text should contain the author and license info if any.

3) In DemoPlug.h, enumerate your plugin's parameters. This number and order of the parameters enumerated here MUST match the definition of paramConstants in DemoPlug.cpp (see below).

4) In DemoPlug.cpp, add your plugin's parameters to paramConstants. NOTE that the parameter names are NOT null-terminated strings! Do NOT change their lengths. Pad them with blanks as necessary to keep their lengths the same. Also set the default values of your parameters here.

5) In DemoPlug.cpp, customize the switch statement in setParameter as needed to pass the parameters into your CMainFrame object. Note that since DemoPlug is derived from CMainFrame, DemoPlug has access to CMainFrame's protected members.

6) In DemoView.cpp, replace the drawing code in Draw with your own drawing code.

7) In FFSrcPlug.def, change the plugin name and description.

8) In Project/Settings/Link, change the output DLL name for both Release and Debug.

And that's all.

NOTES:

The source code and binaries for this release are available from the FFRend web site, http://ffrend.sourceforge.net/.

LICENSE:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA.

Kopyleft 2006 Chris Korda, All Rites Reversed.

END
