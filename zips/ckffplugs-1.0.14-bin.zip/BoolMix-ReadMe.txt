INTRODUCTION:

BoolMix is a boolean mixer Freeframe effect for Windows 2000/XP. It blends two input frames together using a boolean operation. This type of graphical blending is known in the Windows world as a ROP or Raster OPeration. The plugin takes a single parameter, which selects the blending mode to use.

The available blending modes are listed in the table below. Each blending mode is a boolean operator (OR, AND, XOR) optionally combined with an inversion of one of the inputs, or the output.

Parameter    Boolean     Description                     ROP     GDI name
0.0 to 0.1   ~A & B      AND inverted A with B           DSna     
0.1 to 0.2   ~A | B      OR inverted A with B            DSno    MERGEPAINT
0.2 to 0.3   A & ~B      AND A with inverted B           SDna    SRCERASE
0.3 to 0.4   A & ~B      OR A with inverted B            SDno     
0.4 to 0.5   A & B       AND A with B                    DSa     SRCAND
0.5 to 0.6   A | B       OR A with B                     DSo     SRCPAINT
0.6 to 0.7   A ^ B       XOR A with B                    DSx     SRCINVERT
0.7 to 0.8   ~(A & B)    AND A with B, invert result     DSan     
0.8 to 0.9   ~(A | B)    OR A with B, invert result      DSon    NOTSRCERASE
0.9 to 1.0   ~(A ^ B)    XOR A with B, invert result     DSxn     

The XOR modes alter the colors drastically, giving a psychedelic effect. The other modes don't alter the colors as much, but they're also more sensitive to very dark or very light inputs. SRCPAINT is similar to transparency, and causes the least amount of color distortion. SRCAND is similar to luma-keying: the video is only visible in non-black portions of the animation. The default blending mode is SRCINVERT.

PARAMETERS:

Blending mode
Selects one of the blending modes listed above.

NOTES:

The source code and binaries for this release are available from the FFRend web site, http://ffrend.sourceforge.net/.

LICENSE:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA.

Kopyleft 2006 Chris Korda, All Rites Reversed.

END
