----------------
AlphaMix
----------------

DESCRIPTION:	Alpha mixes two inputs.

PARAMETERS:

1.	Mix Value	0 = input B, .5 = 50/50 mix, 1 = input A

REMARKS:

MMX optimized. Supports 32-bit color only.

----------------
Blacken
----------------

DESCRIPTION:	Fade to black.

PARAMETERS:

1.	Brightness	0 = all black, 1 = normal

REMARKS:

MMX optimized. Supports 32-bit color only.

----------------
Brightness
----------------

DESCRIPTION:	Brightness filter.

PARAMETERS:

1.	Brightness	0 = all black, .5 = normal, 1 = all white

REMARKS:

MMX optimized. Supports 32-bit color only.

----------------
CharGen
----------------

DESCRIPTION:	Character generator (single character).

PARAMETERS:

1.	Character	ASCII character to display, from 0x21 to 0x7E
2.	Font		which font to use; depends on installed fonts
3.	Font Size	font size
4.	Horz Scale	horizontal scaling: 0 = narrow, .5 = none, 1 = wide
5.	Pos X		X position
6.	Pos Y		Y position
7.	Rotation	rotation: 0 to 360 degrees
8.	Red		red channel of text color
9.	Green		green channel of text color
10.	Blue		blue channel of text color
11.	Background	if zero, background is transparent, else it's black
12.	Bold		if non-zero, text is bold
13.	Italic		if non-zero, text is italic
14.	Underline	if non-zero, text is underlined

REMARKS:

For anti-aliasing, use CharGenAA instead. To display lines of text, 
use TextGen or TextGenAA.

----------------
CharGenAA
----------------

DESCRIPTION:	Anti-aliased character generator (single character only).

PARAMETERS:

Same as CharGen.

REMARKS:

This plugin uses GDI+ instead GDI, and therefore requires the GDI+ DLL.
To use this plugin under versions of Windows earlier than XP, you must
install the GDI+ redistributable.

----------------
ContrastPS
----------------

DESCRIPTION:	Photoshop-style brightness/contrast filter.

PARAMETERS:

1.	Brightness	0 = minimum, .5 = normal, 1 = maximum
2.	Contrast	0 = all gray, .5 = normal, 1 = thresholding

REMARKS:

MMX optimized. Supports 32-bit color only.

To exactly emulate Photoshop's behavior, the brightness parameter is
scaled by 40%, and therefore does not saturate to black/white. Note
that when reducing Contrast, Brightness is applied first, whereas when
increasing Contrast, Brightness is applied afterwards. Also note that
maximum Contrast (thresholding) is handled as a special case, since it
would otherwise cause a divide by zero. The algorithm is shown below;
in this pseudocode, the parameters are assumed to range from -1 to 1.

for each color channel value [0..255] of each pixel
	if (Contrast <= 0) 
		val = (val - 128) * (1 + Contrast) + 128 + Brightness * 255
	else
		val = (val - (128 - Brightness * 255)) * (1 / (1 - Contrast)) + 128
	val = CLAMP(val, 0, 255)

----------------
Fauve
----------------

DESCRIPTION:	Colorizes input in the style of Fauvism.

PARAMETERS

1.	Mode		0 = Luma, .5 = RGB

REMARKS:

The plugin is a visualization of a histogram but using pseudocolor
instead of the customary graph. Pixels are colored according to the
popularity of their original colors in the input image, such that more
common input colors translate to brighter output colors. The effect
enhances edges, adds texture, simplifies and drastically alters the
palette, and reduces spatial cohesion. In Luma mode, the plugin:

1. Calculates the frame's luma histogram.
2. Replaces each pixel with a greyscale value corresponding to that
pixel's rank in the luma histogram. The histogram is normalized so
that pixels in the top rank are assigned white in the output, while
pixels in lower ranks receive proportionally darker values.

RGB mode is similar, but does the above operations separately for each
color channel, resulting in color output instead of greyscale.

Supports all color modes. Assembler optimized.

----------------
Histogram
----------------

DESCRIPTION:	Displays a continuous histogram of the input video.

PARAMETERS

1.	Mode		0 = Luma, .25 = RGB, .5 = RGB + Luma, .75 = RGB Overlay
2.	Fill		if non-zero, use fill, else draw lines
3.	Erase Bkgnd	if non-zero, erase background, else background is input video
4.	Scale		vertical scaling: 0 = minimum, 1 = maximum (frame height)
5.	Origin		0 = top, 1 = bottom; ignored if Scale is maximum
6.	Line Width	0 = one pixel, 1 = maximum; only applies to line draw mode

REMARKS:

Supports all color modes. Assembler optimized.

----------------
Invert
----------------

DESCRIPTION:	Inverts RGB values.

PARAMETERS

1.	Enable		0 = disabled, non-zero = enabled 

REMARKS:

Supports all color modes.

----------------
MaskMix
----------------

DESCRIPTION:	Mixes two inputs according to a third mask input.

PARAMETERS:

1.	Mask Mode	controls input roles: see table below
2.	Mask Opacity	opacity of mask: 0 = none, 1 = max
3.	Negate Mask	if non-zero, invert mask input

Mask mode table:

#	ch1 	ch2 	mask
----	----	----	----
0	src1	src2	src3
1	src1	src3	src2
2	src2	src3	src1
3	src2	src1	src3
4	src3	src1	src2
5	src3	src2	src1

REMARKS:

Same behavior as vvDynaMask, but an order of magnitude faster.
MMX optimized. Supports 32-bit color only.

----------------
Multiply
----------------

DESCRIPTION:	Multiplies two inputs.

PARAMETERS:

1.	Blend		alpha mixes between input A and multiply result
2.	Invert		if non-zero, invert input B before multiply
3.	Swap inputs	if non-zero, swap inputs

REMARKS:

Multiplies the two inputs, and blends the result with input A.
MMX optimized. Supports 32-bit color only.

----------------
Radar
----------------

DESCRIPTION:	Source plugin to simulate a radar sweep.

PARAMETERS:

1.	Speed		auto-rotation rate: 0 = none, 1 = max
2.	Decay		sweep width: 0 = min, .5 = fit to frame, 1 = max
3.	Radius		sweep radius: 0 = min, 1 = max
4.	Color		selects sweep color: white, R, G, B, C, M, Y
5.	Origin X	sweep origin X: 0 = left, 1 = right
6.	Origin Y	sweep origin Y: 0 = top, 1 = bottom
7.	Angle		angle: 0 = 0 degrees, 1 = 360 degrees
8.	Scale		radius scaling: 0 = none, 1 = max
9.	Reverse		if non-zero, reverse sweep direction

REMARKS:

Assembler optimized. Supports 32-bit color only.

The Angle parameter is more useful with auto-rotate off (Speed = 0).
The Scale parameter is useful for ensuring that the sweep fills the
entire frame, e.g. if the frame has an unusual aspect ratio, or the
origin is moved to a corner of the frame. The fit to frame behavior
(Radius = .5) assumes Scale = 0.

----------------
TextGen
----------------

DESCRIPTION:	Text generator.

PARAMETERS:

1.	Document	which document to display
2.	Line		which line of current document to display
3.	Font		which font to use; depends on installed fonts
4.	Font Size	font size
5.	Leading		line spacing: 0 = min, .5 = default, 1 = max
6.	Horz Scale	horizontal scaling: 0 = narrow, .5 = none, 1 = wide
7.	Pos X		X position
8.	Pos Y		Y position
9.	Rotation	rotation: 0 to 360 degrees
10.	Red		red channel of text color
11.	Green		green channel of text color
12.	Blue		blue channel of text color
13.	Background	if zero, background is transparent, else it's black
14.	Bold		if non-zero, text is bold
15.	Italic		if non-zero, text is italic
16.	Underline	if non-zero, text is underlined
17.	Horz Margins	horizontal margins, as percentage of frame width

REMARKS:

The plugin looks for text files in the folder "My Documents\TextGen".
If there's a text file in My Documents\TextGen called playlist.txt, it's
assumed to contain a list of paths to text files; for details, see below.
If there's no playlist, any text files (files with the .txt extension)
found in My Documents\TextGen are loaded, in alphabetical order. If
there's no playlist and no text files are found either, the plugin
displays "NO TEXT".

If playlist.txt exists, it's assumed to contain a list of absolute
(fully-qualified) paths to other text files. Each line of the playlist 
should contain exactly one path. Do not enclose paths in quotes, even
if they contain spaces. The text files are loaded in the order they 
appear in the playlist. The playlist method requires more setup, but
allows you to link to existing documents instead of copying them
to the TextGen folder, and also lets you specify the document order.

Text files may be ASCII or Unicode UTF-16LE (16-bit little-endian).
Unicode text files must have the BOM (Byte Order Mark) 0xFF, 0xFE
in the first two bytes.

For anti-aliasing, use TextGenAA instead. To display single characters,
use CharGen or CharGenAA.

----------------
TextGenAA
----------------

DESCRIPTION:	Anti-aliased text generator.

PARAMETERS:

Same as TextGen.

REMARKS:

The plugin looks for text files in the folder "My Documents\TextGen".
For details, see TextGen.

This plugin uses GDI+ instead GDI, and therefore requires the GDI+ DLL.
To use this plugin under versions of Windows earlier than XP, you must
install the GDI+ redistributable.

----------------
Whiten
----------------

DESCRIPTION:	Fade to white.

PARAMETERS:

1.	Brightness	0 = normal, 1 = all white

REMARKS:

MMX optimized. Supports 32-bit color only.

---------------------------------------
LICENSE	for all plugins described above
---------------------------------------

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA.

Kopyleft 2007 Chris Korda, All Rites Reversed.

http://whorld.org

END
