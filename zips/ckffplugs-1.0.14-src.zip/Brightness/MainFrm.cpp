// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"
#include "mmintrin.h"

#define USE_MMX	1

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	m_Brightness = .5;
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	return(TRUE);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	Offset(pFrame, m_FrameBytes, m_Brightness);
	return(FF_SUCCESS);
}

DWORD CMainFrame::processFrameCopy(ProcessFrameCopyStruct *pParam)
{
	return(FF_FAIL);
}

void CMainFrame::Offset(PVOID pFrame, int FrameBytes, float Brightness)
{
	int	iVal = round(((Brightness * 2) - 1) * 255);
#if USE_MMX
	int	t = abs(iVal);
	__m64	AbsVal = _mm_set1_pi8(t);
	if (iVal > 0) {
		__asm {
			movq	mm1, AbsVal
			mov		ecx, FrameBytes
			shr		ecx, 3
			mov		ebx, pFrame
	$1:
			movq	mm0, [ebx]
			paddusb	mm0, mm1
			movq	[ebx], mm0
			add		ebx, 8
			loop	$1
			emms
		}
	} else if (iVal < 0) {
		__asm {
			movq	mm1, AbsVal
			mov		ecx, FrameBytes
			shr		ecx, 3
			mov		ebx, pFrame
	$2:
			movq	mm0, [ebx]
			psubusb	mm0, mm1
			movq	[ebx], mm0
			add		ebx, 8
			loop	$2
			emms
		}
	}
#else
	if (iVal) {
		int	dws = FrameBytes >> 2;
		BYTE	*bp = (BYTE *)pFrame;
		int	t;
		for (int i = 0; i < dws; i++) {
			t = *bp;
			t += iVal;
			*bp++ = CLAMP(t, 0, 255);
			t = *bp;
			t += iVal;
			*bp++ = CLAMP(t, 0, 255);
			t = *bp;
			t += iVal;
			*bp++ = CLAMP(t, 0, 255);
			bp++;
		}
	}
#endif
}
