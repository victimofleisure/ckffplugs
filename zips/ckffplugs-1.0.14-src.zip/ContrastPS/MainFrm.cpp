// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"
#include <math.h>
#include "mmintrin.h"

#define USE_MMX	1

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	m_Brightness = 0.5f;
	m_Contrast = 0.5f;
	m_BrightScale = 0.4f;	// PS-style brightness parameter
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	return(TRUE);
}

void Threshold(PVOID pFrame, int FrameBytes, float Threshold)
{
#if USE_MMX
	const __m64	qwT = _mm_set1_pi16(round(Threshold * 255));
	__asm {
		mov		ecx, FrameBytes
		shr		ecx, 3		; bytes to quad words
		mov		ebx, pFrame
		movq	mm4, qwT	; mm4 = threshold
		pxor	mm5, mm5	; mm5 = 0
	$1:
		movq		mm0, [ebx]	; read 2 pixels

		movq		mm1, mm0	; copy 2 pixels
		punpcklbw	mm0, mm5	; convert pixel0 to 4 words

		punpckhbw	mm1, mm5	; convert pixel1 to 4 words
		pcmpgtw		mm0, mm4	; threshold pixel0

		pcmpgtw		mm1, mm4	; threshold pixel1

		packsswb	mm0, mm1	; convert 8 words to 2 pixels

		movq		[ebx], mm0	; write 2 pixels

		add		ebx, 8
		loop	$1
		emms
	}
#else
	int	iT = round(Threshold * 255);
	int	dws = FrameBytes >> 2;
	BYTE	*bp = (BYTE *)pFrame;
	for (int i = 0; i < dws; i++) {
		*bp++ = (*bp <= iT ? 0 : 255);
		*bp++ = (*bp <= iT ? 0 : 255);
		*bp++ = (*bp <= iT ? 0 : 255);
		bp++;
	}
#endif
}

//	PS-style brightness/contrast filter
//
//	Brightness	-1 = min, 0 = no effect, 1 = max
//	Contrast	-1 = all gray, 0 = no effect, 1 = thresholding
//
//	for each color channel value [0..255] of each pixel
//		if (Contrast <= 0) 
//			val = (val - 128) * (1 + Contrast) + 128 + Brightness * 255
//		else
//			val = (val - (128 - Brightness * 255)) * (1 / (1 - Contrast)) + 128
//		val = CLAMP(val, 0, 255)
//
//	PS's brightness parameter is scaled and does not saturate to
//  black/white; to emulate PS behavior, scale brightness by 0.4
//
//	MMX version can't handle brightness scaling > 0.5 due to limitations
//	of fixed-point 16-bit math; failure mode is unexpected wrapping
//
void Contrast(PVOID pFrame, int FrameBytes, float Brightness, float Contrast)
{
	float	fC, fL0, fL1;
	if (Contrast <= 0) {	// if reducing contrast
		fC = 1 + Contrast;
		fL0 = 128;
		fL1 = 128 + Brightness * 255;	// apply brightness after scaling
	} else {	// increasing contrast
		fC = Contrast < 1 ? 1 / (1 - Contrast): 1e6f;	// avoid divide by zero
		fL0 = 128 - Brightness * 255;	// apply brightness before scaling
		fL1 = 128;
	}
#if USE_MMX
	if (fC > 63) {	// if contrast too high for signed 16-bit
		Threshold(pFrame, FrameBytes, 0.5f - Brightness);
		return;
	}
	const __m64	qwC = _mm_set1_pi16(round(fC * 512));
	const __m64	qwL0 = _mm_set1_pi16(round(fL0));
	const __m64	qwL1 = _mm_set1_pi16(round(fL1));
	__asm {
		mov		ecx, FrameBytes
		shr		ecx, 3		; bytes to quad words
		mov		ebx, pFrame
		movq	mm4, qwL0	; mm4 = luma0
		movq	mm5, qwL1	; mm5 = luma1
		movq	mm6, qwC	; mm6 = contrast
		pxor	mm7, mm7	; mm7 = 0
	$1:	
		movq		mm0, [ebx]	; read 2 pixels

		movq		mm1, mm0	; copy 2 pixels
		punpcklbw	mm0, mm7	; convert pixel0 to 4 words

		punpckhbw	mm1, mm7	; convert pixel1 to 4 words
		psubsw		mm0, mm4	; subtract luma0 from pixel0

		psubsw		mm1, mm4	; subtract luma0 from pixel1
		psllw		mm0, 7		; shift pixel0 left 7

		psllw		mm1, 7		; shift pixel1 left 7
		pmulhw		mm0, mm6	; multiply pixel0 by contrast

		pmulhw		mm1, mm6	; multiply pixel1 by contrast

		paddsw		mm0, mm5	; add luma1 to pixel0
		paddsw		mm1, mm5	; add luma1 to pixel1

		packuswb	mm0, mm1	; convert 8 words to 2 pixels

		movq		[ebx], mm0	; write 2 pixels

		add		ebx, 8
		loop	$1
		emms
	}
#else
	int	dws = FrameBytes >> 2;
	BYTE	*bp = (BYTE *)pFrame;
	for (int i = 0; i < dws; i++) {
		float	val;
		val = *bp;
		val = (val - fL0) * fC + fL1;
		*bp++ = round(CLAMP(val, 0, 255));
		val = *bp;
		val = (val - fL0) * fC + fL1;
		*bp++ = round(CLAMP(val, 0, 255));
		val = *bp;
		val = (val - fL0) * fC + fL1;
		*bp++ = round(CLAMP(val, 0, 255));
		bp++;
	}
#endif
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	Contrast(pFrame, m_FrameBytes, (m_Brightness * 2 - 1) * m_BrightScale, 
		m_Contrast * 2 - 1);
	return(FF_SUCCESS);
}

DWORD CMainFrame::processFrameCopy(ProcessFrameCopyStruct *pParam)
{
	return(FF_FAIL);
}
