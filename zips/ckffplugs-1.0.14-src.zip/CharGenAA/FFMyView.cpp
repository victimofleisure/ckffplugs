// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
		01		09aug08	CharGen initial version
		02		11jul11	fix vertical centering
		03		12jul11	reselect default font
		04		14jul11	add background param
		05		19jul11	make font size logarithmic
		06		06aug11	refactor
		07		17nov11	disable test code

		freeframe character generator view
 
*/

// FFMyView.cpp : implementation of the CFFMyView class
//

#include "stdafx.h"
#include "FFMyView.h"
#include <math.h>
#include "Benchmark.h"
#include "Win32Console.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFFMyView

CFFMyView::CFFMyView()
{
//	Win32Console::Create();	// debug only
	m_Character = 0;
	m_Font = 0;
	m_FontSize = .1f;
	m_HorzScale = .5;
	m_PosX = .5;
	m_PosY = .5;
	m_Rotation = 0;
	m_TextR = 1;
	m_TextG = 1;
	m_TextB = 1;
	m_Background = 0;
	m_Bold = 0;
	m_Italic = 0;
	m_Underline = 0;
	GetFonts();
}

int CALLBACK CFFMyView::FontProc(const LOGFONT *Font, const TEXTMETRIC *Metric, DWORD FontType, LPARAM lParam)
{
	CFFMyView	*This = (CFFMyView *)lParam;
	if (FontType == TRUETYPE_FONTTYPE) {
		FONT_INFO	fi;
		_tcscpy(fi.FaceName, Font->lfFaceName);
		fi.AspectRatio = float(Metric->tmAveCharWidth) / Metric->tmHeight;
		This->m_FontInfo.Add(fi);
	}
	return(TRUE);
}

void CFFMyView::GetFonts()
{
	LOGFONT	lf;
	ZeroMemory(&lf, sizeof(lf));
	lf.lfCharSet = ANSI_CHARSET;
	HDC	dc = GetDC(NULL);
	EnumFontFamiliesEx(dc, &lf, FontProc, (LPARAM)this, 0);
	ReleaseDC(NULL, dc);
}

#define TEST 0

DWORD CFFMyView::processFrame(LPVOID pFrame)
{
	CFont	font;
	if (m_FontInfo.GetSize()) {
		int	FontIdx = Denorm(m_Font, m_FontInfo.GetSize());
		const FONT_INFO&	fi = m_FontInfo[FontIdx];
		double	rHeight = m_VideoInfo.frameHeight 
			* (pow(MAX_FONT_SCALE, m_FontSize) - 1) + 1;
		int	Height = round(rHeight);
		font.CreateFont(
			Height,
			0,
			0,
			0,
			m_Bold ? FW_BOLD : FW_NORMAL,
			m_Italic,
			m_Underline,
			FALSE,
			ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE,
			fi.FaceName);
	}
	Bitmap	bmp(&m_bmi, pFrame);
	Graphics	g(&bmp);
	Color	c(round(m_TextR * 255), round(m_TextG * 255), round(m_TextB * 255));
	SolidBrush	brush(c);
	Font	f(m_hDC, font);
	g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
	if (m_Background) {
		Color	bg;
		g.Clear(bg);
	}
#if TEST
	Pen	BluePen(Color(0, 0, 255), 1);
	g.DrawLine(&BluePen, m_VideoInfo.frameWidth / 2, 0, m_VideoInfo.frameWidth / 2, m_VideoInfo.frameHeight);
	g.DrawLine(&BluePen, 0, m_VideoInfo.frameHeight / 2, m_VideoInfo.frameWidth, m_VideoInfo.frameHeight / 2);
#endif
	TCHAR	text = FIRST_CHAR + Denorm(m_Character, NUM_CHARS);
	PointF	org(0, 0);
	RectF	br;
	g.MeasureString(&text, 1, &f, org, &br);
	Matrix	mat;
	float	HorzScale = float(pow(MAX_HORZ_SCALE, m_HorzScale * 2 - 1));
	mat.Scale(HorzScale, 1, MatrixOrderAppend);
	PointF	center(br.Width * HorzScale / 2, br.Height / 2);
	mat.RotateAt(m_Rotation * -360, center, MatrixOrderAppend);
	float	x = m_VideoInfo.frameWidth * m_PosX;
	float	y = m_VideoInfo.frameHeight * m_PosY;
	mat.Translate(x - center.X, y - center.Y, MatrixOrderAppend);
	g.SetTransform(&mat);
#if TEST
	Pen	RedPen(Color(255, 0, 0), 1);
	g.DrawRectangle(&RedPen, br);
#endif
	g.DrawString(&text, 1, &f, org, &brush);
	return(FF_SUCCESS);
}
