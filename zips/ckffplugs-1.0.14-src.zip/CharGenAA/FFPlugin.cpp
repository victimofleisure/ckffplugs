// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		04jan08	add description and about text
		03		09aug08	CharGen initial version
		04		11jul11	change Pos Y default to .5
		05		11jul11	make rotation zero-origin
		06		14jul11	add background param
		07		06aug11	refactor

		freeframe plugin
 
*/

#include <stdafx.h>
#include "FFPlugin.h"
#include <math.h>

const PlugInfoStruct PlugInfo = {
	1,	// API major version; don't change
	0,	// API minor version; don't change
	{'C', 'G', 'A', 'A'},	// plugin identifier; MUST be 4 bytes
	{'C', 'h', 'a', 'r', 'G', 'e', 'n', 'A',
	 'A', ' ', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title; MUST be 16 bytes
	0	// effect plugin
};

const PlugExtendedInfoStruct PlugExtInfo = {
	1,		// plugin major version
	0,		// plugin minor version
	"Antialiased Character Generator",	// description; this IS a null-terminated string
	"Copyleft 2011 Chris Korda",	// about text; this IS a null-terminated string
	0,		// extended data size
	NULL	// extended data block
};

const CFFPlugin::ParamConstantsStruct paramConstants[CFFPlugin::NUM_PARAMS] = {
//			 1234567890123456		these MUST be 16 bytes long, padded with blanks
	{0,		"Character       "},
	{0,		"Font            "},
	{.1f,	"Font Size       "},
	{.5,	"Horz Scale      "},
	{.5,	"Pos X           "},
	{.5,	"Pos Y           "},
	{0,		"Rotation        "},
	{1,		"Red             "},
	{1,		"Green           "},
	{1,		"Blue            "},
	{0,		"Background      "},
	{0,		"Bold            "},
	{0,		"Italic          "},
	{0,		"Underline       "},
};

PlugInfoStruct* getInfo() 
{
	return const_cast<PlugInfoStruct *>(&PlugInfo);
}

DWORD initialise()
{
	return FF_SUCCESS;
}

DWORD deInitialise()
{
	return FF_SUCCESS;
}

DWORD getNumParameters()
{
	return CFFPlugin::NUM_PARAMS;  
}

char* getParameterName(DWORD index)
{
	if (index >= 0 && index < CFFPlugin::NUM_PARAMS)
		return const_cast<char *>(paramConstants[index].name);
	return "                ";
}

float getParameterDefault(DWORD index)
{
	if (index >= 0 && index < CFFPlugin::NUM_PARAMS)
		return paramConstants[index].defaultValue;
	return 0;
}

CFFPlugin::CFFPlugin()
{
	for (int i = 0; i < NUM_PARAMS; i++) {
		m_Param[i].value = paramConstants[i].defaultValue;	// init to default values
		memset(m_Param[i].displayValue, ' ', MAX_STRING);
	}
}

CFFPlugin::~CFFPlugin()
{
}

char* CFFPlugin::getParameterDisplay(DWORD index)
{
	memset(m_Param[index].displayValue, ' ', MAX_STRING);
	if (index >= 0 && index < NUM_PARAMS) {
		char	s[MAX_STRING];
		sprintf(s, "%g", m_Param[index].value);
		int	len = strlen(s);
		memcpy(m_Param[index].displayValue, s, min(len, MAX_STRING));
	}
	return m_Param[index].displayValue;
}

DWORD CFFPlugin::setParameter(SetParameterStruct* pParam)
{
	int	index = pParam->index;
	if (index >= 0 && index < NUM_PARAMS) {
		float	val = pParam->value;
		m_Param[index].value = val;
		switch (index) {
		case CHARACTER:
			m_Character = val;
			break;
		case FONT:
			m_Font = val;
			break;
		case FONT_SIZE:
			m_FontSize = val;
			break;
		case HORZ_SCALE:
			m_HorzScale = val;
			break;
		case POS_X:
			m_PosX = val;
			break;
		case POS_Y:
			m_PosY = val;
			break;
		case ROTATION:
			m_Rotation = val;
			break;
		case RED:
			m_TextR = val;
			break;
		case GREEN:
			m_TextG = val;
			break;
		case BLUE:
			m_TextB = val;
			break;
		case BACKGROUND:
			m_Background = val > 0;
			break;
		case BOLD:
			m_Bold = val > 0;
			break;
		case ITALIC:
			m_Italic = val > 0;
			break;
		case UNDERLINE:
			m_Underline = val > 0;
			break;
		}
		return FF_SUCCESS;
	}
	return FF_FAIL;
}

float CFFPlugin::getParameter(DWORD index)
{
	if (index >= 0 && index < NUM_PARAMS)
		return m_Param[index].value;
	return 0;
}

DWORD CFFPlugin::processFrameCopy(ProcessFrameCopyStruct* pFrameData)
{
	return FF_FAIL;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case FF_CAP_16BITVIDEO:
		return FF_TRUE;

	case FF_CAP_24BITVIDEO:
		return FF_TRUE;

	case FF_CAP_32BITVIDEO:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_FALSE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return CFFPlugin::NUM_INPUT_FRAMES;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return CFFPlugin::NUM_INPUT_FRAMES;

	case FF_CAP_COPYORINPLACE:
		return FF_FALSE;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	// this shouldn't happen if the host is checking the capabilities properly
	if (pVideoInfo->bitDepth < 0 || pVideoInfo->bitDepth > 2)
		return (LPVOID) FF_FAIL;

	CFFPlugin *pPlugObj = new CFFPlugin;

	if (!pPlugObj->Init(*pVideoInfo)) {
		delete pPlugObj;
		return NULL;
	}

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	CFFPlugin *pPlugObj = (CFFPlugin*) instanceID;
	delete pPlugObj;	// delete first, THEN set to null (duh!)
	pPlugObj = NULL;	// mark instance deleted
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	return (LPVOID) &PlugExtInfo;
}
