// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
		01		06aug11	refactor for GDI+

		freeframe GDI+ view
 
*/

// FFGdiplusView.h : interface of the CFFGdiplusView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FFGDIPLUSVIEW_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
#define AFX_FFGDIPLUSVIEW_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFFGdiplusView window

#include "FreeFrame.h"

#if _MFC_VER <= 0x600
typedef ULONG *ULONG_PTR;
#endif
#include "gdiplus.h"
using namespace Gdiplus;

class CFFGdiplusView
{
// Construction
public:
	CFFGdiplusView();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants

// Types

// Attributes

// Operations

// Overrides

// Implementation
public:
	~CFFGdiplusView();

// Generated message map functions
protected:

// Types
	typedef struct tagMYBITMAPINFO : BITMAPINFO {
		// The bmiColors array allocates a single DWORD, but in 16-bit mode,
		// bmiColors needs to contain three DWORDs: one DWORD each for the red,
		// green and blue color masks.  So we inherit from BITMAPINFO and add 
		// space for the green and blue masks; the red mask is bmiColors[0].
		DWORD	GreenMask;
		DWORD	BlueMask;
	} MYBITMAPINFO;

// Constants

// Member data
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	MYBITMAPINFO	m_bmi;			// frame DIB info
	HDC		m_hDC;					// frame DIB device context
	LONG	m_FrameBytes;			// size of frame in bytes
	LONG	m_BytesPerPixel;		// number of bytes per pixel

// GDI+ member data
	GdiplusStartupInput		m_gdipStartupInput;
	GdiplusStartupOutput	m_gdipStartupOutput;
	ULONG_PTR	m_gdipToken;
	ULONG_PTR	m_gdipHookToken;

// Helpers
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FFGDIPLUSVIEW_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
