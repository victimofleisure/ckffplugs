// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo
        02      18jul11	mask mixer

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"
#include <math.h>
#include "mmintrin.h"

#define USE_MMX	1

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	m_MaskOpacity = 1;
	m_MaskMode = 0;
	m_NegateMask = 0;
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	return(TRUE);
}

const CMainFrame::INPUT_SEL CMainFrame::m_InputSel[MASK_MODES] = {
//		A	B	Mask
	{	0,	1,	2	},
	{	0,	2,	1	},
	{	1,	2,	0	},
	{	1,	0,	2	},
	{	2,	0,	1	},
	{	2,	1,	0	},
};

DWORD CMainFrame::processFrameCopy(ProcessFrameCopyStruct *pParam)
{
	const INPUT_SEL& InpSel = m_InputSel[m_MaskMode];
	BYTE	*pInA = (BYTE *)pParam->InputFrames[InpSel.A];
	BYTE	*pInB = (BYTE *)pParam->InputFrames[InpSel.B];
	BYTE	*pInMask = (BYTE *)pParam->InputFrames[InpSel.Mask];
	BYTE	*pOut = (BYTE *)pParam->OutputFrame;
#if USE_MMX
	enum {
		MASK_MULT = 21932	// ((2^13 << 16) / ((255 * 3) << 5)) + 1
	};
	__m64	Zero = _mm_setzero_si64();
	__m64	One = _mm_set1_pi16(1);
	int	BlendedMaskMult = round(MASK_MULT * m_MaskOpacity);
	__m64	MaskMult = _mm_set1_pi16(BlendedMaskMult);	
	__m64	MaskOne = _mm_set1_pi16(8192);		// 2^13
	short	wNegMask = m_NegateMask ? 0xff : 0;
	__m64	NegMask = _mm_set_pi16(0, wNegMask, wNegMask, wNegMask);
	int	nLoops = m_FrameBytes >> 2;
	// Normally we don't care what's in the alpha channel, but since we're
	// summing the mask's channels, a non-zero alpha value in the mask could
	// cause the sum to overflow; hence we zero the mask alpha before summing.
	//
	// Intermediate / Maximize Parallelism ordering is a hair faster than basic.
	// Zero alpha channel is applied afterwards as it hangs Quexal's optimizer.
	__asm {
		mov EAX, pInA                              //   EAX = pointer to input frame A
		mov EDX, pInB                              //   EDX = pointer to input frame B
		movq      mm3, NegMask                     //   NegMask = memory[NegMask]
		movq      mm0, MaskMult                    //   MaskMult = memory[MaskMult]
		movq      mm5, Zero                        //   Zero = memory[Zero]
		mov ESI, pInMask                           //   ESI = pointer to input mask
		movq      mm2, MaskOne                     //   MaskOne = memory[MaskOne]
		movq      mm1, One                         //   One = memory[One]
		mov EDI, pOut                              //   EDI = pointer to output frame
		mov ECX, nLoops                            //   ECX = loop count
	   ALIGN 16
	$1: 
		mov		  EBX, [ESI]                       //   EBX = Mask
		and		  EBX, 0ffffffh                    //   zero Mask alpha before summing
		movd      mm4, EBX                         //   Mask = memory[ESI]
		punpcklbw mm4, mm5                         //   Unpack Mask and Zero into Mask (low-order)
		movq      mm6, mm2                         //   InvMask = MaskOne
		pxor      mm4, mm3                         //   Mask = Mask AND Mask24bit
		pmaddwd   mm4, mm1                         //   Mask = multiply and add Mask by One
		packssdw  mm4, mm4                         //   Pack Mask and Mask into Mask
		pmaddwd   mm4, mm1                         //   Mask = multiply and add Mask by One
		movd      mm7, [EDX]                       //   PixelB = memory[EDX]
		packssdw  mm4, mm4                         //   Pack Mask and Mask into Mask
		psllw     mm4, 5                           //   Shift Mask left by 5
		pmulhw    mm4, mm0                         //   Mask = Mask * MaskMult (high-order)
		punpcklbw mm7, mm5                         //   Unpack PixelB and Zero into PixelB (low-order)
		psllw     mm7, 3                           //   Shift PixelB left by 3
		pmulhw    mm7, mm4                         //   PixelB = PixelB * Mask (high-order)
		psubw     mm6, mm4                         //   InvMask = InvMask - Mask
		movd      mm4, [EAX]                       //   PixelA = memory[EAX]
		add       EAX, 4                           //   Add 4 to EAX
		punpcklbw mm4, mm5                         //   Unpack PixelA and Zero into PixelA (low-order)
		add       EDX, 4                           //   Add 4 to EDX
		psllw     mm4, 3                           //   Shift PixelA left by 3
		pmulhw    mm4, mm6                         //   PixelA = PixelA * InvMask (high-order)
		add       ESI, 4                           //   Add 4 to ESI
		paddw     mm4, mm7                         //   PixelA = PixelA + PixelB
		packuswb  mm4, mm5                         //   Pack PixelA and Zero into PixelA
		movd      [EDI], mm4                       //   memory[EDI] = PixelA
		add       EDI, 4                           //   Add 4 to EDI
		dec       ECX                              //   Decrease ECX
		jnz       $1                               //   Jump to $1 if ECX is not zero
		emms                                       //   Empty MMX state
	}
#else
	int	nLoops = m_FrameBytes >> 2;
	for (int i = 0; i < nLoops; i++) {
		float	fMask = float(pInMask[0] + pInMask[1] + pInMask[2]);
		fMask /= 765;
		if (m_NegateMask)
			fMask = 1 - fMask;
		float	fScaleMask = fMask * m_MaskOpacity;
		float	fInvScaleMask = 1 - fScaleMask;
		pOut[0] = round(pInA[0] * fInvScaleMask + pInB[0] * fScaleMask);
		pOut[1] = round(pInA[1] * fInvScaleMask + pInB[1] * fScaleMask);
		pOut[2] = round(pInA[2] * fInvScaleMask + pInB[2] * fScaleMask);
		pInA += 4;
		pInB += 4;
		pInMask += 4;
		pOut += 4;
	}
#endif
	return(FF_SUCCESS);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	return(FF_FAIL);
}
