// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo
        02      18jul11	mask mixer

		freeframe source plugin's surrogate main frame window
 
*/

#ifndef CMAINFRAME_INCLUDED
#define CMAINFRAME_INCLUDED

#include "FreeFrame.h"

struct VideoInfoStructTag;

class CMainFrame {
public:
// Construction
	CMainFrame();
	~CMainFrame();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants

// Attributes

// Operations
	DWORD	processFrame(LPVOID pFrame);
	DWORD	processFrameCopy(ProcessFrameCopyStruct *pParam);

protected:
// Types
	struct INPUT_SEL {
		int		A;
		int		B;
		int		Mask;
	};

// Constants
	enum {
		MASK_MODES = 6
	};
	static const INPUT_SEL m_InputSel[MASK_MODES];
	
// Member data
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	LONG	m_FrameBytes;		// size of frame in bytes
	LONG	m_BytesPerPixel;	// number of bytes per pixel
	float	m_MaskOpacity;		// effect strength
	int		m_MaskMode;			// input selector
	bool	m_NegateMask;		// if true, invert mask

// Helpers
};

#endif
