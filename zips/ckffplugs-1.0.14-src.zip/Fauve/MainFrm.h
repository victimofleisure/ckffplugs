// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
        02		28dec11	fauve plugin

		freeframe plugin's surrogate main frame window
 
*/

#ifndef CMAINFRAME_INCLUDED
#define CMAINFRAME_INCLUDED

#include "FreeFrame.h"
#include <afxtempl.h>

struct VideoInfoStructTag;

class CMainFrame {
public:
// Construction
	CMainFrame();
	~CMainFrame();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants

// Attributes

// Operations
	DWORD	processFrame(LPVOID pFrame);

protected:
// Types
	typedef struct tagMYBITMAPINFO : BITMAPINFO {
		// The bmiColors array allocates a single DWORD, but in 16-bit mode,
		// bmiColors needs to contain three DWORDs: one DWORD each for the red,
		// green and blue color masks.  So we inherit from BITMAPINFO and add 
		// space for the green and blue masks; the red mask is bmiColors[0].
		DWORD	GreenMask;
		DWORD	BlueMask;
	} MYBITMAPINFO;

// Constants

// Plugin member data
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	MYBITMAPINFO	m_bmi;		// frame DIB info
	LONG	m_FrameBytes;		// size of frame in bytes
	LONG	m_BytesPerPixel;	// number of bytes per pixel

// App member data
	enum {	// display modes
		DM_LUMA,			// luma only
		DM_RGB,				// R, G, B
		DISPLAY_MODES
	};
	enum {	// channels
		R,
		G,
		B,
		LUMA,
		CHANS,
		COLOR_CHANS = LUMA,
	};
	enum {	// video modes
		VIDEO_MODE_16,
		VIDEO_MODE_24,
		VIDEO_MODE_32,
		VIDEO_MODES
	};
	static const int	m_ModeChanRange[VIDEO_MODES][CHANS];	// channel range per mode
	static const int	m_SampleBufSize[VIDEO_MODES];	// buffer size per mode, in elements
	CDWordArray	m_SampleBuf;	// pixel count sample buffer
	DWORD	*m_ChanSample[CHANS];	// pixel counts for each channel
	int		m_ChanRange[CHANS];	// range of each channel
	int		m_Mode;				// display mode

// Helpers
};

#endif
