// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		30dec06	make top-down DIB conditional
		03		12jul11	fix Init handle leak; create DIB with m_hDC, not GetDC
        04		28dec11	fauve plugin

		freeframe plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"

#define	USE_ASM_CALC	1

#define BGR(b, g, r) ((b & 0xff) | ((g & 0xff) << 8) | ((r & 0xff) << 16))

#define GETB(c) LOBYTE(c)
#define GETG(c) HIBYTE(c)
#define GETR(c) LOBYTE(HIWORD(c))

#define BGR16(b, g, r) WORD(((b & 0x1f) | ((g & 0x3f) << 5) | ((r & 0x1f) << 11)))

#define GETB16(c) (c & 0x1f)
#define GETG16(c) ((c >> 5) & 0x3f)
#define GETR16(c) ((c >> 11) & 0x1f)

static const int CHAN_MASK16[] = {0x1f, 0x3f, 0x1f};

const int CMainFrame::m_ModeChanRange[VIDEO_MODES][CHANS] = {
	{	// 16-bit 5-6-5
		(1 << 5), 
		(1 << 6), 
		(1 << 5), 
		(1 << 5) + (1 << 6) + (1 << 5) - 2
	},
	{	// 24-bit
		(1 << 8),
		(1 << 8),
		(1 << 8),
		(1 << 8) * 3 - 2
	},
	{	// 32-bit
		(1 << 8),
		(1 << 8),
		(1 << 8),
		(1 << 8) * 3 - 2
	}
};

const int CMainFrame::m_SampleBufSize[VIDEO_MODES] = {
	{
		m_ModeChanRange[VIDEO_MODE_16][R] + 
		m_ModeChanRange[VIDEO_MODE_16][G] + 
		m_ModeChanRange[VIDEO_MODE_16][B] + 
		m_ModeChanRange[VIDEO_MODE_16][LUMA]
	},
	{
		m_ModeChanRange[VIDEO_MODE_24][R] + 
		m_ModeChanRange[VIDEO_MODE_24][G] + 
		m_ModeChanRange[VIDEO_MODE_24][B] + 
		m_ModeChanRange[VIDEO_MODE_24][LUMA]
	},
	{
		m_ModeChanRange[VIDEO_MODE_32][R] + 
		m_ModeChanRange[VIDEO_MODE_32][G] + 
		m_ModeChanRange[VIDEO_MODE_32][B] + 
		m_ModeChanRange[VIDEO_MODE_32][LUMA]
	}
};

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	ZeroMemory(&m_bmi, sizeof(m_bmi));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	// app-specific
	m_Mode = 1;
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	int	samps = m_SampleBufSize[m_VideoInfo.bitDepth];
	m_SampleBuf.SetSize(samps);
	DWORD	*pSamp = m_SampleBuf.GetData();
	memcpy(m_ChanRange, m_ModeChanRange[m_VideoInfo.bitDepth], sizeof(m_ChanRange));
	for (int i = 0; i < CHANS; i++) {
		m_ChanSample[i] = pSamp;
		pSamp += m_ChanRange[i];
	}
	return(TRUE);
}

inline DWORD CalcMaxSample(const DWORD *pSample, int Samples)
{
	DWORD	MaxVal = 0;
	for (int i = 0; i < Samples; i++) {
		if (pSample[i] > MaxVal)
			MaxVal = pSample[i];
	}
	return(MaxVal);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	// clear sample buffer
	ZeroMemory(m_SampleBuf.GetData(), m_SampleBuf.GetSize() * sizeof(DWORD));
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		{
			const SHORT	*pSrc = (SHORT *)pFrame;
			int	ws = m_FrameBytes >> 1;
			if (USE_ASM_CALC) {
				if (m_Mode == DM_LUMA) {
					DWORD	*pLuma = m_ChanSample[LUMA];
					__asm {
						mov		ecx, ws		// init loop count
						mov		esi, pSrc	// init frame pointer
						mov		edi, pLuma	// init sample pointer to luma
					$Calc16BitLumaTop:
						mov		ax, [esi]	// get 16-bit 5-6-5 pixel from frame
						add		esi, 2		// bump frame pointer
						mov		ebx, eax	// save pixel
						and		eax, 01fh	// isolate pixel's blue level
						mov		edx, eax	// init luma sum to blue level
						mov		eax, ebx	// restore pixel
						shr		eax, 5		// get pixel's green level
						and		eax, 03fh	// isolate pixel's green level
						add		edx, eax	// add green level to luma sum
						shr		ebx, 11		// get pixel's red level
						and		ebx, 01fh	// isolate pixel's red level
						add		edx, ebx	// add red level to luma sum
						inc		dword ptr [edi+edx*4]	// bump luma level's count
						dec		ecx
						jne		$Calc16BitLumaTop
					}
				} else {	// RGB mode
					DWORD	*pBlue = m_ChanSample[B];
					__asm {
						mov		ecx, ws		// init loop count
						mov		esi, pSrc	// init frame pointer
						mov		edi, pBlue	// init sample pointer to blue
					$Calc16BitRGBTop:
						mov		ax, [esi]	// get 16-bit 5-6-5 pixel from frame
						add		esi, 2		// bump frame pointer
						mov		ebx, eax	// save pixel
						and		eax, 01fh	// isolate pixel's blue level
						inc		dword ptr [edi+eax*4]	// bump blue level's count
						sub		edi, 256	// offset sample pointer to green
						mov		eax, ebx	// restore pixel
						shr		eax, 5		// get pixel's green level
						and		eax, 03fh	// isolate pixel's green level
						inc		dword ptr [edi+eax*4]	// bump green level's count
						sub		edi, 128	// offset sample pointer to red
						shr		ebx, 11		// get pixel's red level
						and		ebx, 01fh	// isolate pixel's red level
						inc		dword ptr [edi+ebx*4]	// bump red level's count
						add		edi, 384	// offset sample pointer to back to blue
						dec		ecx
						jne		$Calc16BitRGBTop
					}
				}
			} else {	// no assembler
				if (m_Mode == DM_LUMA) {
					for (int i = 0; i < ws; i++) {
						SHORT	pix = *pSrc++;
						BYTE	b = GETB16(pix);
						BYTE	g = GETG16(pix);
						BYTE	r = GETR16(pix);
						int	luma = r + g + b;
						m_ChanSample[LUMA][luma]++;
					}
				} else {	// RGB mode
					for (int i = 0; i < ws; i++) {
						SHORT	pix = *pSrc++;
						BYTE	b = GETB16(pix);
						BYTE	g = GETG16(pix);
						BYTE	r = GETR16(pix);
						m_ChanSample[R][r]++;
						m_ChanSample[G][g]++;
						m_ChanSample[B][b]++;
					}
				}
			}
		}
		break;
	case FF_CAP_24BITVIDEO:
		{
			const BYTE	*pSrc = (BYTE *)pFrame;
			int	bs = m_FrameBytes / 3;
			if (USE_ASM_CALC) {
				if (m_Mode == DM_LUMA) {
					DWORD	*pLuma = m_ChanSample[LUMA];
					__asm {
						mov		ecx, bs		// init loop count
						mov		esi, pSrc	// init frame pointer
						mov		edi, pLuma	// init sample pointer to luma
						xor		eax, eax	// zero high bytes
					$Calc24BitLumaTop:
						mov		al, [esi]	// get pixel's blue level
						inc		esi			// bump frame pointer
						mov		edx, eax	// init luma sum to blue level
						mov		al, [esi]	// get pixel's green level
						inc		esi			// bump frame pointer
						add		edx, eax	// add green level to luma sum
						mov		al, [esi]	// get pixel's red level
						inc		esi			// bump frame pointer
						add		edx, eax	// add red level to luma sum
						inc		dword ptr [edi+edx*4]	// bump luma level's count
						dec		ecx
						jne		$Calc24BitLumaTop
					}
				} else {	// RGB mode
					DWORD	*pBlue = m_ChanSample[B];
					__asm {
						mov		ecx, bs		// init loop count
						mov		esi, pSrc	// init frame pointer
						mov		edi, pBlue	// init sample pointer to blue
						xor		eax, eax	// zero high bytes
					$Calc24BitRGBTop:
						mov		al, [esi]	// get pixel's blue level
						inc		esi			// bump frame pointer
						inc		dword ptr [edi+eax*4]	// bump blue level's count
						sub		edi, 1024	// offset sample pointer to green
						mov		al, [esi]	// get pixel's green level
						inc		esi			// bump frame pointer
						inc		dword ptr [edi+eax*4]	// bump green level's count
						sub		edi, 1024	// offset sample pointer to red
						mov		al, [esi]	// get pixel's red level
						inc		esi			// bump frame pointer
						inc		dword ptr [edi+eax*4]	// bump red level's count
						add		edi, 2048	// offset sample pointer back to blue
						dec		ecx
						jne		$Calc24BitRGBTop
					}
				}
			} else {
				if (m_Mode == DM_LUMA) {
					for (int i = 0; i < bs; i++) {
						BYTE	b = *pSrc++;
						BYTE	g = *pSrc++;
						BYTE	r = *pSrc++;
						int	luma = r + g + b;
						m_ChanSample[LUMA][luma]++;
					}
				} else {	// RGB mode
					for (int i = 0; i < bs; i++) {
						BYTE	b = *pSrc++;
						BYTE	g = *pSrc++;
						BYTE	r = *pSrc++;
						m_ChanSample[R][r]++;
						m_ChanSample[G][g]++;
						m_ChanSample[B][b]++;
						int	luma = r + g + b;
						m_ChanSample[LUMA][luma]++;
					}
				}
			}
		}
		break;
	case FF_CAP_32BITVIDEO:
		{
			const DWORD	*pSrc = (DWORD *)pFrame;
			int	dws = m_FrameBytes >> 2;
			if (USE_ASM_CALC) {
				if (m_Mode == DM_LUMA) {
					DWORD	*pLuma = m_ChanSample[LUMA];
					__asm {
						mov		ecx, dws	// init loop count
						mov		esi, pSrc	// init frame pointer
						mov		edi, pLuma	// init sample pointer to luma
					$Calc32BitLumaTop:
						mov		eax, [esi]	// get 32-bit pixel from frame
						add		esi, 4		// bump frame pointer
						mov		ebx, eax	// save pixel
						and		eax, 0ffh	// isolate pixel's blue level
						mov		edx, eax	// init luma sum to blue level
						mov		eax, ebx	// restore pixel
						shr		eax, 8		// get pixel's green level
						and		eax, 0ffh	// isolate pixel's green level
						add		edx, eax	// add green level to luma sum
						shr		ebx, 16		// get pixel's red level
						and		ebx, 0ffh	// isolate pixel's red level
						add		edx, ebx	// add red level to luma sum
						inc		dword ptr [edi+edx*4]	// bump luma level's count
						dec		ecx
						jne		$Calc32BitLumaTop
					}
				} else {	// RGB mode
					DWORD	*pBlue = m_ChanSample[B];
					__asm {
						mov		ecx, dws	// init loop count
						mov		esi, pSrc	// init frame pointer
						mov		edi, pBlue	// init sample pointer to blue
					$Calc32BitRGBTop:
						mov		eax, [esi]	// get 32-bit pixel from frame
						add		esi, 4		// bump frame pointer
						mov		ebx, eax	// save pixel
						and		eax, 0ffh	// isolate pixel's blue level
						inc		dword ptr [edi+eax*4]	// bump blue level's count
						sub		edi, 1024	// offset sample pointer to green
						mov		eax, ebx	// restore pixel
						shr		eax, 8		// get pixel's green level
						and		eax, 0ffh	// isolate pixel's green level
						inc		dword ptr [edi+eax*4]	// bump green level's count
						sub		edi, 1024	// offset sample pointer to red
						shr		ebx, 16		// get pixel's red level
						and		ebx, 0ffh	// isolate pixel's red level
						inc		dword ptr [edi+ebx*4]	// bump red level's count
						add		edi, 2048	// offset sample pointer back to blue
						dec		ecx
						jne		$Calc32BitRGBTop
					}
				}
			} else {	// no assembler
				if (m_Mode == DM_LUMA) {
					for (int i = 0; i < dws; i++) {
						DWORD	pix = *pSrc++;
						BYTE	b = GETB(pix);
						BYTE	g = GETG(pix);
						BYTE	r = GETR(pix);
						int	luma = r + g + b;
						m_ChanSample[LUMA][luma]++;
					}
				} else {	// RGB mode
					for (int i = 0; i < dws; i++) {
						DWORD	pix = *pSrc++;
						BYTE	b = GETB(pix);
						BYTE	g = GETG(pix);
						BYTE	r = GETR(pix);
						m_ChanSample[R][r]++;
						m_ChanSample[G][g]++;
						m_ChanSample[B][b]++;
					}
				}
			}
		}
		break;
	}
	if (m_Mode == DM_LUMA) {
		switch (m_VideoInfo.bitDepth) {
		case FF_CAP_16BITVIDEO:
			{
				int	range = m_ChanRange[LUMA];
				DWORD	*sample = m_ChanSample[LUMA];
				DWORD	MaxCount = CalcMaxSample(sample, range);
				int	i;
				for (i = 0; i < range; i++) {
					int	val = round(double(sample[i]) / MaxCount * 0x3f);
					sample[i] = BGR16(val >> 1, val, val >> 1);
				}
				int	ws = m_FrameBytes >> 1;
				WORD	*pSrc = (WORD *)pFrame;
				for (i = 0; i < ws; i++) {
					WORD	pix = *pSrc;
					BYTE	b = GETB16(pix);
					BYTE	g = GETG16(pix);
					BYTE	r = GETR16(pix);
					int	luma = r + g + b;
					*pSrc = WORD(sample[luma]);
					pSrc++;
				}
			}
			break;
		case FF_CAP_24BITVIDEO:
			{
				int	range = m_ChanRange[LUMA];
				DWORD	*sample = m_ChanSample[LUMA];
				DWORD	MaxCount = CalcMaxSample(sample, range);
				int	i;
				for (i = 0; i < range; i++) {
					int	val = round(double(sample[i]) / MaxCount * 0xff);
					sample[i] = BGR(val, val, val);
				}
				int	bs = m_FrameBytes / 3;
				BYTE	*pSrc = (BYTE *)pFrame;
				for (i = 0; i < bs; i++) {
					BYTE	b = pSrc[0];
					BYTE	g = pSrc[1];
					BYTE	r = pSrc[2];
					int	luma = r + g + b;
					int	val = sample[luma];
					*pSrc++ = GETB(val);
					*pSrc++ = GETG(val);
					*pSrc++ = GETR(val);
				}
			}
			break;
		case FF_CAP_32BITVIDEO:
			{
				int	range = m_ChanRange[LUMA];
				DWORD	*sample = m_ChanSample[LUMA];
				DWORD	MaxCount = CalcMaxSample(sample, range);
				int	i;
				for (i = 0; i < range; i++) {
					int	val = round(double(sample[i]) / MaxCount * 0xff);
					sample[i] = BGR(val, val, val);
				}
				int	dws = m_FrameBytes >> 2;
				DWORD	*pSrc = (DWORD *)pFrame;
				for (i = 0; i < dws; i++) {
					DWORD	pix = *pSrc;
					BYTE	b = GETB(pix);
					BYTE	g = GETG(pix);
					BYTE	r = GETR(pix);
					int	luma = r + g + b;
					*pSrc = sample[luma];
					pSrc++;
				}
			}
			break;
		}
	} else {	// RGB mode
		switch (m_VideoInfo.bitDepth) {
		case FF_CAP_16BITVIDEO:
			{
				for (int j = 0; j < COLOR_CHANS; j++) {
					int	range = m_ChanRange[j];
					DWORD	*sample = m_ChanSample[j];
					DWORD	MaxCount = CalcMaxSample(sample, range);
					int	ChanMask = CHAN_MASK16[j];
					for (int i = 0; i < range; i++) {
						sample[i] = round(double(sample[i]) / MaxCount * ChanMask);
					}
				}
				int	ws = m_FrameBytes >> 1;
				WORD	*pSrc = (WORD *)pFrame;
				for (int i = 0; i < ws; i++) {
					WORD	pix = *pSrc;
					BYTE	b = GETB16(pix);
					BYTE	g = GETG16(pix);
					BYTE	r = GETR16(pix);
					*pSrc = BGR16(m_ChanSample[B][b], m_ChanSample[G][g], m_ChanSample[R][r]);
					pSrc++;
				}
			}
			break;
		case FF_CAP_24BITVIDEO:
			{
				for (int j = 0; j < COLOR_CHANS; j++) {
					int	range = m_ChanRange[j];
					DWORD	*sample = m_ChanSample[j];
					DWORD	MaxCount = CalcMaxSample(sample, range);
					for (int i = 0; i < range; i++) {
						sample[i] = round(double(sample[i]) / MaxCount * 0xff);
					}
				}
				int	bs = m_FrameBytes / 3;
				BYTE	*pSrc = (BYTE *)pFrame;
				for (int i = 0; i < bs; i++) {
					BYTE	b = pSrc[0];
					BYTE	g = pSrc[1];
					BYTE	r = pSrc[2];
					*pSrc++ = BYTE(m_ChanSample[B][b]);
					*pSrc++ = BYTE(m_ChanSample[G][g]);
					*pSrc++ = BYTE(m_ChanSample[R][r]);
				}
			}
			break;
		case FF_CAP_32BITVIDEO:
			{
				for (int j = 0; j < COLOR_CHANS; j++) {
					int	range = m_ChanRange[j];
					DWORD	*sample = m_ChanSample[j];
					DWORD	MaxCount = CalcMaxSample(sample, range);
					for (int i = 0; i < range; i++) {
						sample[i] = round(double(sample[i]) / MaxCount * 0xff);
					}
				}
				int	dws = m_FrameBytes >> 2;
				DWORD	*pSrc = (DWORD *)pFrame;
				for (int i = 0; i < dws; i++) {
					DWORD	pix = *pSrc;
					BYTE	b = GETB(pix);
					BYTE	g = GETG(pix);
					BYTE	r = GETR(pix);
					*pSrc = BGR(m_ChanSample[B][b], m_ChanSample[G][g], m_ChanSample[R][r]);
					pSrc++;
				}
			}
			break;
		}
	}
	return(FF_SUCCESS);
}
