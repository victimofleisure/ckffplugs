// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      28oct07	specialize demo

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	m_Enable = TRUE;
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	return(TRUE);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	if (m_Enable)
		Invert(pFrame, m_FrameBytes);
	return(FF_SUCCESS);
}

DWORD CMainFrame::processFrameCopy(ProcessFrameCopyStruct *pParam)
{
	return(FF_FAIL);
}

void CMainFrame::Invert(PVOID pFrame, int FrameBytes)
{
	__asm {
		mov		ebx, pFrame
		mov		ecx, FrameBytes
		shr		ecx, 2				; number of dwords
		je		$2					; skip if zero
$1:
		not		dword ptr [ebx]		; invert dword
		add		ebx, 4				; bump pointer
		loop	$1
$2:
		mov		ecx, FrameBytes
		and		ecx, 3				; number of extra bytes
		je		$4					; skip if zero
$3:
		not		byte ptr [ebx]		; invert byte
		inc		ebx					; bump pointer
		loop	$3
$4:
	}
}
