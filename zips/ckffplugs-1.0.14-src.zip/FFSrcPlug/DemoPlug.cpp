// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		04jan08	add description and about text

		freeframe source plugin demo
 
*/

#include <stdafx.h>
#include "DemoPlug.h"
#include <math.h>

const PlugInfoStruct PlugInfo = {
	1,	// API major version; don't change
	0,	// API minor version; don't change
// TODO: edit ID and title; these are NOT null-terminated strings, keep same length
	{'D', 'S', 'R', 'C'},	// plugin identifier; MUST be 4 bytes
	{'F', 'F', 'S', 'r', 'c', 'D', 'e', 'm',
	 'o', ' ', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title; MUST be 16 bytes
	1	// source plugin
};

const PlugExtendedInfoStruct PlugExtInfo = {
// TODO: set the plugin version, description and about text
	1,		// plugin major version
	0,		// plugin minor version
	"Freeframe Source Plugin Demo",	// description; this IS a null-terminated string
	"Copyleft 2008 Chris Korda",	// about text; this IS a null-terminated string
	0,		// extended data size
	NULL	// extended data block
};

const DemoPlug::ParamConstantsStruct paramConstants[DemoPlug::NUM_PARAMS] = {
// TODO: add default values and names of your plugin's parameters here
//			 1234567890123456		these MUST be 16 bytes long, padded with blanks
	{.5,	"Ball Speed      "},
};

PlugInfoStruct* getInfo() 
{
	return const_cast<PlugInfoStruct *>(&PlugInfo);
}

DWORD initialise()
{
	return FF_SUCCESS;
}

DWORD deInitialise()
{
	return FF_SUCCESS;
}

DWORD getNumParameters()
{
	return DemoPlug::NUM_PARAMS;  
}

char* getParameterName(DWORD index)
{
	if (index >= 0 && index < DemoPlug::NUM_PARAMS)
		return const_cast<char *>(paramConstants[index].name);
	return "                ";
}

float getParameterDefault(DWORD index)
{
	if (index >= 0 && index < DemoPlug::NUM_PARAMS)
		return paramConstants[index].defaultValue;
	return 0;
}

DemoPlug::DemoPlug()
{
	for (int i = 0; i < NUM_PARAMS; i++) {
		m_Param[i].value = paramConstants[i].defaultValue;	// init to default values
		memset(m_Param[i].displayValue, ' ', MAX_STRING);
	}
}

DemoPlug::~DemoPlug()
{
}

char* DemoPlug::getParameterDisplay(DWORD index)
{
	memset(m_Param[index].displayValue, ' ', MAX_STRING);
	if (index >= 0 && index < NUM_PARAMS) {
		CString	s;
		s.Format("%g", m_Param[index].value);
		memcpy(m_Param[index].displayValue, s, min(s.GetLength(), MAX_STRING));
	}
	return m_Param[index].displayValue;
}

DWORD DemoPlug::setParameter(SetParameterStruct* pParam)
{
	int	index = pParam->index;
	if (index >= 0 && index < NUM_PARAMS) {
		float	val = pParam->value;
		m_Param[index].value = val;
		// TODO: pass parameters to MainFrame here
		switch (index) {
		case BALL_SPEED:
			m_View.SetSpeed(val);
			break;
		}
		return FF_SUCCESS;
	}
	return FF_FAIL;
}

float DemoPlug::getParameter(DWORD index)
{
	if (index >= 0 && index < NUM_PARAMS)
		return m_Param[index].value;
	return 0;
}

DWORD DemoPlug::processFrameCopy(ProcessFrameCopyStruct* pFrameData)
{
	return FF_FAIL;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case FF_CAP_16BITVIDEO:
		return FF_TRUE;

	case FF_CAP_24BITVIDEO:
		return FF_TRUE;

	case FF_CAP_32BITVIDEO:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_FALSE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return DemoPlug::NUM_INPUT_FRAMES;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return DemoPlug::NUM_INPUT_FRAMES;

	case FF_CAP_COPYORINPLACE:
		return FF_FALSE;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	// this shouldn't happen if the host is checking the capabilities properly
	if (pVideoInfo->bitDepth < 0 || pVideoInfo->bitDepth > 2)
		return (LPVOID) FF_FAIL;

	DemoPlug *pPlugObj = new DemoPlug;

	if (!pPlugObj->Init(*pVideoInfo)) {
		delete pPlugObj;
		return NULL;
	}

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	DemoPlug *pPlugObj = (DemoPlug*) instanceID;
	delete pPlugObj;	// delete first, THEN set to null (duh!)
	pPlugObj = NULL;	// mark instance deleted
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	return (LPVOID) &PlugExtInfo;
}
