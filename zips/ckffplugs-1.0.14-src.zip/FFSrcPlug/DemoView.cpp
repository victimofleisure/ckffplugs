// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version

		freeframe source plugin's surrogate view - demo draws a bouncing ball
 
*/

// DemoView.cpp : implementation of the CDemoView class
//

#include "stdafx.h"
#include "DemoView.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoView

CDemoView::CDemoView()
{
	m_Size = CSize(0, 0);
	m_Pos = CPoint(0, 0);
	m_BallDiam = 50;
	m_Delta = CPoint(1, 1);
	m_Speed = .5;
}

CDemoView::~CDemoView()
{
}

void CDemoView::Draw(HDC dc)
{
	// TODO: add your drawing code here
	// erase frame
	SetBkColor(dc, RGB(0, 0, 0));	// background color
	CRect	r(0, 0, m_Size.cx, m_Size.cy);
	ExtTextOut(dc, 0, 0, ETO_OPAQUE, r, NULL, 0, NULL);	// as in CDC::FillSolidRect
	// draw ball
	CBrush	b(RGB(255, 0, 0));
	SelectObject(dc, b);
	r = CRect(m_Pos, m_Pos + CSize(m_BallDiam, m_BallDiam));
	Ellipse(dc, r.left, r.top, r.right, r.bottom);
	// update ball's position
	double	scale = pow(10, m_Speed);
	CPoint	TestPos;
	TestPos.x = m_Pos.x + round(m_Delta.x * scale);
	TestPos.y = m_Pos.y + round(m_Delta.y * scale);
	if (TestPos.x < 0 || TestPos.x >= m_Size.cx - m_BallDiam)
		m_Delta.x = -m_Delta.x;
	if (TestPos.y < 0 || TestPos.y >= m_Size.cy - m_BallDiam)
		m_Delta.y = -m_Delta.y;
	m_Pos.x += round(m_Delta.x * scale);
	m_Pos.y += round(m_Delta.y * scale);
}

void CDemoView::SetWndSize(CSize sz)
{
	m_Size = sz;
}
