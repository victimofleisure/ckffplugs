// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version

		freeframe source plugin's surrogate view - demo draws a bouncing ball
 
*/

// DemoView.h : interface of the CDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEMOVIEW_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
#define AFX_DEMOVIEW_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDemoView window

class CDemoView
{
// Construction
public:
	CDemoView();

// Constants

// Types

// Attributes
	void	SetSpeed(float Speed);
	float	GetSpeed() const;

// Operations
	void	SetWndSize(CSize sz);
	void	Draw(HDC dc);

// Overrides

// Implementation
public:
	virtual ~CDemoView();

// Generated message map functions
protected:

// Types

// Constants

// Member data
	CSize	m_Size;		// frame size, in pixels
	CPoint	m_Pos;		// ball's current position
	CPoint	m_Delta;	// direction vector
	int		m_BallDiam;	// ball's diameter
	float	m_Speed;	// normalized speed (0..1)

// Helpers
};

inline void CDemoView::SetSpeed(float Speed)
{
	m_Speed = Speed;
}

inline float CDemoView::GetSpeed() const
{
	return(m_Speed);
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEMOVIEW_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
