// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      08dec06	initial version
		01		15dec06	add invert

		wave generator view
 
*/

// WaveGenView.h : interface of the CWaveGenView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WAVEGENVIEW_H__D25E8390_078F_4A58_BB12_EA70E9806A78__INCLUDED_)
#define AFX_WAVEGENVIEW_H__D25E8390_078F_4A58_BB12_EA70E9806A78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Oscillator.h"

#ifndef FFPLUGIN

#include "BackBufDD.h"

class CWaveGenView : public CView
{
	DECLARE_DYNCREATE(CWaveGenView)
#else
class CWaveGenView
{
#endif
public:
	CWaveGenView();

// Constants
	enum {	// modulation types
		MOD_NONE,
		MOD_FREQ,
		MOD_AMP,
		MOD_PULSE,
		MOD_TYPES
	};
	enum {	// draw modes
		DM_LINE,
		DM_FILL,
		DRAW_MODES
	};

// Public data
	static	CWaveGenView	*m_View;

// Attributes
public:
	void	SetTimerFreq(double Freq);
	void	SetCarWave(int Wave);
	void	SetCarFreq(double Freq);
	void	SetCarAmp(double Amp);
	void	SetCarPulseWidth(double Width);
	void	SetCarPhaseShift(double Shift);
	void	SetModType(int Type);
	void	SetModWave(int Wave);
	void	SetModFreq(double Freq);
	void	SetModAmp(double Amp);
	void	SetModPulseWidth(double Width);
	void	SetModPhaseShift(double Shift);
	void	SetZoom(double Zoom);
	void	SetFrameSize(CSize Size);
	void	SetWaveColor(COLORREF Color);
	void	SetDrawMode(int Mode);
	void	SetEraseBkgnd(bool Enable);
	void	SetLineWidth(int Width);
	void	ShowOrigin(bool Show);
	void	SetVertical(bool Enable);
	void	SetInvert(bool Enable);
	void	SetExclusive(bool Enable);
	bool	IsExclusive() const;

// Operations
public:
	void	Draw(HDC dc);

#ifndef FFPLUGIN
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWaveGenView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWaveGenView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWaveGenView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
#else
	~CWaveGenView();
#endif

// Constants
	enum {
		MAX_POLY_POINTS = 1000	// do PolyLine in blocks of this size
	};
	static const COLORREF m_BkColor;	// background color

// Member data
#ifndef FFPLUGIN
	CBackBufDD	m_dd;		// DirectDraw back buffer
#endif
	COscillator	m_Car;		// carrier oscillator
	COscillator	m_Mod;		// modulator oscillator
	CPen	m_WavePen;		// pen for drawing wave
	CBrush	m_WaveBrush;	// brush for filling wave
	POINT	m_pta[MAX_POLY_POINTS];	// point array for PolyLine
	int		m_pts;			// number of points in array
	double	m_TimerFreq;	// timer frequency in Hertz
	int		m_CarWave;		// carrier waveform; see COscillator
	double	m_CarFreq;		// carrier frequency, in Hertz
	double	m_CarAmp;		// carrier amplitude
	double	m_CarPulseWidth;// carrier pulse width
	double	m_CarPhaseShift;// carrier phase shift delta
	int		m_ModType;		// modulation type; see enum above
	double	m_ModAmp;		// modulation amplitude
	double	m_ModPhaseShift;// modulator phase shift delta
	CSize	m_FrmSz;		// frame size, in logical coords
	double	m_Zoom;			// magnification; 1 = normal
	int		m_DrawMode;		// drawing mode; see enum above
	int		m_LineWidth;	// line width, in logical coords
	bool	m_ShowOrg;		// if true, show origin
	bool	m_DrawVert;		// if true, draw wave vertically
	bool	m_EraseBkgnd;	// if true, erase background
	bool	m_Invert;		// if true, invert filled area
	double	m_CarPos;		// carrier position, in timer ticks
	double	m_ModPos;		// modulator position, in timer ticks
	double	m_PrevCarFreq;	// previous carrier frequency
	COLORREF	m_WaveColor;	// wave color
	COLORREF	m_LineColor;	// wave pen color
	COLORREF	m_FillColor;	// wave brush color

// Helpers
	template<class T> void Swap(T& a, T& b) { T c = a; a = b; b = c; }
	void	MoveToSwap(HDC dc, int x, int y);
	void	LineToSwap(HDC dc, int x, int y);
	void	AddLineTo(HDC dc, POINT pt);
	static	double	Wrap(double Val, double Limit);
};

inline void CWaveGenView::SetCarAmp(double Amp)
{
	m_CarAmp = Amp;
}

inline void CWaveGenView::SetCarPhaseShift(double Shift)
{
	m_CarPhaseShift = Shift;
}

inline void CWaveGenView::SetModWave(int Wave)
{
	m_Mod.SetWaveform(Wave);
}

inline void CWaveGenView::SetModFreq(double Freq)
{
	m_Mod.SetFreq(Freq);
}

inline void CWaveGenView::SetModAmp(double Amp)
{
	m_ModAmp = Amp;
}

inline void CWaveGenView::SetModPulseWidth(double Width)
{
	m_Mod.SetPulseWidth(Width);
}

inline void CWaveGenView::SetModPhaseShift(double Shift)
{
	m_ModPhaseShift = Shift;
}

inline void CWaveGenView::SetZoom(double Zoom)
{
	m_Zoom = Zoom;
}

inline void CWaveGenView::SetFrameSize(CSize Size)
{
	m_FrmSz = Size;
}

inline void CWaveGenView::SetWaveColor(COLORREF Color)
{
	m_WaveColor = Color;
}

inline void CWaveGenView::SetDrawMode(int Mode)
{
	m_DrawMode = Mode;
}

inline void CWaveGenView::SetEraseBkgnd(bool Enable)
{
	m_EraseBkgnd = Enable;
}

inline void CWaveGenView::SetLineWidth(int Width)
{
	m_LineWidth = Width;
	m_LineColor = -1;	// force pen to be recreated
}

inline void CWaveGenView::ShowOrigin(bool Show)
{
	m_ShowOrg = Show;
}

inline void CWaveGenView::SetVertical(bool Enable)
{
	m_DrawVert = Enable;
}

inline void CWaveGenView::SetInvert(bool Enable)
{
	m_Invert = Enable;
}

#ifndef FFPLUGIN
inline bool CWaveGenView::IsExclusive() const
{
	return(m_dd.IsExclusive());
}
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAVEGENVIEW_H__D25E8390_078F_4A58_BB12_EA70E9806A78__INCLUDED_)
