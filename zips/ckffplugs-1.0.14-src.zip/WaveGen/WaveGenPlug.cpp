// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      08dec06	adapt demo for clip player
        02      15dec06	adjust parameter defaults
        03      27dec06	support 16-bit mode
        04      30dec06	bump version
        05	    12jul11	bump version

		wave generator plugin
 
*/

#include <stdafx.h>
#include "WaveGenPlug.h"
#include <math.h>
#include "Win32Console.h"

const PlugInfoStruct PlugInfo = {
	1,	// major version
	0,	// minor version
	{'W', 'V', 'G', 'N'},	// plugin identifier
	{'W', 'a', 'v', 'e', 'G', 'e', 'n', ' ',
	 ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title
	0	// source plugin, NOTE that this plug is an EFFECT
};

const PlugExtendedInfoStruct PlugExtInfo = {
	1,		// major version
	400,	// minor version
	"Wave Generator",	// description
	"Copyleft 2006 Chris Korda",	// about text
	0,		// extended data size
	NULL	// extended data block
};

const WaveGenPlug::ParamConstantsStruct paramConstants[WaveGenPlug::NUM_PARAMS] = {
// TODO: add default values and names of your plugin's parameters here
//			 1234567890123456
	{.2f,	"Car Waveform    "},
	{.5f,	"Car Frequency   "},
	{1,		"Car Amplitude   "},
	{.5f,	"Car Pulse Width "},
	{.5f,	"Car Phase Shift "},
	{.5f,	"Mod Type        "},
	{.2f,	"Mod Waveform    "},
	{.5,	"Mod Frequency   "},
	{1,		"Mod Amplitude   "},
	{.5f,	"Mod Pulse Width "},
	{.5f,	"Mod Phase Shift "},
	{.5f,	"Zoom            "},
	{0,		"Vertical        "},
	{1,		"Fill            "},
	{0,		"Erase Bkgnd     "},
	{.1f,	"Line Width      "},
	{0,		"Show Origin     "},
	{1,		"Red             "},
	{1,		"Green           "},
	{1,		"Blue            "},
	{0,		"Invert          "},
};

PlugInfoStruct* getInfo() 
{
	return const_cast<PlugInfoStruct *>(&PlugInfo);
}

DWORD initialise()
{
#ifdef _DEBUG
	Win32Console::Create();
#endif
	return FF_SUCCESS;
}

DWORD deInitialise()
{
	return FF_SUCCESS;
}

DWORD getNumParameters()
{
	return WaveGenPlug::NUM_PARAMS;  
}

char* getParameterName(DWORD index)
{
	if (index >= 0 && index < WaveGenPlug::NUM_PARAMS)
		return const_cast<char *>(paramConstants[index].name);
	return "                ";
}

float getParameterDefault(DWORD index)
{
	if (index >= 0 && index < WaveGenPlug::NUM_PARAMS)
		return paramConstants[index].defaultValue;
	return 0;
}

WaveGenPlug::WaveGenPlug()
{
	for (int i = 0; i < NUM_PARAMS; i++) {
		m_Param[i].value = paramConstants[i].defaultValue;
		memset(m_Param[i].displayValue, ' ', MAX_STRING);
	}
}

WaveGenPlug::~WaveGenPlug()
{
}

char* WaveGenPlug::getParameterDisplay(DWORD index)
{
	memset(m_Param[index].displayValue, ' ', MAX_STRING);
	if (index >= 0 && index < NUM_PARAMS) {
		CString	s;
		s.Format("%g", m_Param[index].value);
		memcpy(m_Param[index].displayValue, s, min(s.GetLength(), MAX_STRING));
	}
	return m_Param[index].displayValue;
}

static inline int ParmToEnum(float Val, int Enums)
{
	int ival = trunc(Val * Enums);
	return(min(ival, Enums - 1));
}

static inline double ParmToFreq(float Val)
{
	return(pow(10, (Val - .75) * 4));
}

static inline double ParmToPhaseShift(float Val)
{
	return((Val - .5) * 100);
}

static inline double ParmToZoom(float Val)
{
	return(pow(10, (Val - .5) * 2));
}

DWORD WaveGenPlug::setParameter(SetParameterStruct* pParam)
{
	int	index = pParam->index;
	if (index >= 0 && index < NUM_PARAMS) {
		float	val = pParam->value;
		m_Param[index].value = val;
		// TODO: pass parameters to MainFrame here
		switch (index) {
		case CAR_WAVEFORM:
			m_View.SetCarWave(ParmToEnum(val, COscillator::WAVEFORMS));
			break;
		case CAR_FREQUENCY:
			m_View.SetCarFreq(ParmToFreq(val));
			break;
		case CAR_AMPLITUDE:
			m_View.SetCarAmp(val);
			break;
		case CAR_PULSE_WIDTH:
			m_View.SetCarPulseWidth(val);
			break;
		case CAR_PHASE_SHIFT:
			m_View.SetCarPhaseShift(ParmToPhaseShift(val));
			break;
		case MOD_TYPE:
			m_View.SetModType(ParmToEnum(val, CWaveGenView::MOD_TYPES));
			break;
		case MOD_WAVEFORM:
			m_View.SetModWave(ParmToEnum(val, COscillator::WAVEFORMS));
			break;
		case MOD_FREQUENCY:
			m_View.SetModFreq(ParmToFreq(val));
			break;
		case MOD_AMPLITUDE:
			m_View.SetModAmp(val);
			break;
		case MOD_PULSE_WIDTH:
			m_View.SetModPulseWidth(val);
			break;
		case MOD_PHASE_SHIFT:
			m_View.SetModPhaseShift(ParmToPhaseShift(val));
			break;
		case ZOOM:
			m_View.SetZoom(ParmToZoom(val));
			break;
		case VERTICAL:
			m_View.SetVertical(val > 0);
			break;
		case FILL:
			m_View.SetDrawMode(val > 0);
			break;
		case ERASE_BKGND:
			m_EraseBkgnd = val > 0;
			m_View.SetEraseBkgnd(m_EraseBkgnd);
			break;
		case LINE_WIDTH:
			m_View.SetLineWidth(round(val * m_VideoInfo.frameHeight * .1) + 1);
			break;
		case SHOW_ORIGIN:
			m_View.ShowOrigin(val > 0);
			break;
		case COLOR_RED:
			m_Red = round(val * 255);
			m_View.SetWaveColor(RGB(m_Red, m_Green, m_Blue));
			break;
		case COLOR_GREEN:
			m_Green = round(val * 255);
			m_View.SetWaveColor(RGB(m_Red, m_Green, m_Blue));
			break;
		case COLOR_BLUE:
			m_Blue = round(val * 255);
			m_View.SetWaveColor(RGB(m_Red, m_Green, m_Blue));
			break;
		case INVERT:
			m_View.SetInvert(val > 0);
			break;
		}
		return FF_SUCCESS;
	}
	return FF_FAIL;
}

float WaveGenPlug::getParameter(DWORD index)
{
	if (index >= 0 && index < NUM_PARAMS)
		return m_Param[index].value;
	return 0;
}

DWORD WaveGenPlug::processFrameCopy(ProcessFrameCopyStruct* pFrameData)
{
	return FF_FAIL;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case FF_CAP_16BITVIDEO:
		return FF_TRUE;

	case FF_CAP_24BITVIDEO:
		return FF_TRUE;

	case FF_CAP_32BITVIDEO:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_FALSE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return WaveGenPlug::NUM_INPUT_FRAMES;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return WaveGenPlug::NUM_INPUT_FRAMES;

	case FF_CAP_COPYORINPLACE:
		return FF_FALSE;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	// this shouldn't happen if the host is checking the capabilities properly
	if (pVideoInfo->bitDepth < 0 || pVideoInfo->bitDepth > 2)
		return (LPVOID) FF_FAIL;

	WaveGenPlug *pPlugObj = new WaveGenPlug;

	if (!pPlugObj->Init(*pVideoInfo)) {
		delete pPlugObj;
		return NULL;
	}

	SetParameterStruct	sps;
	for (int i = 0; i < WaveGenPlug::NUM_PARAMS; i++) {
		sps.index = i;
		sps.value = paramConstants[i].defaultValue;
		pPlugObj->setParameter(&sps);
	}

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	WaveGenPlug *pPlugObj = (WaveGenPlug*) instanceID;
	delete pPlugObj;	// delete first, THEN set to null (duh!)
	pPlugObj = NULL;	// mark instance deleted
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	return (LPVOID) &PlugExtInfo;
}
