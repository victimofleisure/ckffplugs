// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      08dec06	adapt demo for clip player
        02      27dec06	support 16-bit mode
		03		30dec06	make top-down DIB conditional
		04		12jul11	fix Init handle leak; create DIB with m_hDC, not GetDC

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	ZeroMemory(&m_bmi, sizeof(m_bmi));
	m_hDC = NULL;
	m_hDib = NULL;
	m_DibBits = NULL;
	m_PrevBm = NULL;
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	m_EraseBkgnd = TRUE;
	m_Red = 255;
	m_Green = 255;
	m_Blue = 255;
	m_View.SetTimerFreq(25);
}

CMainFrame::~CMainFrame()
{
	if (m_PrevBm != NULL)
		SelectObject(m_hDC, m_PrevBm);	// restore DC's previous bitmap
	DeleteObject(m_hDib);
	DeleteObject(m_hDC);
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	m_hDC = CreateCompatibleDC(NULL);
	if (m_hDC == NULL)
		return(FALSE);
	ZeroMemory(&m_bmi, sizeof(m_bmi));
	m_bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	m_bmi.bmiHeader.biWidth = m_VideoInfo.frameWidth;
	m_bmi.bmiHeader.biHeight = LONG(m_VideoInfo.frameHeight);
	if (videoInfo.orientation != FF_ORIGIN_BOTTOM_LEFT)
		m_bmi.bmiHeader.biHeight = -m_bmi.bmiHeader.biHeight;	// top-down DIB
	m_bmi.bmiHeader.biPlanes = 1;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_bmi.bmiHeader.biBitCount = 16;
		m_bmi.bmiHeader.biCompression = BI_BITFIELDS;	// must be 5-6-5
		*(DWORD *)m_bmi.bmiColors = 0xF800;	// red color mask
		m_bmi.GreenMask = 0x07E0;	// green color mask
		m_bmi.BlueMask = 0x001F;	// blue color mask
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_bmi.bmiHeader.biBitCount = 24;
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_bmi.bmiHeader.biBitCount = 32;
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_hDib = CreateDIBSection(m_hDC, &m_bmi, DIB_RGB_COLORS, &m_DibBits, NULL, 0);
	if (m_hDib == NULL)
		return(FALSE);
	BITMAP	bm;	// check bitmap's actual size in bytes, just in case
	if (!GetObject(m_hDib, sizeof(bm), &bm))
		return(FALSE);
	if (bm.bmWidthBytes != LONG(m_VideoInfo.frameWidth) * m_BytesPerPixel)
		return(FALSE);
	m_PrevBm = SelectObject(m_hDC, m_hDib);
	if (m_PrevBm == NULL)
		return(FALSE);
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	m_View.SetFrameSize(CSize(m_VideoInfo.frameWidth, m_VideoInfo.frameHeight));
	return(TRUE);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	if (!m_EraseBkgnd)
		memcpy(m_DibBits, pFrame, m_FrameBytes);
	m_View.Draw(m_hDC);
	memcpy(pFrame, m_DibBits, m_FrameBytes);
	return(FF_SUCCESS);
}

