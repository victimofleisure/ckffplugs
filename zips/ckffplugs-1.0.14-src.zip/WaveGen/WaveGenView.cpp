// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      08dec06	initial version
		01		15dec06	add invert

		wave generator view
 
*/

// WaveGenView.cpp : implementation of the CWaveGenView class
//

#include "stdafx.h"
#include "Resource.h"

#include "WaveGenView.h"
#include <math.h>
#include <afxtempl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWaveGenView

#ifndef FFPLUGIN

IMPLEMENT_DYNCREATE(CWaveGenView, CView)

BEGIN_MESSAGE_MAP(CWaveGenView, CView)
	//{{AFX_MSG_MAP(CWaveGenView)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

#endif

/////////////////////////////////////////////////////////////////////////////
// CWaveGenView construction/destruction

CWaveGenView *CWaveGenView::m_View;

const COLORREF CWaveGenView::m_BkColor = RGB(0, 0, 0);

CWaveGenView::CWaveGenView()
{
	m_pts = 0;
	m_TimerFreq = 25;
	m_CarWave = 0;
	m_CarFreq = 1;
	m_CarAmp = 1;
	m_CarPulseWidth = .5;
	m_CarPhaseShift = 0;
	m_ModType = MOD_NONE;
	m_ModAmp = 1;
	m_ModPhaseShift = 0;
	m_FrmSz = CSize(0, 0);
	m_Zoom = 1;
	m_DrawMode = DM_LINE;
	m_LineWidth = 1;
	m_ShowOrg = FALSE;
	m_DrawVert = FALSE;
	m_EraseBkgnd = TRUE;
	m_CarPos = 0;
	m_ModPos = 0;
	m_PrevCarFreq = 0;
	m_WaveColor = RGB(255, 255, 255);
	m_LineColor = -1;
	m_FillColor = -1;
}

CWaveGenView::~CWaveGenView()
{
}

void CWaveGenView::SetTimerFreq(double Freq)
{
	m_Car.SetTimerFreq(Freq);
	m_Mod.SetTimerFreq(Freq);
	m_TimerFreq = Freq;
}

void CWaveGenView::SetCarWave(int Wave)
{
	if (m_ModType != MOD_PULSE)
		m_Car.SetWaveform(Wave);
	m_CarWave = Wave;
}

void CWaveGenView::SetCarFreq(double Freq)
{
	if (m_ModType != MOD_FREQ)
		m_Car.SetFreq(Freq);
	m_CarFreq = Freq;
}

void CWaveGenView::SetCarPulseWidth(double PulseWidth)
{
	if (m_ModType != MOD_PULSE)
		m_Car.SetPulseWidth(PulseWidth);
	m_CarPulseWidth = PulseWidth;
}

void CWaveGenView::SetModType(int Type)
{
	switch (m_ModType) {
	case MOD_FREQ:
		if (Type != MOD_FREQ)
			m_Car.SetFreq(m_CarFreq);
		break;
	case MOD_PULSE:
		if (Type != MOD_PULSE) {
			m_Car.SetPulseWidth(m_CarPulseWidth);
			m_Car.SetWaveform(m_CarWave);
		}
		break;
	}
	switch (Type) {
	case MOD_PULSE:
		m_Car.SetWaveform(COscillator::PULSE);
		break;
	}
	m_ModType = Type;
}

#ifndef FFPLUGIN
void CWaveGenView::SetExclusive(bool Enable)
{
	m_dd.SetExclusive(AfxGetMainWnd()->m_hWnd, m_hWnd, Enable);
	SetFrameSize(m_dd.GetSize());	// make view full-screen
}

BOOL CWaveGenView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return CView::PreCreateWindow(cs);
}
#endif

/////////////////////////////////////////////////////////////////////////////
// CWaveGenView drawing

inline void CWaveGenView::MoveToSwap(HDC dc, int x, int y)
{
	if (m_DrawVert)
		Swap(x, y);
	MoveToEx(dc, x, y, NULL);
}

inline void CWaveGenView::LineToSwap(HDC dc, int x, int y)
{
	if (m_DrawVert)
		Swap(x, y);
	LineTo(dc, x, y);
}

inline void CWaveGenView::AddLineTo(HDC dc, POINT pt)
{
	if (m_DrawVert)
		Swap(pt.x, pt.y);
	m_pta[m_pts++] = pt;
	if (m_pts >= MAX_POLY_POINTS) {
		PolylineTo(dc, m_pta, MAX_POLY_POINTS);
		m_pts = 0;
	}
}

inline double CWaveGenView::Wrap(double Val, double Limit)
{
	double	r = fmod(Val, Limit);
	return(Val < 0 ? r + Limit : r);
}

void CWaveGenView::Draw(HDC dc)
{
	m_Mod.SetClock(Wrap(m_ModPos, 1 / m_Mod.GetFreq() * m_TimerFreq));
	if (m_ModType == MOD_FREQ) {
		m_Car.SetClock(Wrap(m_CarPos, INT_MAX));	// glitches at zero crossing
		m_Car.SetFreqSync(m_PrevCarFreq);
		double	f = m_CarFreq + m_Mod.GetVal() * m_ModAmp * m_CarFreq;
		m_PrevCarFreq = max(0, f);
	} else
		m_Car.SetClock(Wrap(m_CarPos, 1 / m_CarFreq * m_TimerFreq));
	m_CarPos += m_CarPhaseShift;
	m_ModPos += m_ModPhaseShift;
	if (m_EraseBkgnd) {
		SetBkColor(dc, m_BkColor);
		CRect	r(0, 0, m_FrmSz.cx, m_FrmSz.cy);
		ExtTextOut(dc, 0, 0, ETO_OPAQUE, r, NULL, 0, NULL);	// as in CDC::FillSolidRect
	}
	if (m_DrawMode == DM_FILL) {
		if (m_WaveColor != m_FillColor) {
			if (m_WaveBrush.GetSafeHandle != NULL)
				m_WaveBrush.DeleteObject();
			m_WaveBrush.CreateSolidBrush(m_WaveColor);
			m_FillColor = m_WaveColor;
		}
		SelectObject(dc, m_WaveBrush);
		BeginPath(dc);
	} else {
		if (m_WaveColor != m_LineColor) {
			if (m_WavePen.GetSafeHandle != NULL)
				m_WavePen.DeleteObject();
			m_WavePen.CreatePen(PS_SOLID, m_LineWidth, m_WaveColor);
			m_LineColor = m_WaveColor;
		}
		SelectObject(dc, m_WavePen);
	}
	CSize	sz = m_DrawVert ? CPoint(m_FrmSz.cy, m_FrmSz.cx) :
		CPoint(m_FrmSz.cx, m_FrmSz.cy);
	int	h = sz.cy;
	int	oy = h / 2;
	double	dx = m_Zoom;
	int	samps = round(sz.cx / dx + m_Zoom);
	bool	first = TRUE;
	m_pts = 0;
	int	px = -1, py = -1, dir = -1;
	int	dups = 0;
	double	rx = 0;
	for (int i = 0; i < samps; i++) {
		double	amp = m_CarAmp;
		switch (m_ModType) {
		case MOD_FREQ:
			{
				double	f = m_CarFreq + m_Mod.GetVal() * m_ModAmp * m_CarFreq;
				m_Car.SetFreq(max(0, f));
			}
			break;
		case MOD_AMP:
			amp *= m_Mod.GetVal() / 2 * m_ModAmp + .5;
			break;
		case MOD_PULSE:
			m_Car.SetPulseWidth(m_Mod.GetVal() / 2 * m_ModAmp  + .5);
			break;
		}
		double	ry = m_Car.GetVal() * amp;
		int	x = round(rx);
		int	y = oy - round(ry * oy);
		if (first) {
			first = FALSE;
			MoveToSwap(dc, x, y);
		} else {
			if (x == px) {
				if (y != py) {
					if (dir < 0) {
						dir = (y < py);
					} else {
						if (dir != (y < py)) {
							AddLineTo(dc, CPoint(px, py));
							dir = (y < py);
						}
					}
				}
				dups++;
			} else {
				if (dups) {
					AddLineTo(dc, CPoint(px, py));
					dir = -1;
					dups = 0;
				}
				AddLineTo(dc, CPoint(x, y));
			}
		}
		rx += dx;
		px = x;
		py = y;
		m_Mod.TimerHook();
		m_Car.TimerHook();
	}
	PolylineTo(dc, m_pta, m_pts);
	if (m_DrawMode == DM_FILL) {
		if (m_ShowOrg) {
			LineToSwap(dc, px, oy);
			LineToSwap(dc, 0, oy);
			if (m_Invert)
				Rectangle(dc, 0, 0, m_FrmSz.cx + 1, m_FrmSz.cy + 1);
		} else {
			if (m_Invert) {
				LineToSwap(dc, px, sz.cy);
				LineToSwap(dc, 0, sz.cy);
			} else {
				LineToSwap(dc, px, 0);
				LineTo(dc, 0, 0);
			}
		}
		EndPath(dc);
		FillPath(dc);
	} else {
		if (m_ShowOrg) {
			MoveToSwap(dc, 0, oy);
			LineToSwap(dc, sz.cx, oy);
		}
	}
}

#ifndef FFPLUGIN

void CWaveGenView::OnDraw(CDC* pDC)
{
	HDC	dc;
	m_dd.GetDC(&dc);
	Draw(dc);
	m_dd.ReleaseDC(dc);
	m_dd.Blt();
}

/////////////////////////////////////////////////////////////////////////////
// CWaveGenView diagnostics

#ifdef _DEBUG
void CWaveGenView::AssertValid() const
{
	CView::AssertValid();
}

void CWaveGenView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWaveGenView message handlers

void CWaveGenView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
}

BOOL CWaveGenView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CWaveGenView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	SetFrameSize(CSize(cx, cy));
	if (!m_dd.IsExclusive()) {	// surface can't change size in exclusive mode
		m_dd.CreateSurface(cx, cy);
	}
}

int CWaveGenView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_dd.Create(NULL, m_hWnd) || !m_dd.CreateSurface(1, 1)) {
		AfxMessageBox("Can't create surface.");
		exit(0);
	}

	m_View = this;
	
	return 0;
}

#endif
