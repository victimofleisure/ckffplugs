// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
		01		09aug08	TextGen initial version
		02		14jul11	add background param
		03		19aug11	add leading
		04		22aug11	add horizontal margins
		05		23aug11	support Unicode

		freeframe character generator view
 
*/

// TextGenView.h : interface of the CTextGenView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TextGenView_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
#define AFX_TextGenView_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTextGenView window

#include <afxtempl.h>
#include "SortStringArray.h"

class CTextGenView
{
// Construction
public:
	CTextGenView();

// Constants

// Types

// Attributes
	void	SetDoc(float Doc);

	float	m_Line;			// line to show
	float	m_Font;			// font to use
	float	m_FontSize;		// font size
	float	m_Leading;		// leading
	float	m_HorzScale;	// horizontal scaling
	float	m_PosX;			// x-coordinate
	float	m_PosY;			// y-coordinate
	float	m_Rotation;		// rotation
	float	m_TextR;		// text color red
	float	m_TextG;		// text color green
	float	m_TextB;		// text color blue
	bool	m_Background;	// true if drawing background
	bool	m_Bold;			// true if bold
	bool	m_Italic;		// true if italic
	bool	m_Underline;	// true if underline
	float	m_HorzMargins;	// as percentage of frame width

// Operations
	void	SetWndSize(CSize sz);
	void	Draw(HDC dc);

// Overrides

// Implementation
public:
	virtual ~CTextGenView();

// Generated message map functions
protected:

// Types
	typedef struct tagFONT_INFO {
		TCHAR	FaceName[LF_FACESIZE]; 
		float	AspectRatio;
	} FONT_INFO;
	typedef struct tagLINE_INFO {
		int		start;
		int		len;
	} LINE_INFO;

// Constants
	enum {
		MAX_FONT_SCALE = 4,
		MAX_HORZ_STRETCH = 4,
	};
	enum {
		DEXT_TXT,
		DOC_EXTS
	};
	static const LPCTSTR	m_DocExt[DOC_EXTS];	// supported document extensions

// Member data
	CSize	m_FrameSize;	// frame size, in pixels
	CArray<FONT_INFO, FONT_INFO&> 	m_FontInfo;
	CStringArray	m_Text;
	CArray<LINE_INFO, LINE_INFO&>	m_LineInfo;
	CSortStringArray	m_DocPath;
	int		m_Doc;			// document to show

// Helpers
	static	int CALLBACK FontProc(const LOGFONT *Font, const TEXTMETRIC *Metric, DWORD FontType, LPARAM lParam);
	void	GetFonts();
	bool	LoadDocPaths();
	int		Denorm(float Val, int Range);
	static	bool	IsHyphen(TCHAR c);
};

inline int CTextGenView::Denorm(float Val, int Range)
{
	int	i = round(Val * Range - .5);
	return(CLAMP(i, 0, Range - 1));
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TextGenView_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
