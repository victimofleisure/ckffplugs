// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
		00		09aug08	1.0.00
		01		11jul11	1.0.01
		02		19jul11	1.0.02
		03		19aug11	1.0.03
		04		23aug11	1.0.04

		DON'T FORGET TO CHANGE RESOURCE VERSION INFO
		also change version number in PlugExtInfo

*/
