// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		04jan08	add description and about text
		03		09aug08	TextGen initial version
		04		11jul11	change Pos Y default to .5
		05		11jul11	make rotation zero-origin
		06		14jul11	add background param
		07		19aug11	add leading
		08		22aug11	add horizontal margins

		freeframe character generator plugin
 
*/

#include <stdafx.h>
#include "TextGenPlug.h"
#include <math.h>

const PlugInfoStruct PlugInfo = {
	1,	// API major version; don't change
	0,	// API minor version; don't change
	{'T', 'X', 'T', 'G'},	// plugin identifier; MUST be 4 bytes
	{'T', 'e', 'x', 't', 'G', 'e', 'n', ' ',
	 ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title; MUST be 16 bytes
	0	// effect plugin
};

const PlugExtendedInfoStruct PlugExtInfo = {
	1,		// plugin major version
	0,		// plugin minor version
	"Text Generator",	// description; this IS a null-terminated string
	"Copyleft 2008 Chris Korda",	// about text; this IS a null-terminated string
	0,		// extended data size
	NULL	// extended data block
};

const TextGenPlug::ParamConstantsStruct paramConstants[TextGenPlug::NUM_PARAMS] = {
//			 1234567890123456		these MUST be 16 bytes long, padded with blanks
	{0,		"Document        "},
	{0,		"Line            "},
	{0,		"Font            "},
	{.1f,	"Font Size       "},
	{.5f,	"Leading         "},
	{.5,	"Horz Scale      "},
	{.5,	"Pos X           "},
	{.5,	"Pos Y           "},
	{0,		"Rotation        "},
	{1,		"Red             "},
	{1,		"Green           "},
	{1,		"Blue            "},
	{0,		"Background      "},
	{0,		"Bold            "},
	{0,		"Italic          "},
	{0,		"Underline       "},
	{.1f,	"Horz Margins    "},
};

PlugInfoStruct* getInfo() 
{
	return const_cast<PlugInfoStruct *>(&PlugInfo);
}

DWORD initialise()
{
	return FF_SUCCESS;
}

DWORD deInitialise()
{
	return FF_SUCCESS;
}

DWORD getNumParameters()
{
	return TextGenPlug::NUM_PARAMS;  
}

char* getParameterName(DWORD index)
{
	if (index >= 0 && index < TextGenPlug::NUM_PARAMS)
		return const_cast<char *>(paramConstants[index].name);
	return "                ";
}

float getParameterDefault(DWORD index)
{
	if (index >= 0 && index < TextGenPlug::NUM_PARAMS)
		return paramConstants[index].defaultValue;
	return 0;
}

TextGenPlug::TextGenPlug()
{
	for (int i = 0; i < NUM_PARAMS; i++) {
		m_Param[i].value = paramConstants[i].defaultValue;	// init to default values
		memset(m_Param[i].displayValue, ' ', MAX_STRING);
	}
}

TextGenPlug::~TextGenPlug()
{
}

char* TextGenPlug::getParameterDisplay(DWORD index)
{
	memset(m_Param[index].displayValue, ' ', MAX_STRING);
	if (index >= 0 && index < NUM_PARAMS) {
		char	s[MAX_STRING];
		sprintf(s, "%g", m_Param[index].value);
		int	len = strlen(s);
		memcpy(m_Param[index].displayValue, s, min(len, MAX_STRING));
	}
	return m_Param[index].displayValue;
}

DWORD TextGenPlug::setParameter(SetParameterStruct* pParam)
{
	int	index = pParam->index;
	if (index >= 0 && index < NUM_PARAMS) {
		float	val = pParam->value;
		m_Param[index].value = val;
		switch (index) {
		case DOCUMENT:
			m_View.SetDoc(val);
			break;
		case LINE:
			m_View.m_Line = val;
			break;
		case FONT:
			m_View.m_Font = val;
			break;
		case FONT_SIZE:
			m_View.m_FontSize = val;
			break;
		case LEADING:
			m_View.m_Leading = val;
			break;
		case HORZ_SCALE:
			m_View.m_HorzScale = val;
			break;
		case POS_X:
			m_View.m_PosX = val;
			break;
		case POS_Y:
			m_View.m_PosY = val;
			break;
		case ROTATION:
			m_View.m_Rotation = val;
			break;
		case RED:
			m_View.m_TextR = val;
			break;
		case GREEN:
			m_View.m_TextG = val;
			break;
		case BLUE:
			m_View.m_TextB = val;
			break;
		case BACKGROUND:
			m_View.m_Background = val > 0;
			break;
		case BOLD:
			m_View.m_Bold = val > 0;
			break;
		case ITALIC:
			m_View.m_Italic = val > 0;
			break;
		case UNDERLINE:
			m_View.m_Underline = val > 0;
			break;
		case HORZ_MARGINS:
			m_View.m_HorzMargins = val;
			break;
		}
		return FF_SUCCESS;
	}
	return FF_FAIL;
}

float TextGenPlug::getParameter(DWORD index)
{
	if (index >= 0 && index < NUM_PARAMS)
		return m_Param[index].value;
	return 0;
}

DWORD TextGenPlug::processFrameCopy(ProcessFrameCopyStruct* pFrameData)
{
	return FF_FAIL;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case FF_CAP_16BITVIDEO:
		return FF_TRUE;

	case FF_CAP_24BITVIDEO:
		return FF_TRUE;

	case FF_CAP_32BITVIDEO:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_FALSE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return TextGenPlug::NUM_INPUT_FRAMES;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return TextGenPlug::NUM_INPUT_FRAMES;

	case FF_CAP_COPYORINPLACE:
		return FF_FALSE;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	// this shouldn't happen if the host is checking the capabilities properly
	if (pVideoInfo->bitDepth < 0 || pVideoInfo->bitDepth > 2)
		return (LPVOID) FF_FAIL;

	TextGenPlug *pPlugObj = new TextGenPlug;

	if (!pPlugObj->Init(*pVideoInfo)) {
		delete pPlugObj;
		return NULL;
	}

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	TextGenPlug *pPlugObj = (TextGenPlug*) instanceID;
	delete pPlugObj;	// delete first, THEN set to null (duh!)
	pPlugObj = NULL;	// mark instance deleted
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	return (LPVOID) &PlugExtInfo;
}
