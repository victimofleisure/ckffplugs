// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo
        02      18jul11	multiply

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"
#include <math.h>
#include "mmintrin.h"

#define USE_MMX	1

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	m_Blend = 1;
	m_Invert = FALSE;
	m_SwapInputs = FALSE;
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	return(TRUE);
}

DWORD CMainFrame::processFrameCopy(ProcessFrameCopyStruct *pParam)
{
	BYTE	*pInA;
	BYTE	*pInB;
	if (m_SwapInputs) {
		pInA = (BYTE *)pParam->InputFrames[1];
		pInB = (BYTE *)pParam->InputFrames[0];
	} else {
		pInA = (BYTE *)pParam->InputFrames[0];
		pInB = (BYTE *)pParam->InputFrames[1];
	}
	BYTE	*pOut = (BYTE *)pParam->OutputFrame;
#if USE_MMX
	__m64	Zero = _mm_setzero_si64();
	short	wInvMask = m_Invert ? 0xff : 0;
	__m64	InvMask = _mm_set1_pi16(wInvMask);
	int	nLoops = m_FrameBytes >> 2;
	if (m_Blend == 1) {	// if blend is full strength, optimize special case
		__asm {
			mov EAX, pInA                              //   EAX = pointer to input frame A
			mov EDX, pInB                              //   EDX = pointer to input frame B
			movq      mm5, Zero                        //   Zero = memory[Zero]
			mov EDI, pOut                              //   EDI = pointer to output frame
			mov ECX, nLoops                            //   ECX = loop count
			movq      mm4, InvMask                     //   InvMask = memory[InvMask]
		   ALIGN 16
		$1: 
			movd      mm0, [EAX]                       //   PixelA = memory[EAX]
			movd      mm1, [EDX]                       //   PixelB = memory[EDX]
			punpcklbw mm1, mm5                         //   Unpack PixelB and Zero into PixelB (low-order)
			punpcklbw mm0, mm5                         //   Unpack PixelA and Zero into PixelA (low-order)
			pxor      mm1, mm4                         //   PixelB = PixelB XOR InvMask
			pmullw    mm0, mm1                         //   PixelA = PixelA * PixelB (low-order)
			psrlw     mm0, 8                           //   Shift PixelA right by 8
			packuswb  mm0, mm5                         //   Pack PixelA and Zero into PixelA
			add       EAX, 4                           //   Add 4 to EAX
			movd      [EDI], mm0                       //   memory[EDI] = PixelA
			add       EDX, 4                           //   Add 4 to EDX
			add       EDI, 4                           //   Add 4 to EDI
			dec       ECX                              //   Decrease ECX
			jnz       $1                               //   Jump to $1 if ECX is not zero
			emms                                       //   Empty MMX state
		}
	} else {	// blend is less than full strength
		short	wScale = round(m_Blend * 256);
		short	wInvScale = 256 - wScale;
		__m64	Scale = _mm_set1_pi16(wScale);
		__m64	InvScale = _mm_set1_pi16(wInvScale);
		__asm {
			mov EAX, pInA                              //   EAX = pointer to input frame A
			mov EDX, pInB                              //   EDX = pointer to input frame B
			movq      mm5, Zero                        //   Zero = memory[Zero]
			mov EDI, pOut                              //   EDI = pointer to output frame
			mov ECX, nLoops                            //   ECX = loop count
			movq      mm6, Scale                       //   Scale = memory[Scale]
			movq      mm7, InvScale                    //   InvScale = memory[InvScale]
			movq      mm4, InvMask                     //   InvMask = memory[InvMask]
		   ALIGN 16
		$2: 
			movd      mm0, [EAX]                       //   PixelA = memory[EAX]
			movd      mm1, [EDX]                       //   PixelB = memory[EDX]
			punpcklbw mm1, mm5                         //   Unpack PixelB and Zero into PixelB (low-order)
			punpcklbw mm0, mm5                         //   Unpack PixelA and Zero into PixelA (low-order)
			pxor      mm1, mm4                         //   PixelB = PixelB XOR InvMask
			pmullw    mm1, mm0                         //   PixelB = PixelB * PixelA (low-order)
			psrlw     mm1, 8                           //   Shift PixelB right by 8
			pmullw    mm0, mm7                         //   PixelA = PixelA * InvScale (low-order)
			pmullw    mm1, mm6                         //   PixelB = PixelB * Scale (low-order)
			paddw     mm0, mm1                         //   PixelA = PixelA + PixelB
			psrlw     mm0, 8                           //   Shift PixelA right by 8
			packuswb  mm0, mm5                         //   Pack PixelA and Zero into PixelA
			movd      [EDI], mm0                       //   memory[EDI] = PixelA
			add       EAX, 4                           //   Add 4 to EAX
			add       EDX, 4                           //   Add 4 to EDX
			add       EDI, 4                           //   Add 4 to EDI
			dec       ECX                              //   Decrease ECX
			jnz       $2                               //   Jump to $2 if ECX is not zero
			emms                                       //   Empty MMX state
		}
	}
#else	// no MMX
	float	fScale = m_Blend;
	float	fInvScale = 1 - m_Blend;
	int	nLoops = m_FrameBytes >> 2;
	int	InvertMask = m_Invert ? 0xff : 0;
	for (int i = 0; i < nLoops; i++) {
		pOut[0] = round(pInA[0] * fInvScale + pInA[0]
			* (pInB[0] ^ InvertMask) / 255.0 * fScale);
		pOut[1] = round(pInA[1] * fInvScale + pInA[1] 
			* (pInB[1] ^ InvertMask) / 255.0 * fScale);
		pOut[2] = round(pInA[2] * fInvScale + pInA[2] 
			* (pInB[2] ^ InvertMask) / 255.0 * fScale);
		pInA += 4;
		pInB += 4;
		pOut += 4;
	}
#endif	// USE_MMX
	return(FF_SUCCESS);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	return(FF_FAIL);
}
