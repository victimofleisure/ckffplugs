// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo
        02      18jul11	multiply

		freeframe source plugin demo
 
*/

#ifndef ALPHAMIXPLUG_INCLUDED
#define ALPHAMIXPLUG_INCLUDED

#include "FreeFrame.h"
#include "MainFrm.h"

class MultiplyPlug : public CMainFrame {
public:
// Constants
	enum {
		// TODO: enumerate your plugin's parameters here
		BLEND,
		INVERT,
		SWAP_INPUTS,
		NUM_PARAMS
	};
	enum {
		NUM_INPUT_FRAMES = 2,
		MAX_STRING = 16
	};

// Types
	typedef struct ParamConstsStructTag {
		float defaultValue;
		char name[MAX_STRING + 1];
	} ParamConstantsStruct;
	typedef struct ParamDynamicDataStructTag {
		float value;
		char displayValue[MAX_STRING];
	} ParamDynamicDataStruct;

// Construction
	MultiplyPlug();
	~MultiplyPlug();

// Attributes
	char*	getParameterDisplay(DWORD index);			
	DWORD	setParameter(SetParameterStruct* pParam);		
	float	getParameter(DWORD index);

// Operations

private:
// Member data
	ParamDynamicDataStruct m_Param[NUM_PARAMS];
};

PlugInfoStruct*	getInfo();							
DWORD	initialise();								
DWORD	deInitialise();								
DWORD	getNumParameters();							
char*	getParameterName(DWORD index);				
float	getParameterDefault(DWORD index);			
DWORD	getPluginCaps(DWORD index);	
LPVOID	instantiate(VideoInfoStruct* pVideoInfo);
DWORD	deInstantiate(LPVOID instanceID);	
LPVOID	getExtendedInfo();		

#endif
