INTRODUCTION:

WaveGen is a wave generator Freeframe effect for Windows 2000/XP. If you have any experience with analog synthesizers (or their virtual equivalent), the parameters should be familiar.

PARAMETERS:

Car Waveform
Carrier waveform: 0 = Triangle, .125 = Sine, .25 = Ramp Up, .375 = Ramp Down, .5 = Square, .625 = Pulse, .75 = Random, .875 = Random Ramp.

Car Frequency
Carrier frequency, on a logarithmic scale: 0 = .001 Hz, .25 = .01 Hz, .5 = .1 Hz, .75 = 1 Hz, 1 = 10 Hz.

Car Amplitude
Carrier amplitude, from 0 to 1. At 0, there's no output; at 1, the output fills the entire frame.

Car Pulse Width
Carrier pulse width (duty cycle): 0 = all low, .5 = 50%, 1 = all high. Only affects the output when the carrier waveform is "Pulse".

Car Phase Shift
Shift the carrier phase by this much per frame. The unit is time, not degrees. Effectively sets the amount of scrolling: 0 = maximum reverse, .5 = no scrolling, 1 = maximum forward.

Mod Type
Modulation type: 0 = None, .25 = AM (Amplitude Modulation), .5 = FM (Frequency Modulation), .75 = PM (Pulse Width Modulation). Note that when PM is selected, the carrier's waveform is automatically forced to "Pulse".

Mod Waveform
Modulator waveform: 0 = Triangle, .125 = Sine, .25 = Ramp Up, .375 = Ramp Down, .5 = Square, .625 = Pulse, .75 = Random, .875 = Random Ramp.

Mod Frequency
Modulator frequency, on a logarithmic scale: 0 = .001 Hz, .25 = .01 Hz, .5 = .1 Hz, .75 = 1 Hz, 1 = 10 Hz.

Mod Amplitude
Modulator amplitude, from 0 to 1. At 0, there's no modulation; at 1, the modulation's "swing" is at unity.

Mod Pulse Width
Modulator pulse width (duty cycle): 0 = all low, .5 = 50%, 1 = all high. Only affects the output when the modulator waveform is "Pulse".

Mod Phase Shift
Shift the modulator phase by this much per frame. The unit is time, not degrees. Effectively sets the amount of scrolling: 0 = maximum reverse, .5 = no scrolling, 1 = maximum forward.

Zoom
Magnification in the horizontal axis, on a logarithmic scale: 0 = x0.1, .5 = x1, 1 = x10. Note that in vertical mode, Zoom affects the vertical axis instead.

Vertical
If non-zero, draw the output wave vertically instead of horizontally.

Fill
If non-zero, fill in the wave instead drawing it as a line.

Erase Bkgnd
If non-zero, erase the background to black; otherwise, the frame's previous contents are the background.

Line Width
The width of the line, as a scaled percentage of the frame height: 0 = 1 pixel, .5 = 5% of frame height, 1 = 10% of frame height. Only affects the output in line-drawing mode.

Show Origin
If non-zero, show the origin vector.

Red
Sets the red component of the drawing color.

Green
Sets the green component of the drawing color.

Blue
Sets the blue component of the drawing color.

Invert
If non-zero, invert the filled area, i.e. what was background is now filled and vice versa; only affects the output in fill mode.

NOTES:

Try doing AM or PM with the carrier and modulator phase shifts set to scroll slowly in opposite directions.

Also try setting carrier and modulator frequencies nearly the same for nice interference.

Warning: be careful with zoom < .5, as zooming too far out may overload your CPU!

The source code and binaries for this release are available from the FFRend web site, http://ffrend.sourceforge.net/.

LICENSE:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.  You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA.

Kopyleft 2006 Chris Korda, All Rites Reversed.

END
