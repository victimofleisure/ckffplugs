// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	specialize demo

		freeframe source plugin's surrogate main frame window
 
*/

#ifndef CMAINFRAME_INCLUDED
#define CMAINFRAME_INCLUDED

#include "FreeFrame.h"
#include "DoRop.h"

struct VideoInfoStructTag;

class CMainFrame {
public:
// Construction
	CMainFrame();
	~CMainFrame();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants

// Attributes
	void	SetBlendingMode(DWORD Mode);

// Operations
	DWORD	processFrame(LPVOID pFrame);
	DWORD	processFrameCopy(ProcessFrameCopyStruct *pParam);

private:
// Constants

// Member data
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	LONG	m_FrameBytes;		// size of frame in bytes
	LONG	m_BytesPerPixel;	// number of bytes per pixel
	DWORD	m_BlendingMode;		// index of raster operation

// Helpers
	static	void	TimerCallback(LPVOID Cookie);
};

inline void CMainFrame::SetBlendingMode(DWORD Mode)
{
	m_BlendingMode = Mode;
}

#endif
