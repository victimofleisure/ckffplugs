// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27dec06	initial version

		Do Raster OPerations
 
*/

#ifndef DOROP_INCLUDED
#define DOROP_INCLUDED

enum {	// raster operations
	ROP_DSna,	// ~Src & Dst				
	ROP_DSno,	// ~Src | Dst		MERGEPAINT
	ROP_SDna,	// Src & ~Dst		SRCERASE
	ROP_SDno,	// Src & ~Dst				
	ROP_DSa,	// Src & Dst		SRCAND
	ROP_DSo,	// Src | Dst		SRCPAINT
	ROP_DSx,	// Src ^ Dst		SRCINVERT
	ROP_DSan,	// ~(Src & Dst)				
	ROP_DSon,	// ~(Src | Dst)		NOTSRCERASE
	ROP_DSxn,	// ~(Src ^ Dst)		
	ROPS
};

void DoROP(int rop, const BYTE *pA, const BYTE *pB, BYTE *pC, DWORD len);

#endif
