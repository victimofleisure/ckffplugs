// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27dec06	initial version

		Do Raster OPerations
 
*/

#include <stdafx.h>
#include "DoRop.h"

#define nop

// 1 binary operator and 3 unaries: C = uc ((ua A) bo (ub B))
#define ROPDEF(name, bo, ua, ub, uc)\
static void name(const BYTE *pA, const BYTE *pB, BYTE *pC, DWORD len)\
{\
	DWORD	dws = len >> 2; /* get # of dwords */\
	DWORD	i;\
	for (i = 0; i < dws; i++) {\
		*((DWORD *)pC) = uc ((ua *((const DWORD *)pA)) bo (ub *((const DWORD *)pB)));\
		pA += 4;\
		pB += 4;\
		pC += 4;\
	}\
	DWORD	bs = len & 3; /* get # of extra bytes */\
	for (i = 0; i < bs; i++)\
		*pC++ = uc ((ua *pA++) bo (ub *pB++));\
}

//     name bo  ua  ub  uc
ROPDEF(DSna,&  ,~  ,nop,nop)
ROPDEF(DSno,|  ,~  ,nop,nop)
ROPDEF(SDna,&  ,nop,~  ,nop)
ROPDEF(SDno,|  ,nop,~  ,nop)
ROPDEF(DSa,	&  ,nop,nop,nop)
ROPDEF(DSo,	|  ,nop,nop,nop)
ROPDEF(DSx,	^  ,nop,nop,nop)
ROPDEF(DSan,&  ,nop,nop,~  )
ROPDEF(DSon,|  ,nop,nop,~  )
ROPDEF(DSxn,^  ,nop,nop,~  )

#define ROPCASE(rop) case ROP_##rop: rop(pA, pB, pC, len); break;

void DoROP(int rop, const BYTE *pA, const BYTE *pB, BYTE *pC, DWORD len)
{
	switch (rop) {
	ROPCASE(DSna)
	ROPCASE(DSno)
	ROPCASE(SDna)
	ROPCASE(SDno)
	ROPCASE(DSa)
	ROPCASE(DSo)
	ROPCASE(DSx)
	ROPCASE(DSan)
	ROPCASE(DSon)
	ROPCASE(DSxn)
	}
}
