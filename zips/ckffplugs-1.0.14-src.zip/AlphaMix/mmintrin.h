// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      04nov07	initial version

		implement MMX intrinsics
 
*/

#ifndef MMINTRIN_INCLUDED
#define MMINTRIN_INCLUDED

#ifndef __m64

#define __m64 __int64

inline __m64 _mm_setzero_si64()
{
	__m64	r;
	*((__int64 *)&r) = 0;
	return(r);
}

inline __m64 _mm_set_pi32(int i1, int i0)
{
	__m64	r;
	((int *)&r)[0] = i0;
	((int *)&r)[1] = i1;
	return(r);
}

inline __m64 _mm_set_pi16(short w3, short w2, short w1, short w0)
{
	__m64	r;
	((short *)&r)[0] = w0;
	((short *)&r)[1] = w1;
	((short *)&r)[2] = w2;
	((short *)&r)[3] = w3;
	return(r);
}

inline __m64 _mm_set_pi8(char b7, char b6, char b5, char b4, char b3, char b2, char b1, char b0)
{
	__m64	r;
	((char *)&r)[0] = b0;
	((char *)&r)[1] = b1;
	((char *)&r)[2] = b2;
	((char *)&r)[3] = b3;
	((char *)&r)[4] = b4;
	((char *)&r)[5] = b5;
	((char *)&r)[6] = b6;
	((char *)&r)[7] = b7;
	return(r);
}

inline __m64 _mm_set1_pi32(int i)
{
	return(_mm_set_pi32(i, i));
}

inline __m64 _mm_set1_pi16(short w)
{
	return(_mm_set_pi16(w, w, w, w));
}

inline __m64 _mm_set1_pi8(char b)
{
	return(_mm_set_pi8(b, b, b, b, b, b, b, b));
}

inline __m64 _mm_setr_pi32(int i0, int i1)
{
	return(_mm_set_pi32(i1, i0));
}

inline __m64 _mm_setr_pi16(short w0, short w1, short w2, short w3)
{
	return(_mm_set_pi16(w3, w2, w1, w0));
}

inline __m64 _mm_setr_pi8(char b0, char b1,char b2, char b3, char b4, char b5, char b6, char b7)
{
	return(_mm_set_pi8(b7, b6, b5, b4, b3, b2, b1, b0));
}

#endif

#endif
