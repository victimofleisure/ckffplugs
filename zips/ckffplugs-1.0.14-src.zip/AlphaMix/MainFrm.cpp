// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo
        02      16jul11	alpha mixer

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"
#include <math.h>
#include "mmintrin.h"

#define USE_MMX	1

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	m_MixValue = 0.5f;
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	return(TRUE);
}

DWORD CMainFrame::processFrameCopy(ProcessFrameCopyStruct *pParam)
{
	BYTE	*pInA = (BYTE *)pParam->InputFrames[0];
	BYTE	*pInB = (BYTE *)pParam->InputFrames[1];
	BYTE	*pOut = (BYTE *)pParam->OutputFrame;
#if USE_MMX
	short	wScale = round(m_MixValue * 256);
	short	wInvScale = 256 - wScale;
	__m64	Scale = _mm_set1_pi16(wScale);
	__m64	InvScale = _mm_set1_pi16(wInvScale);
	__m64	Zero = _mm_setzero_si64();
	int	nLoops = m_FrameBytes >> 2;
	__asm {
		mov EAX, pInA                              //   EAX = pointer to input frame A
		mov EDX, pInB                              //   EDX = pointer to input frame B
		mov EDI, pOut                              //   EDI = pointer to output frame
		mov ECX, nLoops                            //   ECX = loop count
		movq      mm5, Zero                        //   Zero = memory[Zero]
		movq      mm6, Scale                       //   Scale = memory[Scale]
		movq      mm7, InvScale                    //   InvScale = memory[InvScale]
	   ALIGN 16
	$1: 
		movd      mm0, [EAX]                       //   PixelA = memory[EAX]
		movd      mm1, [EDX]                       //   PixelB = memory[EDX]
		add       EAX, 4                           //   Add 4 to EAX
		punpcklbw mm0, mm5                         //   Unpack PixelA and Zero into PixelA (low-order)
		punpcklbw mm1, mm5                         //   Unpack PixelB and Zero into PixelB (low-order)
		pmullw    mm0, mm6                         //   PixelA = PixelA * Scale (low-order)
		pmullw    mm1, mm7                         //   PixelB = PixelB * InvScale (low-order)
		paddw     mm0, mm1                         //   PixelA = PixelA + PixelB
		psrlw     mm0, 8                           //   Shift PixelA right by 8
		packuswb  mm0, mm5                         //   Pack PixelA and Zero into PixelA
		add       EDX, 4                           //   Add 4 to EDX
		movd      [EDI], mm0                       //   memory[EDI] = PixelA
		add       EDI, 4                           //   Add 4 to EDI
		dec       ECX                              //   Decrease ECX
		jnz       $1                               //   Jump to $1 if ECX is not zero
		emms                                       //   Empty MMX state
	}
#else	// no MMX
	float	fScale = m_MixValue;
	float	fInvScale = 1 - m_MixValue;
	int	nLoops = m_FrameBytes >> 2;
	for (int i = 0; i < nLoops; i++) {
		*pOut++ = round(*pInA++ * fScale + *pInB++ * fInvScale);
		*pOut++ = round(*pInA++ * fScale + *pInB++ * fInvScale);
		*pOut++ = round(*pInA++ * fScale + *pInB++ * fInvScale);
		pInA++;
		pInB++;
		pOut++;
	}
#endif	// USE_MMX
	return(FF_SUCCESS);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	return(FF_FAIL);
}
