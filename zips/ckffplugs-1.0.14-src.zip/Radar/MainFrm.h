// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		02nov09	Radar initial version
		03		09apr11	complete rewrite for version 2

		freeframe radar main frame
 
*/

#ifndef CMAINFRAME_INCLUDED
#define CMAINFRAME_INCLUDED

#include "FreeFrame.h"
#include "ArrayEx.h"

struct VideoInfoStructTag;

class CMainFrame {
public:
// Construction
	CMainFrame();
	~CMainFrame();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants

// Attributes
	int		GetWidth() const;
	int		GetHeight() const;
	double	GetAngle() const;
	void	SetAngle(double Angle);
	double	GetDecay() const;
	void	SetDecay(double Decay);
	double	GetSpeed() const;
	void	SetSpeed(double Speed);
	double	GetOriginX() const;
	void	SetOriginX(double Pos);
	double	GetOriginY() const;
	void	SetOriginY(double Pos);
	double	GetRadius() const;
	void	SetRadius(double Radius);
	double	GetColor() const;
	void	SetColor(double Color);
	double	GetScale() const;
	void	SetScale(double Scale);
	bool	GetReverse() const;
	void	SetReverse(bool Enable);

// Operations
	DWORD	processFrame(LPVOID pFrame);

private:
// Types
	struct SPAN {
		int		v1;
		int		v2;
	};
	typedef	CArrayEx<SPAN, SPAN&> CSpanArray;

// Constants
	enum {
		COLORS = 7
	};
	static const DWORD	m_Palette[COLORS];	// palette of color channel masks

// Member data
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	LONG	m_FrameBytes;		// size of frame in bytes
	LONG	m_BytesPerPixel;	// number of bytes per pixel

// Radar member data
	double	m_Angle;			// sweep angle: 0 = 0 degrees, 1 = 360 degrees
	double	m_Decay;			// sweep decay: 0 = none, 1 = max
	double	m_Speed;			// sweep speed: 0 = none, 1 = max
	double	m_OriginX;			// sweep origin X: 0 = right, 1 = left
	double	m_OriginY;			// sweep origin Y: 0 = top, 1 = bottom
	double	m_Radius;			// sweep radius: .5 = fit to frame, 1 = max
	double	m_Color;			// sweep color: mapped to palette
	double	m_Scale;			// sweep scale: applied to radius
	bool	m_Reverse;			// if true, sweep counterclockwise
	bool	m_UpdateArcTan;		// if true, update arc tangent table
	bool	m_UpdateCircle;		// if true, update circle outline
	int		m_Stride;			// drawing bitmap stride
	CDWordArray	m_ArcTan;		// normalized arc tangent for each pixel
	CSpanArray	m_CircleRow;	// circle outline (x1, x2) for each y
	SPAN	m_CircleBounds;		// circle bounds (y1, y2)

// Helpers
};

inline int CMainFrame::GetWidth() const
{
	return(m_VideoInfo.frameWidth);
}

inline int CMainFrame::GetHeight() const
{
	return(m_VideoInfo.frameHeight);
}

inline double CMainFrame::GetAngle() const
{
	return(m_Angle);
}

inline double CMainFrame::GetDecay() const
{
	return(m_Decay);
}

inline double CMainFrame::GetSpeed() const
{
	return(m_Speed);
}

inline double CMainFrame::GetRadius() const
{
	return(m_Radius);
}

inline double CMainFrame::GetOriginX() const
{
	return(m_OriginX);
}

inline double CMainFrame::GetOriginY() const
{
	return(m_OriginY);
}

inline double CMainFrame::GetColor() const
{
	return(m_Color);
}

inline double CMainFrame::GetScale() const
{
	return(m_Scale);
}

inline bool CMainFrame::GetReverse() const
{
	return(m_Reverse);
}

#endif
