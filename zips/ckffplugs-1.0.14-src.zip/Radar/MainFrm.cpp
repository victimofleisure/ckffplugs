// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		30dec06	make top-down DIB conditional
		03		02nov09	Radar initial version
		04		09apr11	complete rewrite for version 2

		freeframe radar main frame
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"
#include <math.h>

#define USE_ASM	1

const DWORD	CMainFrame::m_Palette[COLORS] = {
	0xffffff,	// white
	0xff0000,	// R
	0x00ff00,	// G
	0x0000ff,	// B
	0x00ffff,	// C
	0xff00ff,	// M
	0xffff00,	// Y
};

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;

// radar init
	m_Angle = 0;
	m_Decay = .5;
	m_Speed = .1;
	m_Radius = .5;
	m_OriginX = .5;
	m_OriginY = .5;
	m_Color = 0;
	m_Scale = 0;
	m_Reverse = FALSE;
	m_UpdateArcTan = FALSE;
	m_UpdateCircle = FALSE;
	m_Stride = 0;
}

CMainFrame::~CMainFrame()
{
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_BytesPerPixel = 4;
		break;
	default:
		return(FALSE);
	}
	m_FrameBytes = GetWidth() * GetHeight() * m_BytesPerPixel;

// radar init
	m_UpdateArcTan = TRUE;
	m_UpdateCircle = TRUE;
	m_Stride = GetWidth() * m_BytesPerPixel;
	return(TRUE);
}

// VC6 implements UInt32x32To64 as call to __allmul, too slow
#pragma warning(disable:4035)	// disable no return value warning
inline ULONGLONG FastUInt32x32To64(DWORD Multiplier, DWORD Multiplicand)
{
    __asm    {
        mov     eax, Multiplicand
        mul		Multiplier
    }
	// 64-bit product returned in registers eax:edx
}
#pragma warning(default:4035)	// restore warning

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	int	width = GetWidth();
	int	height = GetHeight();
	if (m_UpdateArcTan) {
		m_ArcTan.SetSize(width * height);
		double	ox = width * m_OriginX;
		double	oy = height * m_OriginY;
		DWORD	*p = m_ArcTan.GetData();
		double	pi2 = PI * (m_Reverse ? 2 : -2);
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				double	a = atan2(y - oy, x - ox);
				double	d = a / pi2 + .5;	// range [0..1]
				*p++ = round(d * (256 << 16));
			}
		}
		m_UpdateArcTan = FALSE;
	}
	if (m_UpdateCircle) {
		m_CircleRow.SetSize(height);
		double	ox = width * m_OriginX;
		double	oy = height * m_OriginY;
		double	rad = m_Radius * double(min(width, height)) * (m_Scale * 10 + 1);
		int	y1 = round(oy - rad);
		int	y2 = round(oy + rad);
		y1 = max(y1, 0);
		y2 = min(y2, height);
		for (int y = y1; y < y2; y++) {
			double	b;
			if (y > oy)
				b = y - oy + .5;
			else
				b = oy - y - .5;
			double	a = sqrt(rad * rad - b * b);
			int	x1 = round(ox - a);
			int	x2 = round(ox + a);
			x1 = max(x1, 0);
			x2 = min(x2, width);
			m_CircleRow[y].v1 = x1;
			m_CircleRow[y].v2 = x2;
		}
		m_CircleBounds.v1 = y1;
		m_CircleBounds.v2 = y2;
		m_UpdateCircle = FALSE;
	}
	BYTE	*pBits = (BYTE *)pFrame;
	ZeroMemory(pBits, m_FrameBytes);
	if (m_Decay) {	// avoid divide by zero
		DWORD	ColorMask = m_Palette[round(m_Color * (COLORS - 1))];
		int	angle = round(m_Angle * (256 << 16));
		int	decay;
		if (m_Decay <= .5) {
			decay = round(0x100 * (.5 / m_Decay));
		} else {
			decay = round(0x100 * 2 * (1 - m_Decay));
		}
		int	y1 = m_CircleBounds.v1;
		int	y2 = m_CircleBounds.v2;
		pBits += m_Stride * y1;
		for (int y = y1; y < y2; y++) {
			UINT	*pRow = (UINT *)pBits;
			int	x1 = m_CircleRow[y].v1;
			int	x2 = m_CircleRow[y].v2;
			pRow += x1;
			DWORD	*pArcTan = &m_ArcTan[y * width + x1]; 
#if USE_ASM
			__asm {
				mov		esi, pArcTan
				mov		edi, pRow
				mov		ebx, decay
				mov		ecx, x2
				sub		ecx, x1			// number of loops
				jle		$3
$1:
				mov		eax, [esi]		// get *pArcTan
				add		eax, angle		// add angle
				and		eax, 0ffffffh	// wrap
				mul		ebx				// multiply by decay
				test	edx, edx		// if product exceeds 32 bits
				jne		$2				// saturate to black

				shr		eax, 24			// truncate to MSB only
				mov		edx, 255
				sub		edx, eax		// invert brightness
				mov		eax, edx		// convert to RGB value
				shl		eax, 8
				or		eax, edx
				shl		eax, 8
				or		eax, edx
				and		eax, ColorMask	// apply color mask
				mov		[edi], eax		// set *pRow
$2:
				add		esi, 4			// bump pArcTan
				add		edi, 4			// bump pRow
				dec		cx
				jnz		$1
$3:
			}
#else
			for (int x = x1; x < x2; x++) {
				UINT	c = *pArcTan++;
				c += angle;				// add angle
				c &= 0xffffff;			// wrap
				LARGE_INTEGER	li;
				li.QuadPart = FastUInt32x32To64(c, decay);	// multiply by decay
				if (!li.HighPart) {		// if product fit in 32 bits
					c = li.LowPart;
					c >>= 24;			// truncate to MSB only
					c = 255 - c;		// invert brightness
					c = RGB(c, c, c);	// convert to RGB value
					c &= ColorMask;		// apply color mask
					*pRow = c;
				}
				pRow++;
			}
#endif
			pBits += m_Stride;
		}
	}
	if (m_Speed) {
		m_Angle += m_Speed / 10;
		if (m_Angle > 1)
			m_Angle -= 1;	// wrap
	}
	return(FF_SUCCESS);
}

void CMainFrame::SetAngle(double Angle)
{
	m_Angle = Angle;
}

void CMainFrame::SetDecay(double Decay)
{
	m_Decay = Decay;
}

void CMainFrame::SetSpeed(double Speed)
{
	m_Speed = Speed;
}

void CMainFrame::SetRadius(double Radius)
{
	m_Radius = Radius;
	m_UpdateCircle = TRUE;
}

void CMainFrame::SetOriginX(double Pos)
{
	m_OriginX = Pos;
	m_UpdateCircle = TRUE;
	m_UpdateArcTan = TRUE;
}

void CMainFrame::SetOriginY(double Pos)
{
	m_OriginY = Pos;
	m_UpdateCircle = TRUE;
	m_UpdateArcTan = TRUE;
}

void CMainFrame::SetColor(double Color)
{
	m_Color = Color;
}

void CMainFrame::SetScale(double Scale)
{
	m_Scale = Scale;
	m_UpdateCircle = TRUE;
}

void CMainFrame::SetReverse(bool Enable)
{
	m_Reverse = Enable;
	m_UpdateArcTan = TRUE;
}
