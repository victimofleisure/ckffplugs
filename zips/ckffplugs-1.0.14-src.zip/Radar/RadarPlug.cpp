// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		04jan08	add description and about text
		03		02nov09	Radar initial version
		04		09apr11	add new parameters for version 2

		freeframe radar plugin
 
*/

#include <stdafx.h>
#include "RadarPlug.h"
#include <math.h>

const PlugInfoStruct PlugInfo = {
	1,	// API major version; don't change
	0,	// API minor version; don't change
	{'R', 'A', 'D', 'R'},	// plugin identifier; MUST be 4 bytes
	{'R', 'a', 'd', 'a', 'r', ' ', ' ', ' ',
	 ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title; MUST be 16 bytes
	1	// source plugin
};

const PlugExtendedInfoStruct PlugExtInfo = {
	2,		// plugin major version
	0,		// plugin minor version
	"Radar",	// description; this IS a null-terminated string
	"Copyleft 2011 Chris Korda",	// about text; this IS a null-terminated string
	0,		// extended data size
	NULL	// extended data block
};

const RadarPlug::ParamConstantsStruct paramConstants[RadarPlug::NUM_PARAMS] = {
//			 1234567890123456		these MUST be 16 bytes long, padded with blanks
	{.1f,	"Speed           "},
	{.5f,	"Decay           "},
	{.5f,	"Radius          "},
	{0,		"Color           "},
	{.5f,	"Origin X        "},
	{.5f,	"Origin Y        "},
	{0,		"Angle           "},
	{0,		"Scale           "},
	{0,		"Reverse         "},
};

PlugInfoStruct* getInfo() 
{
	return const_cast<PlugInfoStruct *>(&PlugInfo);
}

DWORD initialise()
{
	return FF_SUCCESS;
}

DWORD deInitialise()
{
	return FF_SUCCESS;
}

DWORD getNumParameters()
{
	return RadarPlug::NUM_PARAMS;  
}

char* getParameterName(DWORD index)
{
	if (index >= 0 && index < RadarPlug::NUM_PARAMS)
		return const_cast<char *>(paramConstants[index].name);
	return "                ";
}

float getParameterDefault(DWORD index)
{
	if (index >= 0 && index < RadarPlug::NUM_PARAMS)
		return paramConstants[index].defaultValue;
	return 0;
}

RadarPlug::RadarPlug()
{
	for (int i = 0; i < NUM_PARAMS; i++) {
		m_Param[i].value = paramConstants[i].defaultValue;	// init to default values
		memset(m_Param[i].displayValue, ' ', MAX_STRING);
	}
}

RadarPlug::~RadarPlug()
{
}

char* RadarPlug::getParameterDisplay(DWORD index)
{
	memset(m_Param[index].displayValue, ' ', MAX_STRING);
	if (index >= 0 && index < NUM_PARAMS) {
		CString	s;
		s.Format("%g", m_Param[index].value);
		memcpy(m_Param[index].displayValue, s, min(s.GetLength(), MAX_STRING));
	}
	return m_Param[index].displayValue;
}

DWORD RadarPlug::setParameter(SetParameterStruct* pParam)
{
	int	index = pParam->index;
	if (index >= 0 && index < NUM_PARAMS) {
		float	val = pParam->value;
		m_Param[index].value = val;
		switch (index) {
		case SPEED:
			SetSpeed(val);
			break;
		case DECAY:
			SetDecay(val);
			break;
		case RADIUS:
			SetRadius(val);
			break;
		case COLOR:
			SetColor(val);
			break;
		case ORIGIN_X:
			SetOriginX(val);
			break;
		case ORIGIN_Y:
			SetOriginY(val);
			break;
		case ANGLE:
			SetAngle(val);
			break;
		case SCALE:
			SetScale(val);
			break;
		case REVERSE:
			SetReverse(val != 0);
			break;
		}
		return FF_SUCCESS;
	}
	return FF_FAIL;
}

float RadarPlug::getParameter(DWORD index)
{
	if (index >= 0 && index < NUM_PARAMS)
		return m_Param[index].value;
	return 0;
}

DWORD RadarPlug::processFrameCopy(ProcessFrameCopyStruct* pFrameData)
{
	return FF_FAIL;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case FF_CAP_16BITVIDEO:
		return FF_FALSE;

	case FF_CAP_24BITVIDEO:
		return FF_FALSE;

	case FF_CAP_32BITVIDEO:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_FALSE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return RadarPlug::NUM_INPUT_FRAMES;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return RadarPlug::NUM_INPUT_FRAMES;

	case FF_CAP_COPYORINPLACE:
		return FF_FALSE;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	// this shouldn't happen if the host is checking the capabilities properly
	if (pVideoInfo->bitDepth < 0 || pVideoInfo->bitDepth > 2)
		return (LPVOID) FF_FAIL;

	RadarPlug *pPlugObj = new RadarPlug;

	if (!pPlugObj->Init(*pVideoInfo)) {
		delete pPlugObj;
		return NULL;
	}

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	RadarPlug *pPlugObj = (RadarPlug*) instanceID;
	delete pPlugObj;	// delete first, THEN set to null (duh!)
	pPlugObj = NULL;	// mark instance deleted
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	return (LPVOID) &PlugExtInfo;
}
