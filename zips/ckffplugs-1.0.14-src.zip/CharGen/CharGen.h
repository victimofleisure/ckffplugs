// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version

		freeframe source plugin
 
*/

// FFSrcPlug.h : main header file for the FFSrcPlug DLL
//

#if !defined(AFX_FFSRCPLUG_H__943632C4_9EA9_474D_907B_B46E3AB934BD__INCLUDED_)
#define AFX_FFSRCPLUG_H__943632C4_9EA9_474D_907B_B46E3AB934BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFFSrcPlug
// See FFSrcPlug.cpp for the implementation of this class
//

class CFFSrcPlug : public CWinApp
{
public:
	CFFSrcPlug();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFFSrcPlug)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CFFSrcPlug)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FFSRCPLUG_H__943632C4_9EA9_474D_907B_B46E3AB934BD__INCLUDED_)
