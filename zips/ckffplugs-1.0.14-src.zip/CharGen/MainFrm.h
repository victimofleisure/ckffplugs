// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		09aug08	CharGen initial version

		freeframe character generator main frame
 
*/

#ifndef CMAINFRAME_INCLUDED
#define CMAINFRAME_INCLUDED

#include "FreeFrame.h"
#include "CharGenView.h"

struct VideoInfoStructTag;

class CMainFrame {
public:
// Construction
	CMainFrame();
	~CMainFrame();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants

// Attributes
	CCharGenView	m_View;			// our view instance

// Operations
	DWORD	processFrame(LPVOID pFrame);

private:
// Types
	typedef struct tagMYBITMAPINFO : BITMAPINFO {
		// The bmiColors array allocates a single DWORD, but in 16-bit mode,
		// bmiColors needs to contain three DWORDs: one DWORD each for the red,
		// green and blue color masks.  So we inherit from BITMAPINFO and add 
		// space for the green and blue masks; the red mask is bmiColors[0].
		DWORD	GreenMask;
		DWORD	BlueMask;
	} MYBITMAPINFO;

// Constants

// Member data
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	MYBITMAPINFO	m_bmi;		// frame DIB info
	HDC		m_hDC;				// frame DIB device context
	HBITMAP	m_hDib;				// frame DIB handle
	void	*m_DibBits;			// frame DIB data
	HGDIOBJ	m_PrevBm;			// DC's previous bitmap
	LONG	m_FrameBytes;		// size of frame in bytes
	LONG	m_BytesPerPixel;	// number of bytes per pixel

// Helpers
	static	void	TimerCallback(LPVOID Cookie);
};

#endif
