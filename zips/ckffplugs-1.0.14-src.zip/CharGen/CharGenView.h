// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
		01		09aug08	CharGen initial version
		02		14jul11	add background param

		freeframe character generator view
 
*/

// CharGenView.h : interface of the CCharGenView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CharGenView_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
#define AFX_CharGenView_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCharGenView window

#include <afxtempl.h>

class CCharGenView
{
// Construction
public:
	CCharGenView();

// Constants

// Types

// Attributes
	float	m_Character;	// character to show
	float	m_Font;			// font to use
	float	m_FontSize;		// font size
	float	m_HorzScale;	// horizontal scaling
	float	m_PosX;			// x-coordinate
	float	m_PosY;			// y-coordinate
	float	m_Rotation;		// rotation
	float	m_TextR;		// text color red
	float	m_TextG;		// text color green
	float	m_TextB;		// text color blue
	bool	m_Background;	// true if drawing background
	bool	m_Bold;			// true if bold
	bool	m_Italic;		// true if italic
	bool	m_Underline;	// true if underline

// Operations
	void	SetWndSize(CSize sz);
	void	Draw(HDC dc);

// Overrides

// Implementation
public:
	virtual ~CCharGenView();

// Generated message map functions
protected:

// Types
	typedef struct tagFONT_INFO {
		TCHAR	FaceName[LF_FACESIZE]; 
		float	AspectRatio;
	} FONT_INFO;

// Constants
	enum {
		MAX_FONT_SCALE = 4,
		MAX_HORZ_SCALE = 4,
		FIRST_CHAR = '!',
		LAST_CHAR = '~',
		NUM_CHARS = LAST_CHAR - FIRST_CHAR + 1,
	};

// Member data
	CSize	m_FrameSize;	// frame size, in pixels
	CArray<FONT_INFO, FONT_INFO&> 	m_FontInfo;

// Helpers
	static	int CALLBACK FontProc(const LOGFONT *Font, const TEXTMETRIC *Metric, DWORD FontType, LPARAM lParam);
	void	GetFonts();
	int		Denorm(float Val, int Range);
};

inline int CCharGenView::Denorm(float Val, int Range)
{
	int	i = round(Val * Range - .5);
	return(CLAMP(i, 0, Range - 1));
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CharGenView_H__4E7A57CC_64AF_47DE_98D1_C3DF8A34C524__INCLUDED_)
