// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
		01		09aug08	CharGen initial version
		02		11jul11	fix vertical centering
		03		12jul11	reselect default font
		04		14jul11	add background param
		05		19jul11	make font size logarithmic

		freeframe character generator view
 
*/

// CharGenView.cpp : implementation of the CCharGenView class
//

#include "stdafx.h"
#include "CharGenView.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCharGenView

CCharGenView::CCharGenView()
{
	m_FrameSize = CSize(0, 0);
	m_Character = 0;
	m_Font = 0;
	m_FontSize = .1f;
	m_HorzScale = .5;
	m_PosX = .5;
	m_PosY = .5;
	m_Rotation = 0;
	m_TextR = 1;
	m_TextG = 1;
	m_TextB = 1;
	m_Background = 0;
	m_Bold = 0;
	m_Italic = 0;
	m_Underline = 0;
	GetFonts();
}

CCharGenView::~CCharGenView()
{
}

int CALLBACK CCharGenView::FontProc(const LOGFONT *Font, const TEXTMETRIC *Metric, DWORD FontType, LPARAM lParam)
{
	CCharGenView	*This = (CCharGenView *)lParam;
	if (FontType == TRUETYPE_FONTTYPE) {
		FONT_INFO	fi;
		strcpy(fi.FaceName, Font->lfFaceName);
		fi.AspectRatio = float(Metric->tmAveCharWidth) / Metric->tmHeight;
		This->m_FontInfo.Add(fi);
	}
	return(TRUE);
}

void CCharGenView::GetFonts()
{
	LOGFONT	lf;
	ZeroMemory(&lf, sizeof(lf));
	lf.lfCharSet = ANSI_CHARSET;
	HDC	dc = GetDC(NULL);
	EnumFontFamiliesEx(dc, &lf, FontProc, (LPARAM)this, 0);
	ReleaseDC(NULL, dc);
}

void CCharGenView::Draw(HDC dc)
{
	HGDIOBJ	hPrevFont = NULL;
	CFont	font;
	if (m_FontInfo.GetSize()) {
		int	FontIdx = Denorm(m_Font, m_FontInfo.GetSize());
		const FONT_INFO&	fi = m_FontInfo[FontIdx];
		double	rHeight = m_FrameSize.cy 
			* (pow(MAX_FONT_SCALE, m_FontSize) - 1) + 1;
		int	Height = round(rHeight);
		int	Width;
		if (m_HorzScale == .5)
			Width = 0;
		else
			Width = round(rHeight * fi.AspectRatio 
				* pow(MAX_HORZ_SCALE, m_HorzScale * 2 - 1));
		int	Escapement = round(m_Rotation * 3600);
		font.CreateFont(
			Height,
			Width,
			Escapement,
			0,
			m_Bold ? FW_BOLD : FW_NORMAL,
			m_Italic,
			m_Underline,
			FALSE,
			ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE,
			fi.FaceName);
		hPrevFont = SelectObject(dc, font);
	}
	if (m_Background) {
		SetBkColor(dc, RGB(0, 0, 0));
		CRect	r(0, 0, m_FrameSize.cx, m_FrameSize.cy);
		ExtTextOut(dc, 0, 0, ETO_OPAQUE, r, NULL, 0, NULL);
	} else
		SetBkMode(dc, TRANSPARENT);
	COLORREF	tclr = RGB(round(m_TextR * 255), 
		round(m_TextG * 255), round(m_TextB * 255));
	SetTextColor(dc, tclr);
	SetTextAlign(dc, TA_BOTTOM);
	int	x = round(m_FrameSize.cx * (m_PosX - .5));
	int	y = round(m_FrameSize.cy * (m_PosY - .5));
	char	text = FIRST_CHAR + Denorm(m_Character, NUM_CHARS);
	CSize TextSize;
	GetTextExtentPoint32(dc, &text, 1, &TextSize);
	CPoint center;
	center.x = TextSize.cx / 2;
	center.y = TextSize.cy / 2;
	CPoint rcenter;
	double	angle = PI * 2 * m_Rotation;
	rcenter.x = round(cos(angle) * center.x - sin(angle) * center.y);
	rcenter.y = round(sin(angle) * center.x + cos(angle) * center.y);
	TextOut(dc, x + m_FrameSize.cx / 2 - rcenter.x, 
		y + m_FrameSize.cy / 2 + rcenter.y, &text, 1);
	if (hPrevFont != NULL)
		SelectObject(dc, hPrevFont);	// reselect default font
}

void CCharGenView::SetWndSize(CSize sz)
{
	m_FrameSize = sz;
}
