// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      06nov06	initial version
		01		30nov06	allow AviSynth scripts
		02		23nov07	support Unicode
		03		17dec07	support mpeg via AviSynth
		04		08may10	for mpg, reset path to clip

        player for video or still images
 
*/

#include "stdafx.h"
#include "ClipPlayer.h"
#include "shlwapi.h"

CClipPlayer::CClipPlayer()
{
	m_dd = NULL;
	m_Surface = NULL;
	m_FrameSize = 0;
	m_FrameCount = 0;
	m_FrameRate = 0;
	m_BitCount = 0;
}

CClipPlayer::~CClipPlayer()
{
	Close();
}

bool CClipPlayer::Open(LPCTSTR Path)
{
	bool	retc;
	CString	Ext = PathFindExtension(Path);
	bool	IsMpeg = !_tcsicmp(Ext, EXT_MPG);
	if (!_tcsicmp(Ext, EXT_AVI) || !_tcsicmp(Ext, EXT_AVS) || IsMpeg) {
		// CVideo::Open assumes the surface already exists; this reduces overhead
		// by allowing the surface to be reused if the frame size hasn't changed
		if (m_Video.GetSurface() == NULL && FAILED(m_Video.CreateSurface(*m_dd)))
			return(FALSE);
		if (IsMpeg) {	// create AviSynth script in temporary folder
			TCHAR	AvsPath[MAX_PATH];
			GetTempPath(MAX_PATH, AvsPath);
			PathAppend(AvsPath, _T("ClipPlay.avs"));
			CStdioFile	fp;
			if (fp.Open(AvsPath, CFile::modeCreate | CFile::modeWrite)) {
				CString	s;
				s.Format(_T("DirectShowSource(\"%s\")"), Path);
				fp.WriteString(s);
				fp.Close();
				retc = m_Video.Open(AvsPath);	// open AviSynth script
				if (retc)
					m_Video.SetPath(Path);	// reset path to clip
				DeleteFile(AvsPath);
			} else
				retc = FALSE;
		} else	// AVI file or AviSynth script
			retc = m_Video.Open(Path);
		if (retc) {
			m_Picture.Close();
			m_FrameSize = m_Video.GetFrameSize();
			m_FrameCount = m_Video.GetFrameCount();
			m_FrameRate = m_Video.GetFrameRate();
			m_BitCount = m_Video.GetBitCount();
			m_Surface = m_Video.GetSurface();
		}
	} else {	// still image
		retc = m_Picture.Open(Path, *m_dd);
		if (retc) {
			m_Video.Close();
			m_FrameSize = m_Picture.GetSize();
			m_FrameCount = 1;
			m_FrameRate = 0;
			m_BitCount = m_Picture.GetBitsPerPixel();
			m_PicturePath = Path;
			m_Surface = m_Picture.GetSurface();
		}
	}
	return(retc);
}

void CClipPlayer::Close()
{
	m_Video.Close();
	m_Picture.Close();
	m_PicturePath.Empty();
}

HRESULT CClipPlayer::CreateSurface()
{
	HRESULT	hr = 0;
	if (IsVideoOpen()) {
		if (SUCCEEDED(hr = m_Video.CreateSurface(*m_dd)))
			m_Surface = m_Video.GetSurface();
	} else if (IsPictureOpen()) {
		if (SUCCEEDED(hr = m_Picture.CreateSurface(*m_dd)))
			m_Surface = m_Picture.GetSurface();
	}
	return(hr);
}

void CClipPlayer::DestroySurface()
{
	m_Video.DestroySurface();
	m_Picture.DestroySurface();
	m_Surface = NULL;
}

bool CClipPlayer::GetProps(PROPS& Props) const
{
	if (IsVideoOpen())
		return(m_Video.GetProps(Props));
	if (m_Picture.IsOpen()) {
		ZeroMemory(&Props, sizeof(Props));
		Props.FrameSize = m_Picture.GetSize();
		Props.FrameCount = 1;
		Props.BitCount = m_Picture.GetBitsPerPixel();
		return(TRUE);
	}
	return(FALSE);
}
