// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      06nov06	initial version
        01      02dec06	add GetCurFrame
		02		04dec06	add IsFirstFrame
		03		08feb07	add Select
		04		10mar07	init m_CurIdx to 0 instead of -1

        array of clip players
 
*/

#ifndef CCLIPPLAYERLIST_INCLUDED
#define CCLIPPLAYERLIST_INCLUDED

#include "ClipPlayer.h"

class CClipPlayerList : public WObject {
public:
// Construction
	CClipPlayerList();

// Constants
	enum {
		MAX_CLIPS = 10	// maximum number of open clips
	};

// Types
	typedef CClipPlayer::PROPS PROPS;
	
// Attributes
	bool	IsOpen() const;
	bool	IsVideoOpen() const;
	bool	IsPictureOpen() const;
	SIZE	GetFrameSize() const;
	DWORD	GetFrameCount() const;
	DWORD	GetCurFrame() const;
	float	GetFrameRate() const;
	DWORD	GetBitCount() const;
	LPCSTR	GetPath() const;
	HRESULT	GetLastError() const;
	LPDIRECTDRAWSURFACE	GetSurface();
	bool	GetProps(PROPS& Props) const;
	void	SetBackBuf(CBackBufDD& BackBuf);
	void	SetAutoRewind(bool Enable);
	bool	IsFirstFrame() const;
	int		GetCurSel() const;

// Operations
	void	CreateSurfaces();
	void	DestroySurfaces();
	bool	Open(LPCSTR Path);
	void	Close();
	bool	Select(int Pos);
	bool	SelectRelative(int Delta);
	bool	SelectNext();
	bool	SelectPrev();
	void	Deselect();

// Video operations
	bool	TimerHook();
	void	Rewind();
	void	Seek(DWORD Frame);

private:
// Member data
	CClipPlayer	m_Clip[MAX_CLIPS];	// array of videos
	CDWordArray	m_List;		// video indices, in most recently used order
	int		m_CurIdx;		// index of current video
	int		m_CurPos;		// current video's position in list, or -1 if none
	bool	m_AutoRewind;	// if true, play clips from the beginning

// Helpers
	CClipPlayer&	GetCurVideo();
	const	CClipPlayer& GetCurVideo() const;
	void	PlayVideo(int Pos, int Idx);
};

inline CClipPlayer& CClipPlayerList::GetCurVideo()
{
	ASSERT(m_CurIdx >= 0);
	return(m_Clip[m_CurIdx]);
}

inline const CClipPlayer& CClipPlayerList::GetCurVideo() const
{
	ASSERT(m_CurIdx >= 0);
	return(m_Clip[m_CurIdx]);
}

inline bool CClipPlayerList::IsOpen() const
{
	return(GetCurVideo().IsOpen());
}

inline bool CClipPlayerList::IsVideoOpen() const
{
	return(GetCurVideo().IsVideoOpen());
}

inline bool CClipPlayerList::IsPictureOpen() const
{
	return(GetCurVideo().IsPictureOpen());
}

inline SIZE CClipPlayerList::GetFrameSize() const
{
	return(GetCurVideo().GetFrameSize());
}

inline DWORD CClipPlayerList::GetFrameCount() const
{
	return(GetCurVideo().GetFrameCount());
}

inline DWORD CClipPlayerList::GetCurFrame() const
{
	return(GetCurVideo().GetCurFrame());
}

inline float CClipPlayerList::GetFrameRate() const
{
	return(GetCurVideo().GetFrameRate());
}

inline DWORD CClipPlayerList::GetBitCount() const
{
	return(GetCurVideo().GetBitCount());
}

inline LPCSTR CClipPlayerList::GetPath() const
{
	return(GetCurVideo().GetPath());
}

inline HRESULT CClipPlayerList::GetLastError() const
{
	return(GetCurVideo().GetLastError());
}

inline LPDIRECTDRAWSURFACE CClipPlayerList::GetSurface()
{
	return(GetCurVideo().GetSurface());
}

inline void CClipPlayerList::SetAutoRewind(bool Enable)
{
	m_AutoRewind = Enable;
}

inline bool CClipPlayerList::TimerHook()
{
	return(GetCurVideo().TimerHook());
}

inline void	CClipPlayerList::Close()
{
	GetCurVideo().Close();
}

inline void	CClipPlayerList::Rewind()
{
	GetCurVideo().Rewind();
}

inline void	CClipPlayerList::Seek(DWORD Frame)
{
	GetCurVideo().Seek(Frame);
}

inline bool CClipPlayerList::IsFirstFrame() const
{
	return(GetCurVideo().IsFirstFrame());
}

inline int CClipPlayerList::GetCurSel() const
{
	return(m_CurPos);
}

inline bool CClipPlayerList::SelectNext()
{
	return(SelectRelative(1));
}

inline bool CClipPlayerList::SelectPrev()
{
	return(SelectRelative(-1));
}

inline void CClipPlayerList::Deselect()
{
	m_CurPos = -1;
}

#endif
