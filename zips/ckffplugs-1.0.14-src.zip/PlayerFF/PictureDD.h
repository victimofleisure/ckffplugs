// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      22aug06	initial version
        01      11oct06	add DestroySurface
        02      28oct06	add GetBitsPerPixel
        03      06nov06	make IsOpen a wrapper
		04		23nov07	support Unicode

        IPicture wrapper with DirectDraw surface
 
*/

#ifndef CPICTUREDD_INCLUDED
#define CPICTUREDD_INCLUDED

#include "Picture.h"
#include "BackBufDD.h"

class CPictureDD : public WObject {
public:
// Construction
	CPictureDD();
	~CPictureDD();

// Attributes
	bool	IsOpen() const;
	SIZE	GetSize() const;
	LPDIRECTDRAWSURFACE	GetSurface();
	HRESULT	GetLastError() const;
	bool	GetBitmap(BITMAP& Bitmap) const;
	DWORD	GetBitsPerPixel() const;

// Operations
	bool	Open(LPCTSTR Path, CBackBufDD& BackBuf);
	void	Close();
	bool	UpdateSurface();
	bool	CreateSurface(CBackBufDD& BackBuf);
	void	DestroySurface();

protected:
// Member data
	CPicture	m_Picture;	// IPicture wrapper
	CSize	m_Size;			// size of picture in pixels
	LPDIRECTDRAWSURFACE	m_Surface;	// pointer to DirectDraw surface
	HRESULT	m_hr;			// most recent DirectDraw result code
};

inline bool	CPictureDD::IsOpen() const
{
	return(m_Picture.IsOpen());
}

inline SIZE CPictureDD::GetSize() const
{
	return(m_Size);
}

inline LPDIRECTDRAWSURFACE CPictureDD::GetSurface()
{
	return(m_Surface);
}

inline HRESULT CPictureDD::GetLastError() const
{
	return(m_hr);
}

#endif
