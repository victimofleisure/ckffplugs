// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      06nov06	adapt demo for clip player
        02      02dec06	add speed parameter
		03		08feb07	add recent clips parameter
		04		06mar07	add defer bank change

		freeframe source plugin
 
*/

#ifndef PLAYERFFPLUG_INCLUDED
#define PLAYERFFPLUG_INCLUDED

#include "FreeFrame.h"
#include "MainFrm.h"

class PlayerFFPlug : public CMainFrame {
public:
// Constants
	enum {
		BANK,
		CLIP,
		POSITION,
		SPEED,
		PLAY,
		AUTO_REWIND,
		RECENT_CLIPS,
		DEFER_BANK_CHG,
		NUM_PARAMS
	};
	enum {
		NUM_INPUT_FRAMES = 1,
		MAX_STRING = 16
	};

// Types
	typedef struct ParamConstsStructTag {
		float defaultValue;
		char name[MAX_STRING + 1];
	} ParamConstantsStruct;
	typedef struct ParamDynamicDataStructTag {
		float value;
		char displayValue[MAX_STRING];
	} ParamDynamicDataStruct;

// Construction
	PlayerFFPlug();
	~PlayerFFPlug();

// Attributes
	char*	getParameterDisplay(DWORD index);			
	DWORD	setParameter(SetParameterStruct* pParam);		
	float	getParameter(DWORD index);

// Operations
	// processFrame is inherited from base class
	DWORD	processFrameCopy(ProcessFrameCopyStruct* pFrameData);

private:
// Member data
	ParamDynamicDataStruct m_Param[NUM_PARAMS];
};

PlugInfoStruct*	getInfo();							
DWORD	initialise();								
DWORD	deInitialise();								
DWORD	getNumParameters();							
char*	getParameterName(DWORD index);				
float	getParameterDefault(DWORD index);			
DWORD	getPluginCaps(DWORD index);	
LPVOID	instantiate(VideoInfoStruct* pVideoInfo);
DWORD	deInstantiate(LPVOID instanceID);	
LPVOID	getExtendedInfo();		

#endif
