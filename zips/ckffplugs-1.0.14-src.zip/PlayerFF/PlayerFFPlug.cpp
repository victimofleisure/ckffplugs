// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      06nov06	adapt demo for clip player
        02      02dec06	add speed parameter
        03      30dec06	bump version
		04		08feb07	add recent clips parameter
		05		06mar07	add defer bank change
		06		09mar07	add letterbox configuration
        07      17dec07	bump version
        08      05may10	bump version
		09		07may10	add FFRend API
		10		07may12	in setParameter, return fail if clip path won't open

		freeframe source plugin
 
*/

#include <stdafx.h>
#include "PlayerFFPlug.h"
#include <math.h>

const PlugInfoStruct PlugInfo = {
	1,	// API major version
	0,	// API minor version
#ifdef LETTERBOX
	{'P', 'L', 'L', 'B'},	// plugin identifier
	{'P', 'l', 'a', 'y', 'e', 'r', 'F', 'F',
	 'L', 'B', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title
#else
	{'P', 'L', 'Y', 'R'},	// plugin identifier
	{'P', 'l', 'a', 'y', 'e', 'r', 'F', 'F',
	 ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title
#endif
	1	// source plugin
};

const PlugExtendedInfoStruct PlugExtInfo = {
	2,		// plugin major version
	100,	// plugin minor version
#ifdef LETTERBOX
	"Clip Player Letterbox",	// description
#else
	"Clip Player",	// description
#endif
	"Copyleft 2010 Chris Korda",	// about text
	0,		// extended data size
	NULL	// extended data block
};

const PlayerFFPlug::ParamConstantsStruct paramConstants[PlayerFFPlug::NUM_PARAMS] = {
// TODO: add default values and names of your plugin's parameters here
//			 1234567890123456
	{0,		"Bank            "},
	{0,		"Clip            "},
	{0,		"Position        "},
	{.6f,	"Speed           "},
	{1,		"Play            "},
	{0,		"Auto-Rewind     "},
	{0,		"Recent Clips    "},
	{0,		"Defer Bank Chg  "},
};

enum {	// secret API between FFRend and PlayerFF
	FFREND_PLAYER_CLIP_PATH = 666,
	FFREND_PLAYER_QUIET_SET_BANK,
	FFREND_PLAYER_QUIET_SET_CLIP,
	FFREND_PLAYER_SKIP_INITIAL_OPEN,
	FFREND_PLAYER_DO_INITIAL_OPEN,
};

PlugInfoStruct* getInfo() 
{
	return const_cast<PlugInfoStruct *>(&PlugInfo);
}

DWORD getNumParameters()
{
	return PlayerFFPlug::NUM_PARAMS;  
}

char* getParameterName(DWORD index)
{
	if (index >= 0 && index < PlayerFFPlug::NUM_PARAMS)
		return const_cast<char *>(paramConstants[index].name);
	return "                ";
}

float getParameterDefault(DWORD index)
{
	if (index >= 0 && index < PlayerFFPlug::NUM_PARAMS)
		return paramConstants[index].defaultValue;
	return 0;
}

PlayerFFPlug::PlayerFFPlug()
{
	for (int i = 0; i < NUM_PARAMS; i++) {
		m_Param[i].value = paramConstants[i].defaultValue;
		memset(m_Param[i].displayValue, ' ', MAX_STRING);
	}
}

PlayerFFPlug::~PlayerFFPlug()
{
}

char* PlayerFFPlug::getParameterDisplay(DWORD index)
{
	memset(m_Param[index].displayValue, ' ', MAX_STRING);
	if (index >= 0 && index < NUM_PARAMS) {
		CString	s;
		s.Format("%g", m_Param[index].value);
		memcpy(m_Param[index].displayValue, s, min(s.GetLength(), MAX_STRING));
	}
	return m_Param[index].displayValue;
}

DWORD PlayerFFPlug::setParameter(SetParameterStruct* pParam)
{
	int	index = pParam->index;
	if (index >= 0 && index < NUM_PARAMS) {
		float	val = pParam->value;
		m_Param[index].value = val;
		switch (index) {
		case BANK:
			SetBank(val);
			break;
		case CLIP:
			SetClip(val);
			break;
		case POSITION:
			SetPos(val);
			break;
		case SPEED:
			SetSpeed(val);
			break;
		case PLAY:
			Play(val != 0);
			break;
		case AUTO_REWIND:
			SetAutoRewind(val != 0);
			break;
		case RECENT_CLIPS:
			SelectRecentClip(val);
			break;
		case DEFER_BANK_CHG:
			SetDeferBankChange(val != 0);
			break;
		}
	} else {
		switch (index) {
		case FFREND_PLAYER_CLIP_PATH:
			{
				// cast float to const char pointer
				LPCSTR	Path = LPCSTR(*((DWORD *)&pParam->value));
				if (!Open(Path))
					return FF_FAIL;
			}
			break;
		case FFREND_PLAYER_QUIET_SET_BANK:
			QuietSetBank(pParam->value);
			break;
		case FFREND_PLAYER_QUIET_SET_CLIP:
			QuietSetClip(pParam->value);
			break;
		default:
			return FF_FAIL;
		}
	}
	return FF_SUCCESS;
}

float PlayerFFPlug::getParameter(DWORD index)
{
	if (index >= 0 && index < NUM_PARAMS)
		return m_Param[index].value;
	else {
		if (index == FFREND_PLAYER_CLIP_PATH) {
			float	val;
			// cast const char pointer to float
			*((DWORD *)&val) = DWORD(GetPath());
			return(val);
		}
	}
	return 0;
}

DWORD PlayerFFPlug::processFrameCopy(ProcessFrameCopyStruct* pFrameData)
{
	return FF_FAIL;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case FF_CAP_16BITVIDEO:
		return FF_TRUE;

	case FF_CAP_24BITVIDEO:
		return FF_TRUE;

	case FF_CAP_32BITVIDEO:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_FALSE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return PlayerFFPlug::NUM_INPUT_FRAMES;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return PlayerFFPlug::NUM_INPUT_FRAMES;

	case FF_CAP_COPYORINPLACE:
		return FF_FALSE;

	case FFREND_PLAYER_SKIP_INITIAL_OPEN:
		PlayerFFPlug::SetInitialOpen(FALSE);	// skip initial SetClip
		return FF_TRUE;

	case FFREND_PLAYER_DO_INITIAL_OPEN:
		PlayerFFPlug::SetInitialOpen(TRUE);	// do initial SetClip as usual
		return FF_TRUE;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	// this shouldn't happen if the host is checking the capabilities properly
	if (pVideoInfo->bitDepth < 0 || pVideoInfo->bitDepth > 2)
		return (LPVOID) FF_FAIL;

	PlayerFFPlug *pPlugObj = new PlayerFFPlug;

	if (!pPlugObj->Init(*pVideoInfo)) {
		delete pPlugObj;
		return NULL;
	}

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	PlayerFFPlug *pPlugObj = (PlayerFFPlug*) instanceID;
	delete pPlugObj;	// delete first, THEN set to null (duh!)
	pPlugObj = NULL;	// mark instance deleted
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	return (LPVOID) &PlugExtInfo;
}
