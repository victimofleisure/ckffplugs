// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      06nov06	adapt demo for clip player
        02      02dec06	add SetSpeed and jog state
		03		04dec06	coalesce seeks
		04		30dec06	make video flipping conditional
		05		08feb07	add recent clips parameter
		06		06mar07	add defer bank change
		07		08mar07	back buffer was at file scope, make it a member
		08		09mar07	add letterbox configuration
		09		10mar07	validate clip extensions
		10		05may10	in processFrame, always reset default surface
		11		07may10	add FFRend API
		12		07may12	reset seek in SelectRecentClip

		freeframe source plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"
#include "Win32Console.h"
#include "BackBufDD.h"
#include "PathStr.h"
#include <math.h>

#define SAFE_RELEASE(p) { if (p) { (p)->Release(); (p) = NULL; } }

const LPCSTR CMainFrame::m_ClipExt[CLIP_EXTS] = {
	".avi",
	".jpg",
	".gif",
	".bmp",
	".avs"
};

#ifdef LETTERBOX
#define DEST_RECT m_Letterbox	// destination rectangle is letterbox
#else
#define DEST_RECT NULL
#endif

bool	CMainFrame::m_InitialOpen = TRUE;	// by default, do initial SetClip

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	m_Surface = NULL;
	m_SurfaceBits = NULL;
	m_FrameSize = CSize(0, 0);
	m_BitCount = 0;
	m_CurBank = 0;
	m_CurClip = -1;
	m_CurClipNorm = 0;
	m_JogDelta = 1;
	m_JogFrame = 0;
	m_SeekFrame = 0;
	m_Seeking = FALSE;
	m_Playing = TRUE;
	m_Jogging = FALSE;
	m_DeferBankChange = FALSE;
	m_ClipPath.SetSize(1);	// start with one bank
}

CMainFrame::~CMainFrame()
{
	m_dd.Destroy();
}

DWORD initialise()
{
#ifdef _DEBUG
	Win32Console::Create();
#endif
	return FF_SUCCESS;
}

DWORD deInitialise()
{
	return FF_SUCCESS;
}

bool CMainFrame::CreateSurface()
{
	SAFE_RELEASE(m_Surface);
	DDSURFACEDESC	sd;
	ZeroMemory(&sd, sizeof(sd));
	sd.dwSize = sizeof(sd);
	sd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	sd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_3DDEVICE | DDSCAPS_SYSTEMMEMORY;
	sd.dwWidth = 1;
	sd.dwHeight	= 1;
	return(SUCCEEDED(m_dd.CreateSurface(&sd, &m_Surface)));
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	if (!m_dd.Create(NULL, NULL))
		return(FALSE);
	if (!CreateSurface())
		return(FALSE);
	m_VideoInfo = videoInfo;
	m_FrameSize = CSize(m_VideoInfo.frameWidth, m_VideoInfo.frameHeight);
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_BitCount = 16;
		break;
	case FF_CAP_24BITVIDEO:
		m_BitCount = 24;
		break;
	case FF_CAP_32BITVIDEO:
		m_BitCount = 32;
		break;
	default:
		return(FALSE);
	}
	m_Clip.SetBackBuf(m_dd);
	if (!LoadClips())
		return(FALSE);
	if (m_InitialOpen)
		SetClip(0);
	return(TRUE);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	DDSURFACEDESC	sd;
	ZeroMemory(&sd, sizeof(sd));
	sd.dwSize = sizeof(sd);
	sd.dwFlags = DDSD_WIDTH | DDSD_HEIGHT | DDSD_PITCH 
		| DDSD_LPSURFACE | DDSD_PIXELFORMAT;
	sd.dwWidth = m_FrameSize.cx;
	sd.dwHeight = m_FrameSize.cy;
	sd.lPitch = m_FrameSize.cx * m_BitCount / 8;
	sd.lpSurface = pFrame;
	sd.ddpfPixelFormat.dwSize = sizeof(DDPIXELFORMAT);
	sd.ddpfPixelFormat.dwRGBBitCount = m_BitCount;
	switch (m_BitCount) {
	case 16:
		sd.ddpfPixelFormat.dwFlags = DDPF_RGB;
		sd.ddpfPixelFormat.dwRBitMask = 0xf800;	// 5-6-5
		sd.ddpfPixelFormat.dwGBitMask = 0x07e0;
		sd.ddpfPixelFormat.dwBBitMask = 0x001f;
		break;
	case 24:
	case 32:
		sd.ddpfPixelFormat.dwFlags = DDPF_RGB;
		sd.ddpfPixelFormat.dwRBitMask = 0xff0000;
		sd.ddpfPixelFormat.dwGBitMask = 0x00ff00;
		sd.ddpfPixelFormat.dwBBitMask = 0x0000ff;
		break;
	}
	if (FAILED(m_Surface->SetSurfaceDesc(&sd, 0)))
		return(FF_FAIL);
#ifdef LETTERBOX	// clear frame first so letterbox is black
	ZeroMemory(pFrame, m_FrameSize.cx * m_FrameSize.cy * (m_BitCount >> 3));
#endif
	DWORD	retc = FF_SUCCESS;
	if (m_Clip.IsVideoOpen()) {	// if a video file is open
		if (m_Seeking) {	// if a seek is pending
			m_Clip.Seek(m_SeekFrame);	// sets first frame flag
			m_Seeking = FALSE;
		}
		if (m_Playing) {
			if (m_Jogging && !m_Clip.IsFirstFrame()) {
				m_JogFrame += m_JogDelta;
				int	frame = round(m_JogFrame);
				int	frames = m_Clip.GetFrameCount();
				// handle wraparound; assume delta < frames
				if (frame < 0) {
					frame += frames;
					m_JogFrame += frames;
				} else if (frame > frames - 1) {
					frame -= frames;
					m_JogFrame -= frames;
				}
				frame = CLAMP(frame, 0, frames - 1);	// safety net
				m_Clip.Seek(frame);	// sets first frame flag
			}
			// if first frame, TimerHook clears flag instead of reading
			if (!m_Clip.TimerHook())
				retc = FF_FAIL;
		}
		DDBLTFX	fx;
		ZeroMemory(&fx, sizeof(fx));
		fx.dwSize = sizeof(fx);
		if (m_VideoInfo.orientation != FF_ORIGIN_BOTTOM_LEFT)
			fx.dwDDFX = DDBLTFX_MIRRORUPDOWN;	// vertically flip video
		m_Surface->Blt(DEST_RECT, // blit video frame to plugin frame
			m_Clip.GetSurface(), NULL,	DDBLT_WAIT | DDBLT_DDFX, &fx);
	} else if (m_Clip.IsPictureOpen()) {	// if a picture file is open
		m_Surface->Blt(DEST_RECT,	// blit picture frame to plugin frame
			m_Clip.GetSurface(), NULL, DDBLT_WAIT, NULL);
	} else {	// display no clip message
		static const LPCSTR	NoClip = "NO CLIP";
		HDC	dc;
		m_Surface->GetDC(&dc);
		CFont	f;
		f.CreatePointFont(m_FrameSize.cx, "", NULL);
		SelectObject(dc, f);
		FillRect(dc, CRect(0, 0, m_FrameSize.cx, m_FrameSize.cy),
			(HBRUSH)GetStockObject(BLACK_BRUSH));
		SetTextAlign(dc, TA_CENTER | TA_BASELINE);
		SetTextColor(dc, RGB(255, 255, 255));
		SetBkColor(dc, RGB(0, 0, 0));
		TextOut(dc, m_FrameSize.cx / 2, m_FrameSize.cy / 2, NoClip, strlen(NoClip));
		m_Surface->ReleaseDC(dc);
	}
	m_Surface->SetSurfaceDesc(CVideo::GetDefaultSurface(), 0);	// avoids leaking a frame
	return(retc);
}

void CMainFrame::SetPos(float Pos)
{
	if (m_Clip.IsVideoOpen()) {
		int	frames = m_Clip.GetFrameCount();
		m_SeekFrame = min(trunc(Pos * frames), frames - 1);
		if (m_Jogging)
			m_JogFrame = float(m_SeekFrame);
		m_Seeking = TRUE;
	}
}

void CMainFrame::SetSpeed(float Speed)
{
	// Speed:	0	.1	.2	.3	.4	.5	.6	.7	.8	.9	1
	// Delta:	-16	-8	-4	-2	-1	0	1	2	4	8	16
	bool	jog = Speed != .6f;
	if (jog && !m_Jogging)	// if transition to jogging
		m_JogFrame = float(m_Clip.GetCurFrame());
	m_Jogging = jog;
	if (Speed > .6)
		m_JogDelta = float(pow(2, (Speed - .6) * 10));
	else if (Speed < .4)
		m_JogDelta = float(-pow(2, (.4 - Speed) * 10));
	else	// .4 to .6
		m_JogDelta = float((Speed - .5) * 10);	// linear mapping
}

#ifdef _DEBUG
void CMainFrame::DumpBanks()
{
	int	banks = m_ClipPath.GetSize();
	printf("%d banks\n", banks);
	for (int i = 0; i < m_ClipPath.GetSize(); i++) {
		int	clips = m_ClipPath[i].GetSize();
		printf("bank %d: %d clips\n", i, clips);
		for (int j = 0; j < clips; j++) {
			printf("%d: [%s]\n", j, m_ClipPath[i][j]);
		}
	}
}
#endif

bool CMainFrame::LoadClips()
{
	CPathStr	ClipFolder;
	char	*p = ClipFolder.GetBuffer(MAX_PATH);
	bool	retc = SUCCEEDED(SHGetSpecialFolderPath(NULL, p, CSIDL_PERSONAL, 0));
	if (!retc)
		return(FALSE);
	ClipFolder.ReleaseBuffer();
	ClipFolder.Append("PlayerFF");
	CPathStr	PlaylistPath(ClipFolder);
	PlaylistPath.Append("playlist.txt");
	CStdioFile	fp;
	int	bank = 0;
	if (fp.Open(PlaylistPath, CFile::modeRead | CFile::shareDenyWrite)) {
		CString	s;
		while (fp.ReadString(s)) {
			s.TrimLeft();
			s.TrimRight();
			if (s.IsEmpty())
				continue;	// ignore blank lines
			if (sscanf(s, ":%d\n", &bank) == 1) {
				bank = max(bank, 0);
				if (bank >= m_ClipPath.GetSize())
					m_ClipPath.SetSize(bank + 1);
			} else {
				m_ClipPath[bank].Add(s);
			}
		}
	} else {
		CPathStr	FindPath(ClipFolder);
		FindPath.Append("\\*.*");
		CFileFind	ff;
		BOOL bWorking = ff.FindFile(FindPath);
		while (bWorking) {
			bWorking = ff.FindNextFile();
			if (!ff.IsDirectory()) {
				CString	name = ff.GetFileName();
				LPCTSTR	Ext = PathFindExtension(name);
				int	i;
				for (i = 0; i < CLIP_EXTS; i++) {
					if (!stricmp(Ext, m_ClipExt[i]))
						break;
				}
				if (i < CLIP_EXTS)
					m_ClipPath[0].Add(ff.GetFilePath());
			}
		}
		m_ClipPath[0].Sort();
	}
#ifdef _DEBUG
	DumpBanks();
#endif
	return(TRUE);
}

bool CMainFrame::SetBank(float Bank)
{
	int	banks = m_ClipPath.GetSize();
	if (banks <= 0)
		return(TRUE);
	int	Idx = min(trunc(Bank * banks), banks - 1);
	if (Idx == m_CurBank)
		return(TRUE);
	m_CurBank = Idx;
	m_CurClip = -1;	// defeat caching
	if (m_DeferBankChange)
		return(TRUE);
	return(SetClip(m_CurClipNorm));
}

bool CMainFrame::SetClip(float Clip)
{
	int	clips = m_ClipPath[m_CurBank].GetSize();
	if (clips <= 0)
		return(TRUE);
	int	Idx = min(trunc(Clip * clips), clips - 1);
	if (Idx == m_CurClip)
		return(TRUE);
	m_CurClip = Idx;
	m_CurClipNorm = Clip;
	bool	retc = m_Clip.Open(m_ClipPath[m_CurBank][m_CurClip]);
	ResetSeek();
#ifdef LETTERBOX
	UpdateLetterbox();
#endif
	return(retc);
}

void CMainFrame::QuietSetBank(float Bank)
{
	int	banks = m_ClipPath.GetSize();
	if (banks > 0)
		m_CurBank = min(trunc(Bank * banks), banks - 1);
}

void CMainFrame::QuietSetClip(float Clip)
{
	int	clips = m_ClipPath[m_CurBank].GetSize();
	if (clips > 0) {
		m_CurClip = min(trunc(Clip * clips), clips - 1);
		m_CurClipNorm = Clip;
	}
}

void CMainFrame::SelectRecentClip(float Clip)
{
	int	sel = trunc(Clip * MAX_CLIPS);
	sel = min(sel, MAX_CLIPS - 1);
	if (sel == m_Clip.GetCurSel())
		return;	// nothing to do
	m_Clip.Select(sel);
	ResetSeek();
#ifdef LETTERBOX
	UpdateLetterbox();
#endif
}

void CMainFrame::UpdateLetterbox()
{
	CSize	SrcSz = m_Clip.GetFrameSize();
	CSize	DstSz = m_FrameSize;
	CRect	r(0, 0, DstSz.cx, DstSz.cy);
	float	SrcAsp = float(SrcSz.cy) / SrcSz.cx;
	float	DstAsp = float(DstSz.cy) / DstSz.cx;
	if (SrcAsp > DstAsp)
		r.right = round(SrcSz.cx * (float(DstSz.cy) / SrcSz.cy));
	else
		r.bottom = round(SrcSz.cy * (float(DstSz.cx) / SrcSz.cx));
	if (r.right < DstSz.cx)
		r.OffsetRect((DstSz.cx - r.right) / 2, 0);
	if (r.bottom < DstSz.cy)
		r.OffsetRect(0, (DstSz.cy - r.bottom) / 2);
	m_Letterbox = r;
}
