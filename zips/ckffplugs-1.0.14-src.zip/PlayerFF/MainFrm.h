// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      06nov06	adapt demo for clip player
        02      02dec06	add SetSpeed and jog state
		03		04dec06	coalesce seeks
		04		08feb07	add recent clips parameter
		05		06mar07	add defer bank change
		06		08mar07	back buffer was at file scope, make it a member
		07		09mar07	add letterbox configuration
		08		10mar07	validate clip extensions
		09		05may10	remove update surface
		10		07may10	add FFRend API
		11		07may12	reset seek in Open

		freeframe source plugin's surrogate main frame window
 
*/

#ifndef CMAINFRAME_INCLUDED
#define CMAINFRAME_INCLUDED

#include "FreeFrame.h"
#include "ClipPlayerList.h"
#include "SortStringArray.h"
#include <afxtempl.h>

struct VideoInfoStructTag;

class CMainFrame {
public:
// Construction
	CMainFrame();
	~CMainFrame();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants
	enum {
		MAX_CLIPS = CClipPlayerList::MAX_CLIPS
	};

// Attributes
	bool	SetBank(float Bank);
	bool	SetClip(float Clip);
	void	Play(bool Enable);
	void	SetPos(float Pos);
	void	SetAutoRewind(bool Enable);
	void	SetSpeed(float Speed);
	void	SelectRecentClip(float Clip);
	void	SetDeferBankChange(bool Enable);
	LPCTSTR	GetPath() const;
	static	void	SetInitialOpen(bool Enable);
	void	QuietSetBank(float Bank);
	void	QuietSetClip(float Clip);

// Operations
	DWORD	processFrame(LPVOID pFrame);
	bool	Open(LPCSTR Path);

private:
// Constants
	enum {
		CLIP_EXTS = 5
	};
	static const LPCSTR	m_ClipExt[CLIP_EXTS];	// supported clip extensions

// Types
	typedef CArray<CSortStringArray, CSortStringArray&>	CBank;

// Member data
	CBackBufDD	m_dd;				// DirectDraw back buffer
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	CClipPlayerList	m_Clip;			// array of clip players
	LPDIRECTDRAWSURFACE	m_Surface;	// DirectDraw frame buffer
	LPVOID	m_SurfaceBits;			// frame buffer's memory
	CSize	m_FrameSize;			// frame size, in pixels
	DWORD	m_BitCount;				// color depth, in bits per pixel
	int		m_CurBank;				// index of currently selected bank
	int		m_CurClip;				// index of currently selected clip
	float	m_CurClipNorm;			// normalized clip selection
	float	m_JogDelta;				// frames to jog per timer tick
	float	m_JogFrame;				// current frame when jogging
	int		m_SeekFrame;			// frame to seek
	bool	m_Seeking;				// true if seek is pending
	bool	m_Playing;				// true if playing, false if paused
	bool	m_Jogging;				// true if playback speed isn't x1 forward
	bool	m_DeferBankChange;		// if true, defer bank change until next clip change
	CBank	m_ClipPath;				// list of clip paths in special folder
	CRect	m_Letterbox;			// letterbox rectangle
	static	bool	m_InitialOpen;	// true if initial SetClip is enabled

// Helpers
	bool	CreateSurface();
	bool	LoadClips();
	void	DumpBanks();
	void	UpdateLetterbox();
	void	ResetSeek();
};

inline void CMainFrame::Play(bool Enable)
{
	m_Playing = Enable;
}

inline void CMainFrame::SetAutoRewind(bool Enable)
{
	m_Clip.SetAutoRewind(Enable);
}

inline void CMainFrame::SetDeferBankChange(bool Enable)
{
	m_DeferBankChange = Enable;
}

inline bool CMainFrame::Open(LPCSTR Path)
{
	if (!m_Clip.Open(Path))
		return(FALSE);
	ResetSeek();
#ifdef LETTERBOX
	UpdateLetterbox();
#endif
	return(TRUE);
}

inline LPCTSTR CMainFrame::GetPath() const
{
	return(m_Clip.GetPath());
}

inline void CMainFrame::SetInitialOpen(bool Enable)
{
	m_InitialOpen = Enable;
}

inline void CMainFrame::ResetSeek()
{
	if (m_Jogging)	// if jogging, update jog position
		m_JogFrame = float(m_Clip.GetCurFrame());
	m_Seeking = FALSE;	// cancel any pending seeks
}

#endif
