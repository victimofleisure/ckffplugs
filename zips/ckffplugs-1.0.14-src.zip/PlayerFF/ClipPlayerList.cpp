// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      06nov06	initial version
		01		08feb07	add Select
		02		10mar07	init m_CurIdx to 0 instead of -1

        array of clip players
 
*/

#include "stdafx.h"
#include "ClipPlayerList.h"

CClipPlayerList::CClipPlayerList()
{
	m_List.SetSize(MAX_CLIPS);
	for (int i = 0; i < MAX_CLIPS; i++)
		m_List[i] = i;
	m_CurIdx = 0;
	m_CurPos = -1;
	m_AutoRewind = FALSE;
}

void CClipPlayerList::SetBackBuf(CBackBufDD& BackBuf)
{
	for (int i = 0; i < MAX_CLIPS; i++)
		m_Clip[i].SetBackBuf(BackBuf);
}

void CClipPlayerList::CreateSurfaces()
{
	for (int i = 0; i < MAX_CLIPS; i++)
		m_Clip[i].CreateSurface();
}

void CClipPlayerList::DestroySurfaces()
{
	for (int i = 0; i < MAX_CLIPS; i++)
		m_Clip[i].DestroySurface();
}

inline void CClipPlayerList::PlayVideo(int Pos, int Idx)
{
	m_CurPos = Pos;
	m_CurIdx = Idx;
	if (m_AutoRewind && Idx >= 0)
		m_Clip[Idx].Rewind();
}

bool CClipPlayerList::Open(LPCSTR Path)
{
	ASSERT(Path != NULL);
	if (!Path[0])	// else search gives false positive
		return(FALSE);
	int	i, Idx = 0;
	for (i = 0; i < MAX_CLIPS; i++) {	// search our list for path
		Idx = m_List[i];
		if (!strcmp(Path, m_Clip[Idx].GetPath()))
			break;
	}
	if (i < MAX_CLIPS)	{				// if clip is already open
		m_List.RemoveAt(i);
		m_List.InsertAt(0, Idx);			// move it to front of list
		if (m_AutoRewind)
			m_Clip[Idx].Rewind();
	} else {
		Idx = m_List[MAX_CLIPS - 1];	// least recently used slot
		if (!m_Clip[Idx].Open(Path)) 	// open clip in LRU slot
			return(FALSE);
		m_List.RemoveAt(MAX_CLIPS - 1);
		m_List.InsertAt(0, Idx);			// move it to front	of list
	}
	PlayVideo(0, Idx);						// make it current
	return(TRUE);
}

bool CClipPlayerList::SelectRelative(int Delta)
{
	int	Lower = 0, Upper = MAX_CLIPS - 1;
	int	Pos = m_CurPos;
	for (int i = 0; i < MAX_CLIPS; i++) {
		Pos += Delta;	// bump and wrap
		if (Pos < Lower)
			Pos = Upper;
		else if (Pos > Upper)
			Pos = Lower;
		int	Vid = m_List[Pos];
		if (m_Clip[Vid].IsOpen()) {
			PlayVideo(Pos, Vid);
			return(TRUE);
		}
	}
	return(FALSE);
}

bool CClipPlayerList::Select(int Pos)
{
	if (Pos >= 0 && Pos < MAX_CLIPS) {
		int	Vid = m_List[Pos];
		if (m_Clip[Vid].IsOpen()) {
			PlayVideo(Pos, Vid);
			return(TRUE);
		}
	} else
		Deselect();
	return(FALSE);
}
