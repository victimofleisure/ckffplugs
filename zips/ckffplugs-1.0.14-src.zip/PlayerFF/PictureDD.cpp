// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      22aug06	initial version
        01      11oct06	add DestroySurface
        02      28oct06	add GetBitsPerPixel
		03		23nov07	support Unicode

        IPicture wrapper with DirectDraw surface
 
*/

#include "stdafx.h"
#include "PictureDD.h"

#define SAFE_RELEASE(p) { if (p) { (p)->Release(); (p) = NULL; } }

CPictureDD::CPictureDD()
{
	m_Size = CSize(0, 0);
	m_Surface = NULL;
	m_hr = 0;
}

CPictureDD::~CPictureDD()
{
	Close();
}

bool CPictureDD::Open(LPCTSTR Path, CBackBufDD& BackBuf)
{
	Close();
	if (!m_Picture.Open(Path))
		return(FALSE);
	BITMAP	bm;
	HBITMAP	hBitmap	= m_Picture.GetHandle();
	if (!GetObject(hBitmap, sizeof(bm), &bm))
		return(FALSE);
	m_Size = CSize(bm.bmWidth, bm.bmHeight);
	m_Size.cx &= ~1;	// force size to be even, else some plugins will fail
	m_Size.cy &= ~1;
	if (!CreateSurface(BackBuf))
		return(FALSE);
	return(UpdateSurface());
}

bool CPictureDD::UpdateSurface()
{
	HBITMAP	hBitmap	= m_Picture.GetHandle();
	CDC	dcBitmap;
	dcBitmap.CreateCompatibleDC(NULL);
	HGDIOBJ	PrevObj = dcBitmap.SelectObject(hBitmap);
	HDC	sdc;
	m_Surface->GetDC(&sdc);
	BOOL	retc = BitBlt(sdc, 0, 0, m_Size.cx, m_Size.cy, dcBitmap, 0, 0, SRCCOPY);
	m_Surface->ReleaseDC(sdc);
	dcBitmap.SelectObject(PrevObj);
	return(retc != 0);
}

void CPictureDD::Close()
{
	SAFE_RELEASE(m_Surface);
	m_Picture.Close();
}

bool CPictureDD::CreateSurface(CBackBufDD& BackBuf)
{
	if (!m_Picture.IsOpen())
		return(FALSE);
	SAFE_RELEASE(m_Surface);
	DDSURFACEDESC	sd;
	ZeroMemory(&sd, sizeof(sd));
	sd.dwSize = sizeof(sd);
	sd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;
	sd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_3DDEVICE | DDSCAPS_SYSTEMMEMORY;
	sd.dwWidth = m_Size.cx;
	sd.dwHeight	= m_Size.cy;
	if (FAILED(m_hr = BackBuf.CreateSurface(&sd, &m_Surface)))
		return(FALSE);
	return(UpdateSurface());
}

void CPictureDD::DestroySurface()
{
	SAFE_RELEASE(m_Surface);
}

bool CPictureDD::GetBitmap(BITMAP& Bitmap) const
{
	return(GetObject(m_Picture.GetHandle(), sizeof(BITMAP), &Bitmap) != 0);
}

DWORD CPictureDD::GetBitsPerPixel() const
{
	BITMAP	bi;
	return(GetBitmap(bi) ? bi.bmBitsPixel : 0);
}
