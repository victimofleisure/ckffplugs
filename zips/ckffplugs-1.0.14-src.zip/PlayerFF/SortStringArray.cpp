// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      09jul05 initial version
 
		sortable string array
 
*/

#include "stdafx.h"
#include "SortStringArray.h"

void CSortStringArray::Sort()
{
	qsort(m_pData, m_nSize, sizeof(CString *), compare);
}

int CSortStringArray::compare(const void *arg1, const void *arg2)
{
	return(strcmp(*(LPCSTR *)arg1, *(LPCSTR *)arg2));
}


