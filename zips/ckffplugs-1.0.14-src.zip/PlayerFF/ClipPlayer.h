// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      06nov06	initial version
		01		04dec06	add IsFirstFrame
		02		23nov07	support Unicode
		03		08may10	for mpg, reset path to clip

        player for video or still images
 
*/

#ifndef CCLIPPLAYER_INCLUDED
#define CCLIPPLAYER_INCLUDED

#include "Video.h"
#include "PictureDD.h"

class CClipPlayer : public WObject {
public:
// Construction
	CClipPlayer();
	~CClipPlayer();

// Types
	typedef CVideo::PROPS PROPS;

// Attributes
	bool	IsOpen() const;
	bool	IsVideoOpen() const;
	bool	IsPictureOpen() const;
	SIZE	GetFrameSize() const;
	DWORD	GetFrameCount() const;
	float	GetFrameRate() const;
	DWORD	GetBitCount() const;
	DWORD	GetCurFrame() const;
	LPCTSTR	GetPath() const;
	HRESULT	GetLastError() const;
	LPDIRECTDRAWSURFACE	GetSurface();
	bool	GetProps(PROPS& Props) const;
	void	SetBackBuf(CBackBufDD& BackBuf);
	bool	IsFirstFrame() const;

// Operations
	HRESULT	CreateSurface();
	void	DestroySurface();
	bool	Open(LPCTSTR Path);
	void	Close();

// Video operations
	bool	TimerHook();
	void	Rewind();
	void	Seek(DWORD Frame);

private:
// Types
	class CMyVideo : public CVideo {
	public:
		void	SetPath(LPCSTR Path) { m_Path = Path; }
	};

// Member data
	CMyVideo	m_Video;	// video interface
	CPictureDD	m_Picture;	// picture interface
	CBackBufDD	*m_dd;		// pointer to user's DirectDraw back buffer
	LPDIRECTDRAWSURFACE	m_Surface;	// DirectDraw surface of video or picture
	CSize	m_FrameSize;	// frame size of video or picture, in pixels
	int		m_FrameCount;	// total number of frames; always one for pictures
	float	m_FrameRate;	// frame rate, in frames per second; zero for pictures
	int		m_BitCount;		// color depth, in bits per pixel
	CString		m_PicturePath;	// if a picture is open, its path
};

inline bool CClipPlayer::IsVideoOpen() const
{
	return(m_Video.IsOpen());
}

inline bool CClipPlayer::IsPictureOpen() const
{
	return(m_Picture.IsOpen());
}

inline bool CClipPlayer::IsOpen() const
{
	return(IsVideoOpen() || IsPictureOpen());
}

inline SIZE CClipPlayer::GetFrameSize() const
{
	return(m_FrameSize);
}

inline DWORD CClipPlayer::GetFrameCount() const
{
	return(m_FrameCount);
}

inline float CClipPlayer::GetFrameRate() const
{
	return(m_FrameRate);
}

inline DWORD CClipPlayer::GetBitCount() const
{
	return(m_BitCount);
}

inline DWORD CClipPlayer::GetCurFrame() const
{
	return(m_Video.GetCurFrame());
}

inline LPCTSTR CClipPlayer::GetPath() const
{
	return(IsVideoOpen() ? m_Video.GetPath() : m_PicturePath);
}

inline HRESULT CClipPlayer::GetLastError() const
{
	return(IsVideoOpen() ? m_Video.GetLastError() : m_Picture.GetLastError());
}

inline LPDIRECTDRAWSURFACE CClipPlayer::GetSurface()
{
	return(m_Surface);
}

inline void CClipPlayer::SetBackBuf(CBackBufDD& BackBuf)
{
	m_dd = &BackBuf;
}

inline bool CClipPlayer::TimerHook()
{
	m_Video.TimerHook();
	return(m_Video.UpdateSurface());
}

inline void	CClipPlayer::Rewind()
{
	m_Video.Rewind();
}

inline void	CClipPlayer::Seek(DWORD Frame)
{
	m_Video.Seek(Frame);
}

inline bool CClipPlayer::IsFirstFrame() const
{
	return(m_Video.IsFirstFrame());
}

#endif
