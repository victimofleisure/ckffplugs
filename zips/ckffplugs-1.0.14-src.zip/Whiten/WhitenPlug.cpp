// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      01nov07	specialize demo

		freeframe source plugin demo
 
*/

#include <stdafx.h>
#include "WhitenPlug.h"
#include <math.h>

const PlugInfoStruct PlugInfo = {
	1,	// major version
	0,	// minor version
	{'W', 'H', 'T', 'N'},	// plugin identifier
	{'W', 'h', 'i', 't', 'e', 'n', ' ', ' ',
	 ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',},  // plugin title
	0	// source plugin
};

const PlugExtendedInfoStruct PlugExtInfo = {
	1,		// major version
	0,		// minor version
	"Whiten",	// description
	"Copyleft 2007 Chris Korda",	// about text
	0,		// extended data size
	NULL	// extended data block
};

const WhitenPlug::ParamConstantsStruct paramConstants[WhitenPlug::NUM_PARAMS] = {
// TODO: add default values and names of your plugin's parameters here
//			 1234567890123456
	{0,		"Brightness      "},
};

PlugInfoStruct* getInfo() 
{
	return const_cast<PlugInfoStruct *>(&PlugInfo);
}

DWORD initialise()
{
	return FF_SUCCESS;
}

DWORD deInitialise()
{
	return FF_SUCCESS;
}

DWORD getNumParameters()
{
	return WhitenPlug::NUM_PARAMS;  
}

char* getParameterName(DWORD index)
{
	if (index >= 0 && index < WhitenPlug::NUM_PARAMS)
		return const_cast<char *>(paramConstants[index].name);
	return "                ";
}

float getParameterDefault(DWORD index)
{
	if (index >= 0 && index < WhitenPlug::NUM_PARAMS)
		return paramConstants[index].defaultValue;
	return 0;
}

WhitenPlug::WhitenPlug()
{
	for (int i = 0; i < NUM_PARAMS; i++) {
		m_Param[i].value = paramConstants[i].defaultValue;
		memset(m_Param[i].displayValue, ' ', MAX_STRING);
	}
}

WhitenPlug::~WhitenPlug()
{
}

char* WhitenPlug::getParameterDisplay(DWORD index)
{
	memset(m_Param[index].displayValue, ' ', MAX_STRING);
	if (index >= 0 && index < NUM_PARAMS) {
		CString	s;
		s.Format("%g", m_Param[index].value);
		memcpy(m_Param[index].displayValue, s, min(s.GetLength(), MAX_STRING));
	}
	return m_Param[index].displayValue;
}

DWORD WhitenPlug::setParameter(SetParameterStruct* pParam)
{
	int	index = pParam->index;
	if (index >= 0 && index < NUM_PARAMS) {
		float	val = pParam->value;
		m_Param[index].value = val;
		// TODO: pass parameters to MainFrame here
		switch (index) {
		case BRIGHTNESS:
			m_Brightness = val;
			break;
		}
		return FF_SUCCESS;
	}
	return FF_FAIL;
}

float WhitenPlug::getParameter(DWORD index)
{
	if (index >= 0 && index < NUM_PARAMS)
		return m_Param[index].value;
	return 0;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case FF_CAP_16BITVIDEO:
		return FF_FALSE;

	case FF_CAP_24BITVIDEO:
		return FF_FALSE;

	case FF_CAP_32BITVIDEO:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_FALSE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return WhitenPlug::NUM_INPUT_FRAMES;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return WhitenPlug::NUM_INPUT_FRAMES;

	case FF_CAP_COPYORINPLACE:
		return FF_CAP_PREFER_NONE;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	// this shouldn't happen if the host is checking the capabilities properly
	if (pVideoInfo->bitDepth < 0 || pVideoInfo->bitDepth > 2)
		return (LPVOID) FF_FAIL;

	WhitenPlug *pPlugObj = new WhitenPlug;

	if (!pPlugObj->Init(*pVideoInfo)) {
		delete pPlugObj;
		return NULL;
	}

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	WhitenPlug *pPlugObj = (WhitenPlug*) instanceID;
	delete pPlugObj;	// delete first, THEN set to null (duh!)
	pPlugObj = NULL;	// mark instance deleted
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	return (LPVOID) &PlugExtInfo;
}
