// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
		01		09aug08	TextGen initial version
		02		11jul11	fix vertical centering
		03		12jul11	reselect default font
		04		14jul11	add background param
		05		19jul11	make font size logarithmic
		06		06aug11	refactor
		07		19aug11	add leading
		08		22aug11	add horizontal margins
		09		23aug11	support Unicode

		freeframe character generator view
 
*/

// FFMyView.cpp : implementation of the CFFMyView class
//

#include "stdafx.h"
#include "FFMyView.h"
#include <math.h>
#include "Benchmark.h"
#include "Win32Console.h"
#include "PathStr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFFMyView

const LPCTSTR CFFMyView::m_DocExt[DOC_EXTS] = {
	_T(".txt"),
};

// GDI+ creates lines slightly wider than GDI; we compensate for this,
// because the character widths for our line wrapping calculation still
// come from GDI's GetTextExtentExPoint, which has no equivalent in GDI+
static const float WIDTH_SCALE = .963f;	// approximate

#ifndef _UNICODE
#error only Unicode apps are supported
#endif

class CStdioFileEx : public CStdioFile {
public:
	BOOL Open(LPCTSTR lpszFileName, UINT nOpenFlags, CFileException* pError = NULL);
};

BOOL CStdioFileEx::Open(LPCTSTR lpszFileName, UINT nOpenFlags, CFileException* pError)
{
	if (nOpenFlags & (modeWrite | modeReadWrite))
		return CStdioFile::Open(lpszFileName, nOpenFlags, pError);
	if (!CStdioFile::Open(lpszFileName, nOpenFlags, pError))
		return FALSE;
	wchar_t	bom = 0;
	Read(&bom, sizeof(wchar_t));	// try to read byte order mark
	if (bom == 0xfeff) {	// if UTF-16 little endian
		Close();	// reopen as binary
		if (!CStdioFile::Open(lpszFileName, nOpenFlags | typeBinary, pError))
			return FALSE;
		Seek(sizeof(wchar_t), CFile::begin);	// skip byte order mark
	} else	// assume ANSI
		SeekToBegin();
	return TRUE;
}

CFFMyView::CFFMyView()
{
//	Win32Console::Create();	// debug only
	m_Doc = -1;
	m_Line = 0;
	m_Font = 0;
	m_FontSize = .1f;
	m_Leading = .5;
	m_HorzScale = .5;
	m_PosX = .5;
	m_PosY = .5;
	m_Rotation = 0;
	m_TextR = 1;
	m_TextG = 1;
	m_TextB = 1;
	m_Background = 0;
	m_Bold = 0;
	m_Italic = 0;
	m_Underline = 0;
	m_HorzMargins = .1f;
	GetFonts();
	LoadDocPaths();
	SetDoc(0);
}

int CALLBACK CFFMyView::FontProc(const LOGFONT *Font, const TEXTMETRIC *Metric, DWORD FontType, LPARAM lParam)
{
	CFFMyView	*This = (CFFMyView *)lParam;
	if (FontType == TRUETYPE_FONTTYPE) {
		FONT_INFO	fi;
		_tcscpy(fi.FaceName, Font->lfFaceName);
		fi.AspectRatio = float(Metric->tmAveCharWidth) / Metric->tmHeight;
		This->m_FontInfo.Add(fi);
	}
	return(TRUE);
}

void CFFMyView::GetFonts()
{
	LOGFONT	lf;
	ZeroMemory(&lf, sizeof(lf));
	lf.lfCharSet = ANSI_CHARSET;
	HDC	dc = GetDC(NULL);
	EnumFontFamiliesEx(dc, &lf, FontProc, (LPARAM)this, 0);
	ReleaseDC(NULL, dc);
}

bool CFFMyView::LoadDocPaths()
{
	CPathStr	DocFolder;
	TCHAR	*p = DocFolder.GetBuffer(MAX_PATH);
	bool	retc = SUCCEEDED(SHGetSpecialFolderPath(NULL, p, CSIDL_PERSONAL, 0));
	if (!retc)
		return(FALSE);
	DocFolder.ReleaseBuffer();
	DocFolder.Append(_T("TextGen"));
	CPathStr	PlaylistPath(DocFolder);
	PlaylistPath.Append(_T("playlist.txt"));
	CStdioFileEx	fp;
	if (fp.Open(PlaylistPath, CFile::modeRead | CFile::shareDenyWrite)) {
		CString	s;
		while (fp.ReadString(s)) {
			s.TrimLeft();
			s.TrimRight();
			if (s.IsEmpty())
				continue;	// ignore blank lines
			m_DocPath.Add(s);
		}
	} else {
		CPathStr	FindPath(DocFolder);
		FindPath.Append(_T("\\*.*"));
		CFileFind	ff;
		BOOL bWorking = ff.FindFile(FindPath);
		while (bWorking) {
			bWorking = ff.FindNextFile();
			if (!ff.IsDirectory()) {
				CString	name = ff.GetFileName();
				LPCTSTR	Ext = PathFindExtension(name);
				int	i;
				for (i = 0; i < DOC_EXTS; i++) {
					if (!_tcsicmp(Ext, m_DocExt[i]))
						break;
				}
				if (i < DOC_EXTS)
					m_DocPath.Add(ff.GetFilePath());
			}
		}
		m_DocPath.Sort();
	}
#ifdef _DEBUG
	DumpBanks();
#endif
	return(TRUE);
}

void CFFMyView::SetDoc(float Doc)
{
	int	docs = m_DocPath.GetSize();
	if (!docs) {
		m_Text.RemoveAll();
		m_Text.Add(_T("NO TEXT"));
		return;
	}
	int	iDoc = Denorm(Doc, docs);
	if (iDoc == m_Doc)
		return;
	m_Text.RemoveAll();
	CStdioFileEx	f;
	LPCTSTR	Path = m_DocPath[iDoc];
	CString	s;
	if (f.Open(Path, CFile::modeRead | CFile::shareDenyWrite)) {
		while (f.ReadString(s)) {
			s.TrimLeft();
			s.TrimRight();
			if (!s.IsEmpty())
				m_Text.Add(s);
		}
	}
}

inline bool CFFMyView::IsHyphen(TCHAR c)
{
	enum {
		EN_DASH = 0x96,
		EM_DASH = 0x97,
	};
	return(c == '-' || BYTE(c) == EN_DASH || BYTE(c) == EM_DASH);
}

DWORD CFFMyView::processFrame(LPVOID pFrame)
{
	if (!m_Text.GetSize())
		return(FF_FAIL);
	if (!m_FontInfo.GetSize())
		return(FF_FAIL);
	CFont	font;
	int	FontIdx = Denorm(m_Font, m_FontInfo.GetSize());
	const FONT_INFO&	fi = m_FontInfo[FontIdx];
	float	rHeight = float(m_VideoInfo.frameHeight 
		* (pow(MAX_FONT_SCALE, m_FontSize) - 1) + 1);
	int	Height = round(rHeight);
	int	Width;
	if (m_HorzScale == .5)
		Width = 0;
	else
		Width = round(rHeight * fi.AspectRatio 
			* pow(MAX_HORZ_SCALE, m_HorzScale * 2 - 1));
	font.CreateFont(
		Height,
		Width,
		0,
		0,
		m_Bold ? FW_BOLD : FW_NORMAL,
		m_Italic,
		m_Underline,
		FALSE,
		ANSI_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_DONTCARE,
		fi.FaceName);
	Font	f(m_hDC, font);
	int	TextIdx = Denorm(m_Line, m_Text.GetSize());
	const CString&	text = m_Text[TextIdx];
	CDWordArray	dx;
	int	textLen = text.GetLength();
	dx.SetSize(textLen);
	int	nFit;
	CSize	sz;
	HGDIOBJ	hPrevFont = SelectObject(m_hDC, font);
	GetTextExtentExPoint(m_hDC, text, textLen, INT_MAX, 
		&nFit, (int *)dx.GetData(), &sz);
	int	i = 0;
	int	begLine = 0;
	int	endLine = 0;
	int	maxExt = round(m_VideoInfo.frameWidth * (1 - m_HorzMargins) * WIDTH_SCALE);
	LPCTSTR	pText = text;
	int	lines = 0;
	while (i < textLen) {
		bool	gotSpace = isspace(pText[i]) != 0;
		bool	gotHyphen = IsHyphen(pText[i]);
		if (gotSpace || gotHyphen || i == textLen - 1) {	// if end of word
			int	endPos = gotSpace ? i - 1 : i;	// exclude space, include hyphen
			int	begExt = begLine ? dx[begLine - 1] : 0;
			int	lineExt = dx[endPos] - begExt;
			if (lineExt > maxExt) {	// if word doesn't fit on line
				int	lineLen = endLine - begLine;
				if (IsHyphen(pText[endLine]))
					lineLen++;	// include hyphen
				if (lineLen > 0) {
					LINE_INFO	li = {begLine, lineLen};
					m_LineInfo.SetAtGrow(lines++, li);
					begLine = endLine + 1;	// skip terminator
				}
			}
			endLine = i;
		}
		i++;
	}
	int	lineLen = textLen - begLine;
	if (lineLen > 0) {
		LINE_INFO	li = {begLine, lineLen};
		m_LineInfo.SetAtGrow(lines++, li);
	}
	Bitmap	bmp(&m_bmi, pFrame);
	Graphics	g(&bmp);
	Color	c(round(m_TextR * 255), round(m_TextG * 255), round(m_TextB * 255));
	SolidBrush	brush(c);
	g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
	if (m_Background) {
		Color	bg;
		g.Clear(bg);
	}
	if (lines) {
		StringFormat	sf;
		sf.SetAlignment(StringAlignmentCenter);
		Matrix	mat;
		float	HorzScale = float(pow(MAX_HORZ_SCALE, m_HorzScale * 2 - 1));
		mat.Scale(HorzScale, 1, MatrixOrderAppend);
		mat.Rotate(m_Rotation * -360, MatrixOrderAppend);
		float	x = m_VideoInfo.frameWidth / 2 
			+ m_VideoInfo.frameWidth * 2 * (m_PosX - .5f);
		float	y = m_VideoInfo.frameHeight / 2 
			+ m_VideoInfo.frameHeight * 2 * (m_PosY - .5f);
		mat.Translate(x, y, MatrixOrderAppend);
		g.SetTransform(&mat);
		float	Leading = (m_Leading * 2 - 1) * rHeight;
		float	dy = rHeight + Leading;
		float	yofs = (rHeight - (lines - 1) * dy) / 2 - rHeight;
		double	angle = PI * 2 * m_Rotation;
		for (int i = 0; i < lines; i++) {
			const LINE_INFO& li = m_LineInfo[i];
			LPCTSTR	str = &pText[li.start];
			PointF	org(0, yofs);
			g.DrawString(str, li.len, &f, org, &sf, &brush);
			yofs += dy;
		}
	}
	if (hPrevFont != NULL)
		SelectObject(m_hDC, hPrevFont);	// reselect default font
	return(FF_SUCCESS);
}
