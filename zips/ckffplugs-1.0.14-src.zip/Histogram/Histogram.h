// Copyleft 2005 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01		26nov11	histogram plugin

		histogram plugin
 
*/

// Histogram.h : main header file for the Histogram DLL
//

#if !defined(AFX_HISTOGRAM_H__943632C4_9EA9_474D_907B_B46E3AB934BD__INCLUDED_)
#define AFX_HISTOGRAM_H__943632C4_9EA9_474D_907B_B46E3AB934BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CHistogram
// See Histogram.cpp for the implementation of this class
//

class CHistogram : public CWinApp
{
public:
	CHistogram();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHistogram)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CHistogram)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISTOGRAM_H__943632C4_9EA9_474D_907B_B46E3AB934BD__INCLUDED_)
