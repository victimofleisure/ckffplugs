// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
		02		30dec06	make top-down DIB conditional
		03		12jul11	fix Init handle leak; create DIB with m_hDC, not GetDC
        04		26nov11	histogram plugin
        05		29nov11	optimize in assembler
        06		30nov11	allocate single sample array
        07		28dec11	fix crash in 24-bit mode
        08		28dec11	use trunc to fix width of first and last bars

		freeframe plugin's surrogate main frame window
 
*/

#include <stdafx.h>
#include "FreeFrame.h"
#include "MainFrm.h"

#define	USE_ASM_CALC	1
#define	USE_ASM_FILL	1

const COLORREF	CMainFrame::m_ChanColor[CHANS] = {
	RGB(255, 0, 0), 
	RGB(0, 255, 0),
	RGB(0, 0, 255),
	RGB(255, 255, 255),
};

const COLORREF	CMainFrame::m_ChanColorBGR[CHANS] = {
	RGB(0, 0, 255),
	RGB(0, 255, 0),
	RGB(255, 0, 0), 
	RGB(255, 255, 255),
};

const int CMainFrame::m_ModeChanRange[VIDEO_MODES][CHANS] = {
	{	// 16-bit 5-6-5
		(1 << 5), 
		(1 << 6), 
		(1 << 5), 
		(1 << 5) + (1 << 6) + (1 << 5) - 2
	},
	{	// 24-bit
		(1 << 8),
		(1 << 8),
		(1 << 8),
		(1 << 8) * 3 - 2
	},
	{	// 32-bit
		(1 << 8),
		(1 << 8),
		(1 << 8),
		(1 << 8) * 3 - 2
	}
};

const int CMainFrame::m_SampleBufSize[VIDEO_MODES] = {
	{
		m_ModeChanRange[VIDEO_MODE_16][R] + 
		m_ModeChanRange[VIDEO_MODE_16][G] + 
		m_ModeChanRange[VIDEO_MODE_16][B] + 
		m_ModeChanRange[VIDEO_MODE_16][LUMA]
	},
	{
		m_ModeChanRange[VIDEO_MODE_24][R] + 
		m_ModeChanRange[VIDEO_MODE_24][G] + 
		m_ModeChanRange[VIDEO_MODE_24][B] + 
		m_ModeChanRange[VIDEO_MODE_24][LUMA]
	},
	{
		m_ModeChanRange[VIDEO_MODE_32][R] + 
		m_ModeChanRange[VIDEO_MODE_32][G] + 
		m_ModeChanRange[VIDEO_MODE_32][B] + 
		m_ModeChanRange[VIDEO_MODE_32][LUMA]
	}
};

CMainFrame::CMainFrame()
{
	ZeroMemory(&m_VideoInfo, sizeof(m_VideoInfo));
	ZeroMemory(&m_bmi, sizeof(m_bmi));
	m_hDC = NULL;
	m_hDib = NULL;
	m_DibBits = NULL;
	m_PrevBm = NULL;
	m_FrameBytes = 0;
	m_BytesPerPixel = 0;
	// app-specific
	m_Mode = 0;
	m_Fill = TRUE;
	m_EraseBkgnd = FALSE;
	m_BitBashFill = FALSE;
	m_TopDownDIB = FALSE;
	m_Scale = 1;
	m_Origin = 1;
	m_LineWidth = 1;
	m_PrevPen = NULL;
	m_pFrame = NULL;
}

CMainFrame::~CMainFrame()
{
	if (m_PrevBm != NULL)
		SelectObject(m_hDC, m_PrevBm);	// restore DC's previous bitmap
	if (m_PrevPen != NULL)
		SelectObject(m_hDC, m_PrevPen);
	DeleteObject(m_hDib);
	DeleteObject(m_hDC);
}

bool CMainFrame::Init(const VideoInfoStruct& videoInfo)
{
	m_VideoInfo = videoInfo;
	m_hDC = CreateCompatibleDC(NULL);
	if (m_hDC == NULL)
		return(FALSE);
	ZeroMemory(&m_bmi, sizeof(m_bmi));
	m_bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	m_bmi.bmiHeader.biWidth = m_VideoInfo.frameWidth;
	m_bmi.bmiHeader.biHeight = LONG(m_VideoInfo.frameHeight);
	if (videoInfo.orientation != FF_ORIGIN_BOTTOM_LEFT) {
		m_bmi.bmiHeader.biHeight = -m_bmi.bmiHeader.biHeight;	// top-down DIB
		m_TopDownDIB = TRUE;
	}
	m_bmi.bmiHeader.biPlanes = 1;
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		m_bmi.bmiHeader.biBitCount = 16;
		m_bmi.bmiHeader.biCompression = BI_BITFIELDS;	// must be 5-6-5
		*(DWORD *)m_bmi.bmiColors = 0xF800;	// red color mask
		m_bmi.GreenMask = 0x07E0;	// green color mask
		m_bmi.BlueMask = 0x001F;	// blue color mask
		m_BytesPerPixel = 2;
		break;
	case FF_CAP_24BITVIDEO:
		m_bmi.bmiHeader.biBitCount = 24;
		m_BytesPerPixel = 3;
		break;
	case FF_CAP_32BITVIDEO:
		m_bmi.bmiHeader.biBitCount = 32;
		m_BytesPerPixel = 4;
		m_BitBashFill = TRUE;	// use bit bash fill for 32-bit video
		break;
	default:
		return(FALSE);
	}
	m_hDib = CreateDIBSection(m_hDC, &m_bmi, DIB_RGB_COLORS, &m_DibBits, NULL, 0);
	if (m_hDib == NULL)
		return(FALSE);
	BITMAP	bm;	// check bitmap's actual size in bytes, just in case
	if (!GetObject(m_hDib, sizeof(bm), &bm))
		return(FALSE);
	if (bm.bmWidthBytes != LONG(m_VideoInfo.frameWidth) * m_BytesPerPixel)
		return(FALSE);
	m_PrevBm = SelectObject(m_hDC, m_hDib);
	if (m_PrevBm == NULL)
		return(FALSE);
	m_FrameBytes = m_VideoInfo.frameWidth * m_VideoInfo.frameHeight * m_BytesPerPixel;
	m_SampleBuf.SetSize(m_SampleBufSize[m_VideoInfo.bitDepth]);
	DWORD	*pSamp = m_SampleBuf.GetData();
	memcpy(m_ChanRange, m_ModeChanRange[m_VideoInfo.bitDepth], sizeof(m_ChanRange));
	for (int i = 0; i < CHANS; i++) {
		m_ChanSample[i] = pSamp;
		pSamp += m_ChanRange[i];
	}
	m_PrevPen = SelectObject(m_hDC, GetStockObject(WHITE_PEN));
	return(TRUE);
}

DWORD CMainFrame::processFrame(LPVOID pFrame)
{
	// clear sample buffer
	ZeroMemory(m_SampleBuf.GetData(), m_SampleBuf.GetSize() * sizeof(DWORD));
	switch (m_VideoInfo.bitDepth) {
	case FF_CAP_16BITVIDEO:
		{
			const SHORT	*pSrc = (SHORT *)pFrame;
			int	ws = m_FrameBytes >> 1;
			if (USE_ASM_CALC) {
				DWORD	*pBlue = m_ChanSample[B];
				__asm {
					mov		ecx, ws		// init loop count
					mov		esi, pSrc	// init frame pointer
					mov		edi, pBlue	// init sample pointer to blue
				$Calc16BitTop:
					mov		ax, [esi]	// get 16-bit 5-6-5 pixel from frame
					add		esi, 2		// bump frame pointer
					mov		ebx, eax	// save pixel
					and		eax, 01fh	// isolate pixel's blue level
					mov		edx, eax	// init luma sum to blue level
					inc		dword ptr [edi+eax*4]	// bump blue level's count
					sub		edi, 256	// offset sample pointer to green
					mov		eax, ebx	// restore pixel
					shr		eax, 5		// get pixel's green level
					and		eax, 03fh	// isolate pixel's green level
					add		edx, eax	// add green level to luma sum
					inc		dword ptr [edi+eax*4]	// bump green level's count
					sub		edi, 128	// offset sample pointer to red
					shr		ebx, 11		// get pixel's red level
					and		ebx, 01fh	// isolate pixel's red level
					add		edx, ebx	// add red level to luma sum
					inc		dword ptr [edi+ebx*4]	// bump red level's count
					add		edi, 512	// offset sample pointer to luma
					inc		dword ptr [edi+edx*4]	// bump luma level's count
					sub		edi, 128	// offset sample pointer to blue
					dec		ecx
					jne		$Calc16BitTop
				}
			} else {	// no assembler
				for (int i = 0; i < ws; i++) {
					SHORT	pix = *pSrc++;
					BYTE	b = pix & 0x1f;
					BYTE	g = (pix >> 5) & 0x3f;
					BYTE	r = (pix >> 11) & 0x1f;
					m_ChanSample[R][r]++;
					m_ChanSample[G][g]++;
					m_ChanSample[B][b]++;
					int	luma = r + g + b;
					m_ChanSample[LUMA][luma]++;
				}
			}
		}
		break;
	case FF_CAP_24BITVIDEO:
		{
			// not optimized
			const BYTE	*pSrc = (BYTE *)pFrame;
			int	bs = m_FrameBytes / 3;
			for (int i = 0; i < bs; i++) {
				BYTE	b = *pSrc++;
				BYTE	g = *pSrc++;
				BYTE	r = *pSrc++;
				m_ChanSample[R][r]++;
				m_ChanSample[G][g]++;
				m_ChanSample[B][b]++;
				int	luma = r + g + b;
				m_ChanSample[LUMA][luma]++;
			}
		}
		break;
	case FF_CAP_32BITVIDEO:
		{
			const DWORD	*pSrc = (DWORD *)pFrame;
			int	dws = m_FrameBytes >> 2;
			if (USE_ASM_CALC) {
				DWORD	*pBlue = m_ChanSample[B];
				__asm {
					mov		ecx, dws	// init loop count
					mov		esi, pSrc	// init frame pointer
					mov		edi, pBlue	// init sample pointer to blue
				$Calc32BitTop:
					mov		eax, [esi]	// get 32-bit pixel from frame
					add		esi, 4		// bump frame pointer
					mov		ebx, eax	// save pixel
					and		eax, 0ffh	// isolate pixel's blue level
					mov		edx, eax	// init luma sum to blue level
					inc		dword ptr [edi+eax*4]	// bump blue level's count
					sub		edi, 1024	// offset sample pointer to green
					mov		eax, ebx	// restore pixel
					shr		eax, 8		// get pixel's green level
					and		eax, 0ffh	// isolate pixel's green level
					add		edx, eax	// add green level to luma sum
					inc		dword ptr [edi+eax*4]	// bump green level's count
					sub		edi, 1024	// offset sample pointer to red
					shr		ebx, 16		// get pixel's red level
					and		ebx, 0ffh	// isolate pixel's red level
					add		edx, ebx	// add red level to luma sum
					inc		dword ptr [edi+ebx*4]	// bump red level's count
					add		edi, 3072	// offset sample pointer to luma
					inc		dword ptr [edi+edx*4]	// bump luma level's count
					sub		edi, 1024	// offset sample pointer to blue
					dec		ecx
					jne		$Calc32BitTop
				}
			} else {	// no assembler
				for (int i = 0; i < dws; i++) {
					DWORD	pix = *pSrc++;
					BYTE	b = LOBYTE(pix);
					BYTE	g = HIBYTE(pix);
					BYTE	r = LOBYTE(HIWORD(pix));
					m_ChanSample[R][r]++;
					m_ChanSample[G][g]++;
					m_ChanSample[B][b]++;
					int	luma = r + g + b;
					m_ChanSample[LUMA][luma]++;
				}
			}
		}
		break;
	}
	if (m_Fill && m_BitBashFill) {	// if filling via bit bash fill
		m_pFrame = pFrame;	// save frame pointer for bit bash fill
		if (m_EraseBkgnd)
			ZeroMemory(m_pFrame, m_FrameBytes);	// clear frame buffer
	} else {	// drawing line, or filling via GDI fill
		if (m_EraseBkgnd)	// if erasing background
			ZeroMemory(m_DibBits, m_FrameBytes);	// clear DIB
		else	// not erasing background
			memcpy(m_DibBits, pFrame, m_FrameBytes);	// init DIB from frame
	}
	switch (m_Mode) {
	case DM_LUMA:
		DrawHist(LUMA, 0, 1);
		break;
	case DM_RGB:
		DrawHist(R, R, COLOR_CHANS);
		DrawHist(G, G, COLOR_CHANS);
		DrawHist(B, B, COLOR_CHANS);
		break;
	case DM_RGB_LUMA:
		DrawHist(R, R, CHANS);
		DrawHist(G, G, CHANS);
		DrawHist(B, B, CHANS);
		DrawHist(LUMA, LUMA, CHANS);
		break;
	case DM_RGB_OVERLAY:
		DrawHist(R, 0, 1);
		DrawHist(G, 0, 1);
		DrawHist(B, 0, 1);
		break;
	}
	if (!(m_Fill && m_BitBashFill))	// if not filling via bit bash fill
		memcpy(pFrame, m_DibBits, m_FrameBytes);	// copy DIB to frame
	return(FF_SUCCESS);
}

inline void FillVert32(DWORD *pFrame, int Stride, int x, int y1, int Rows, int Color);
inline void FillVert32Rev(DWORD *pFrame, int Stride, int x, int y2, int Rows, int Color);
inline void FillVertOr32(DWORD *pFrame, int Stride, int x, int y1, int Rows, int Color);
inline void FillVertOr32Rev(DWORD *pFrame, int Stride, int x, int y2, int Rows, int Color);

void CMainFrame::DrawHist(int ChanIdx, int RowIdx, int Rows)
{
	int	width = m_VideoInfo.frameWidth;
	int	height = m_VideoInfo.frameHeight;
	double	ScaledHeight = height * m_Scale;
	double	RowDelta = ScaledHeight / Rows; 
	double	OffsetY = (height - ScaledHeight) * m_Origin;
	int	cy = round(RowDelta);
	int	oy = round(OffsetY + RowDelta * RowIdx + RowDelta);
	DWORD	*sample = m_ChanSample[ChanIdx];
	int	range = m_ChanRange[ChanIdx];
	DWORD	MaxCount = 0;
	for (int i = 0; i < range; i++) {
		if (sample[i] > MaxCount)
			MaxCount = sample[i];
	}
	double	xscale = double(range) / width;
	if (m_Fill) {
		if (m_Mode == DM_RGB_OVERLAY) {
			if (m_BitBashFill) {	// if bit bash fill
				DWORD	*pFrame = (DWORD *)m_pFrame;
				double	yscale = double(cy) / MaxCount;
				DWORD	color = m_ChanColorBGR[ChanIdx];
				if (m_TopDownDIB) {	// if top-down DIB
					for (int x = 0; x < width; x++) {
						int	j = trunc(x * xscale);
						int	y = round(sample[j] * yscale);
						FillVertOr32Rev(pFrame, width, x, oy, y, color);
					}
				} else {	// bottom-up DIB
					for (int x = 0; x < width; x++) {
						int	j = trunc(x * xscale);
						int	y = round(sample[j] * yscale);
						FillVertOr32(pFrame, width, x, height - oy, y, color);
					}
				}
			} else {	// GDI fill
				CPen	pen(PS_SOLID, 1, m_ChanColor[ChanIdx]);
				SelectObject(m_hDC, pen);
				SetROP2(m_hDC, R2_MERGEPEN);
				// Same as non-overlay case except use Rectangle because FillRect
				// doesn't support ROPs; brush is irrelevant for a one pixel wide
				// rectangle because it's all border so only pen is actually used.
				// This method is much slower than bit-bashing, and also fails to
				// draw anything if the line has a height of 1.
				double	yscale = double(cy) / MaxCount;
				for (int x = 0; x < width; x++) {
					int	j = trunc(x * xscale);
					int	y = round(sample[j] * yscale);
					Rectangle(m_hDC, x, oy - y, x + 1, oy);
				}
			}
		} else {	// not RGB overlay
			if (m_BitBashFill) {	// if bit bash fill
				DWORD	*pFrame = (DWORD *)m_pFrame;
				double	yscale = double(cy) / MaxCount;
				DWORD	color = m_ChanColorBGR[ChanIdx];
				if (m_TopDownDIB) {	// if top-down DIB
					for (int x = 0; x < width; x++) {
						int	j = trunc(x * xscale);
						int	y = round(sample[j] * yscale);
						FillVert32Rev(pFrame, width, x, oy, y, color);
					}
				} else {	// bottom-up DIB
					for (int x = 0; x < width; x++) {
						int	j = trunc(x * xscale);
						int	y = round(sample[j] * yscale);
						FillVert32(pFrame, width, x, height - oy, y, color);
					}
				}
			} else {	// GDI fill
				CBrush	brush(m_ChanColor[ChanIdx]);
				double	yscale = double(cy) / MaxCount;
				for (int x = 0; x < width; x++) {
					int	j = trunc(x * xscale);
					int	y = round(sample[j] * yscale);
					FillRect(m_hDC, CRect(x, oy - y, x + 1, oy), brush);
				}
			}
		}
	} else {	// line instead of fill
		cy--;	// include zero
		oy--;
		CPen	pen(PS_SOLID, m_LineWidth, m_ChanColor[ChanIdx]);
		SelectObject(m_hDC, pen);
		if (m_Mode == DM_RGB_OVERLAY)
			SetROP2(m_hDC, R2_MERGEPEN);
		double	yscale = double(cy) / MaxCount;
		int	y = round(sample[0] * yscale);
		MoveToEx(m_hDC, 0, oy - y, NULL);
		for (int x = 1; x < width; x++) {
			int	j = trunc(x * xscale);
			int	y = round(sample[j] * yscale);
			LineTo(m_hDC, x, oy - y);
		}
	}
}

static inline void FillVert32(DWORD *pFrame, int Stride, int x, int y1, int Rows, int Color)
{
	DWORD	*pDst = pFrame + y1 * Stride + x;
	if (USE_ASM_FILL) {
		__asm {
			mov		ecx, Rows
			test	ecx, ecx
			jle		$FillVert32End
			mov		esi, pDst
			mov		edx, Stride
			shl		edx, 2
			mov		eax, Color
		$FillVert32Top:
			mov		[esi], eax
			add		esi, edx
			dec		ecx
			jne		$FillVert32Top
		$FillVert32End:
		}
	} else {	// no assembler
		for (int i = 0; i < Rows; i++) {
			*pDst = Color;
			pDst += Stride;
		}
	}
}

static inline void FillVert32Rev(DWORD *pFrame, int Stride, int x, int y2, int Rows, int Color)
{
	DWORD	*pDst = pFrame + y2 * Stride + x;
	if (USE_ASM_FILL) {
		__asm {
			mov		ecx, Rows
			test	ecx, ecx
			jle		$FillVert32RevEnd
			mov		esi, pDst
			mov		edx, Stride
			shl		edx, 2
			mov		eax, Color
		$FillVert32RevTop:
			sub		esi, edx
			mov		[esi], eax
			dec		ecx
			jne		$FillVert32RevTop
		$FillVert32RevEnd:
		}
	} else {	// no assembler
		for (int i = 0; i < Rows; i++) {
			pDst -= Stride;
			*pDst = Color;
		}
	}
}

static inline void FillVertOr32(DWORD *pFrame, int Stride, int x, int y1, int Rows, int Color)
{
	DWORD	*pDst = pFrame + y1 * Stride + x;
	if (USE_ASM_FILL) {
		__asm {
			mov		ecx, Rows
			test	ecx, ecx
			jle		$FillVertOr32End
			mov		esi, pDst
			mov		edx, Stride
			shl		edx, 2
			mov		eax, Color
		$FillVertOr32Top:
			or		[esi], eax
			add		esi, edx
			dec		ecx
			jne		$FillVertOr32Top
		$FillVertOr32End:
		}
	} else {	// no assembler
		for (int i = 0; i < Rows; i++) {
			*pDst |= Color;
			pDst += Stride;
		}
	}
}

static inline void FillVertOr32Rev(DWORD *pFrame, int Stride, int x, int y2, int Rows, int Color)
{
	DWORD	*pDst = pFrame + y2 * Stride + x;
	if (USE_ASM_FILL) {
		__asm {
			mov		ecx, Rows
			test	ecx, ecx
			jle		$FillVertOr32RevEnd
			mov		esi, pDst
			mov		edx, Stride
			shl		edx, 2
			mov		eax, Color
		$FillVertOr32RevTop:
			sub		esi, edx
			or		[esi], eax
			dec		ecx
			jne		$FillVertOr32RevTop
		$FillVertOr32RevEnd:
		}
	} else {	// no assembler
		for (int i = 0; i < Rows; i++) {
			pDst -= Stride;
			*pDst |= Color;
		}
	}
}
