// Copyleft 2006 Chris Korda
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 2 of the License, or any later version.
/*
        chris korda
 
		revision history:
		rev		date	comments
        00      27jul06	initial version
        01      27dec06	support 16-bit mode
        02		26nov11	histogram plugin
        03		29nov11	optimize in assembler
        04		30nov11	allocate single sample array

		freeframe plugin's surrogate main frame window
 
*/

#ifndef CMAINFRAME_INCLUDED
#define CMAINFRAME_INCLUDED

#include "FreeFrame.h"

struct VideoInfoStructTag;

class CMainFrame {
public:
// Construction
	CMainFrame();
	~CMainFrame();
	bool	Init(const VideoInfoStructTag& videoInfo);

// Constants

// Attributes

// Operations
	DWORD	processFrame(LPVOID pFrame);

protected:
// Types
	typedef struct tagMYBITMAPINFO : BITMAPINFO {
		// The bmiColors array allocates a single DWORD, but in 16-bit mode,
		// bmiColors needs to contain three DWORDs: one DWORD each for the red,
		// green and blue color masks.  So we inherit from BITMAPINFO and add 
		// space for the green and blue masks; the red mask is bmiColors[0].
		DWORD	GreenMask;
		DWORD	BlueMask;
	} MYBITMAPINFO;

// Constants

// Plugin member data
	VideoInfoStruct	m_VideoInfo;	// copy of video info passed to Init
	MYBITMAPINFO	m_bmi;		// frame DIB info
	HDC		m_hDC;				// frame DIB device context
	HBITMAP	m_hDib;				// frame DIB handle
	void	*m_DibBits;			// frame DIB data
	HGDIOBJ	m_PrevBm;			// DC's previous bitmap
	LONG	m_FrameBytes;		// size of frame in bytes
	LONG	m_BytesPerPixel;	// number of bytes per pixel

// App member data
	enum {	// display modes
		DM_LUMA,			// luma only
		DM_RGB,				// R, G, B
		DM_RGB_LUMA,		// R, G, B, luma
		DM_RGB_OVERLAY,		// R, G, B OR'd together
		DISPLAY_MODES
	};
	enum {	// channels
		R,
		G,
		B,
		LUMA,
		CHANS,
		COLOR_CHANS = LUMA,
	};
	enum {	// video modes
		VIDEO_MODE_16,
		VIDEO_MODE_24,
		VIDEO_MODE_32,
		VIDEO_MODES
	};
	static const COLORREF	m_ChanColor[CHANS];	// channel colors in RGB
	static const COLORREF	m_ChanColorBGR[CHANS];	// channel colors in BGR
	static const int	m_ModeChanRange[VIDEO_MODES][CHANS];	// channel range per mode
	static const int	m_SampleBufSize[VIDEO_MODES];	// buffer size per mode, in elements
	CDWordArray	m_SampleBuf;	// pixel count sample buffer
	DWORD	*m_ChanSample[CHANS];	// pixel counts for each channel
	int		m_ChanRange[CHANS];	// range of each channel
	int		m_Mode;				// display mode
	bool	m_Fill;				// if true, fill, else draw line
	bool	m_EraseBkgnd;		// if true, erase background
	bool	m_BitBashFill;		// if true, fill via bit bash instead of GDI
	bool	m_TopDownDIB;		// if true, DIB is top-down
	float	m_Scale;			// graph scaling
	float	m_Origin;			// graph origin
	int		m_LineWidth;		// line width in pixels
	HGDIOBJ	m_PrevPen;			// DC's previous pen
	LPVOID	m_pFrame;			// pointer to current frame

// Helpers
	void	DrawHist(int ChanIdx, int RowIdx, int Rows);
};

#endif
